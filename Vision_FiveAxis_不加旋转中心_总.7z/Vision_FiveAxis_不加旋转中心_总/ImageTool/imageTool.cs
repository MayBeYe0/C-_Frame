﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;
using Parameter;

namespace ImageTool1212
{
    public class imageTool1212
    {
        #region 属性字段
        //抓圆
        HTuple hv_Width, hv_Height, hv_Tuple;
        //创建模板
        HObject ho_Regions;
        public ModelParamers modelPara = new ModelParamers();  //模型参数
        public CircleCenterParam cCenterPara = new CircleCenterParam();  //圆心参数
        #endregion
        #region 清空图像
        public void ClearWindow(HTuple hwin)
        {
            HOperatorSet.ClearWindow(hwin);
        }
        #endregion
        #region 显示图片
        public void ShowImage(HObject image, HTuple hwin)
        {
            if (/*image != null*/ image.CountObj() != 0 )
            {
                HOperatorSet.GetImageSize(image, out hv_Width, out hv_Height);
                HOperatorSet.SetPart(hwin, 0, 0, hv_Height, hv_Width);
                HOperatorSet.DispObj(image, hwin);
            }
            hv_Width = null; hv_Height = null;
        }
        #endregion
        #region 显示九点标定轮廓
        public void ShowNineCalibContours(PosInfo pos, HTuple hwin)
        {
            if (pos != null)
            {
                HOperatorSet.SetLineWidth(hwin, 3);
                HOperatorSet.SetColor(hwin, "green");
                //显示轮廓
                HOperatorSet.DispObj(pos.CircleContours, hwin);
                HOperatorSet.DispObj(pos.CrossContours, hwin); 
            }
        }
        #endregion
        #region 显示九点模板轮廓
        public void ShowModelContours(ModelParamers modelPara, HTuple hwin)
        {
            if (modelPara.ModelContours != null)
            {
                HOperatorSet.SetLineWidth(hwin, 3);
                HOperatorSet.SetColor(hwin, "green");
                //显示轮廓
                HOperatorSet.DispObj(modelPara.ModelContours, hwin);
            }
        }
        #endregion
        #region 显示阀标定轮廓
        public void ShowCalibraValve(CalibraValveParam CVP, HTuple hwin)
        {
            if (CVP != null)
            {
                HOperatorSet.SetLineWidth(hwin, 3);
                HOperatorSet.SetColor(hwin, "green");
                //显示轮廓
                HOperatorSet.DispObj(CVP.CircleContour, hwin);
                HOperatorSet.DispObj(CVP.CircleCenterContour, hwin); 
            }
        }
        #endregion
        #region 抓圆(九点标定)
        public void FindCircle(HObject image, ref PosInfo posInf, CalibraNinePointParam CNPP)
        {
            int i = posInf.CountsObj;
            //拟合圆
            ho_Regions = new HObject();
            HObject ho_RegionTrans = new HObject(), ho_ImageResult = new HObject(), ho_RegionDilation = new HObject(), ho_ImageReduced = new HObject(), ho_Edges = new HObject(), ho_SelectedXLD = new HObject(), ho_Cross = new HObject(), ho_ImageMedian = new HObject(), ho_ConnectedRegions = new HObject(), ho_SelectedRegions = new HObject();
            HTuple hv_Area, hv_Row, hv_Column, hv_PointOrder;
            ho_ImageMedian.Dispose();
            HOperatorSet.MedianImage(image, out ho_ImageMedian, "circle", CNPP.MedianValue, "mirrored");  //中值滤波
            ho_Regions.Dispose();
            HOperatorSet.Threshold(ho_ImageMedian, out ho_Regions, CNPP.MinGray, CNPP.MaxGray);  //筛选区域
            ho_ConnectedRegions.Dispose();
            HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
            ho_SelectedRegions.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions, out ho_SelectedRegions, "area",
                "and", CNPP.MinArea, CNPP.MaxArea);
            ho_RegionTrans.Dispose();
            HOperatorSet.ShapeTrans(ho_SelectedRegions, out ho_RegionTrans, "convex");
            ho_ImageResult.Dispose();
            HOperatorSet.PaintRegion(ho_RegionTrans, image, out ho_ImageResult,
                5, "fill");
            ho_RegionDilation.Dispose();
            HOperatorSet.DilationCircle(ho_Regions, out ho_RegionDilation, 20);
            ho_ImageReduced.Dispose();
            HOperatorSet.ReduceDomain(ho_ImageResult, ho_RegionDilation, out ho_ImageReduced
                );
            ho_Edges.Dispose();
            HOperatorSet.EdgesSubPix(ho_ImageReduced, out ho_Edges, "canny", 10, 10, 60);
            ho_SelectedXLD.Dispose();
            HOperatorSet.SelectShapeXld(ho_Edges, out ho_SelectedXLD, (new HTuple("circularity")).TupleConcat(
                "contlength"), "and", (new HTuple(0.29899)).TupleConcat(995.58), (new HTuple(1)).TupleConcat(
                5000));
            HOperatorSet.AreaCenterXld(ho_SelectedXLD, out hv_Area, out hv_Row, out hv_Column,
                out hv_PointOrder);
            ho_Cross.Dispose();
            HOperatorSet.GenCrossContourXld(out ho_Cross, hv_Row, hv_Column, 36, 0);

            posInf.Rows[i] = hv_Row;
            posInf.Columns[i] = hv_Column;
            posInf.CircleContours = ho_SelectedXLD;
            posInf.CrossContours = ho_Cross;
            posInf.CountsObj++;
        }
        #endregion
        #region 保存矩阵
        public void SaveMatric(HTuple HomMat2D)
        {
            if (HomMat2D != null)
            {
                HOperatorSet.WriteTuple(HomMat2D, "NineHomMat2D.tup");
            }
        }
        #endregion
        #region 打开矩阵
        public HTuple ReadMatric()
        {
            HOperatorSet.ReadTuple("NineHomMat2D.tup",
            out hv_Tuple);
            return hv_Tuple;
        }
        #endregion
        #region 创建模板
        public void CreateModel(HObject ho_Image, out HTuple ModelID, ref ModelParamers modelParamers, HTuple hwin, int shape)
        {
            HTuple hv_Row, hv_Column, hv_Radius, hv_HomMat2D, hv_Row11, hv_Column11, hv_Row21, hv_Column21, hv_Area;
            HObject ho_Circle = new HObject(), ho_ImageReduced = new HObject(), ho_ModelContours = new HObject();
            //创建模板
            HOperatorSet.SetLineWidth(hwin, 3);
            HOperatorSet.SetColor(hwin, "green");
            if (shape == 0)  //圆
            {
                disp_message(3600, "请画一个圆", "image", 12, 12, "red", "true");
                HOperatorSet.DrawCircle(3600, out hv_Row, out hv_Column, out hv_Radius);
                ho_Circle.Dispose();
                HOperatorSet.GenCircle(out ho_Circle, hv_Row, hv_Column, hv_Radius);
            }
            else  //矩形
            {
                disp_message(3600, "请画一个矩形", "image", 12, 12, "red", "true");
                HOperatorSet.DrawRectangle1(3600, out hv_Row11, out hv_Column11, out hv_Row21,
                    out hv_Column21);
                ho_Circle.Dispose();
                HOperatorSet.GenRectangle1(out ho_Circle, hv_Row11, hv_Column11, hv_Row21,
                    hv_Column21);
                HOperatorSet.AreaCenter(ho_Circle, out hv_Area, out hv_Row, out hv_Column);
            }
            ho_ImageReduced.Dispose();
            HOperatorSet.ReduceDomain(ho_Image, ho_Circle, out ho_ImageReduced);
            HOperatorSet.CreateScaledShapeModel(ho_ImageReduced, modelParamers.NumLevels, (new HTuple(modelParamers.AngleStart)).TupleRad(), (new HTuple(modelParamers.AngleExtent)).TupleRad(), "auto", 0.9, 1.1, "auto", "auto", "use_polarity",
                ((new HTuple(modelParamers.MinContrast)).TupleConcat(modelParamers.MinContrast)).TupleConcat(modelParamers.MinNum), modelParamers.MinContrastThres, out ModelID);
            ho_ModelContours.Dispose();
            HOperatorSet.GetShapeModelContours(out ho_ModelContours, ModelID, 1);
            HOperatorSet.VectorAngleToRigid(0, 0, 0, hv_Row, hv_Column, 0, out hv_HomMat2D);
        HOperatorSet.AffineTransContourXld(ho_ModelContours, out ho_ModelContours,
            hv_HomMat2D);

            modelParamers.ModelContours = ho_ModelContours;
            modelParamers.CreateModelRow = hv_Row;
            modelParamers.CreateModelColumn = hv_Column;
        }
        #endregion
        #region 保存模板
        public void SaveModel(HTuple model, string fileName)
        {
            if (model != null)
            {
                HOperatorSet.WriteShapeModel(model, fileName);
            }
        }
        #endregion
        #region 打开模板
        public HTuple ReadModel(string fileName)
        {
            HTuple hv_ModelID;
            HOperatorSet.ReadShapeModel(fileName, out hv_ModelID);
            return hv_ModelID;
        }
        #endregion
        #region 查找模板
        public void FindCrossModel(HObject image, HTuple hv_ModelID, ref ModelParamers modelParamers)
        {
            HObject ho_Rectangle = new HObject();
            HTuple hv_Row1, hv_Column1, hv_Angle, hv_Scale, hv_Score;
            //查找模板
            ho_Rectangle.Dispose();
            HOperatorSet.GenRectangle1(out ho_Rectangle, modelParamers.FindAreaRowLeft, modelParamers.FindAreaColumnLeft, modelParamers.FindAreaRowRight, modelParamers.FindAreaColumnRight);
            HOperatorSet.ReduceDomain(image, ho_Rectangle, out image);
            HOperatorSet.FindScaledShapeModel(image, hv_ModelID, (new HTuple(modelParamers.AngleStart)).TupleRad(), (new HTuple(modelParamers.AngleExtent)).TupleRad(), modelParamers.ScaleMin, modelParamers.ScaleMax, modelParamers.MinScore,
                1, 0.5, "least_squares", (new HTuple(5)).TupleConcat(0), 0.7, out hv_Row1, out hv_Column1, out hv_Angle, out hv_Scale, out hv_Score);
            modelParamers.FindModelRow = hv_Row1;
            modelParamers.FindModelColumn = hv_Column1;
            modelParamers.FindModelAngle = hv_Angle;

            hv_Row1 = null; hv_Column1 = null; hv_Angle = null; hv_Scale = null; hv_Score = null;
        }
        #endregion
        #region 变换模板位置
        public void GetModelContour(HTuple hv_ModelID, ref ModelParamers modelParamers)
        {
            HTuple hv_Mat2D;
            HObject ho_ContoursAffinTrans = new HObject(), ho_ModelContours1 = new HObject();
            ho_ModelContours1.Dispose();
            HOperatorSet.GetShapeModelContours(out ho_ModelContours1, hv_ModelID, 1);
            HOperatorSet.VectorAngleToRigid(0, 0, 0, modelParamers.FindModelRow, modelParamers.FindModelColumn, modelParamers.FindModelAngle, out hv_Mat2D);
            ho_ContoursAffinTrans.Dispose();
            HOperatorSet.AffineTransContourXld(ho_ModelContours1, out ho_ContoursAffinTrans,
                hv_Mat2D);

            modelParamers.ModelContours = ho_ContoursAffinTrans;
            hv_Mat2D = null;
        }
        #endregion
        #region 查找区域
        public void CreateFindModelArea(ref ModelParamers modelParamers)
        {
            HTuple hv_Row, hv_Column, hv_Row1, hv_Column1;
            disp_message(3600, "请画一个矩形", "image", 12, 12, "red", "true");
            HOperatorSet.DrawRectangle1(3600, out hv_Row, out hv_Column, out hv_Row1,
                out hv_Column1);
            modelParamers.FindAreaRowLeft = hv_Row;
            modelParamers.FindAreaColumnLeft = hv_Column;
            modelParamers.FindAreaRowRight = hv_Row1;
            modelParamers.FindAreaColumnRight = hv_Column1;
            hv_Row = null; hv_Column = null; hv_Row1 = null; hv_Column1 = null;
        }
        #endregion
        #region 旋转中心找圆心
        public void FindCircleCenter(HObject image, out CircleCenterParam CenterPara)
        {
            //拟合圆
            ho_Regions = new HObject();
            HObject ho_RegionTrans = new HObject(), ho_ImageResult = new HObject(), ho_RegionDilation = new HObject(), ho_ImageReduced = new HObject(), ho_Edges = new HObject(), ho_SelectedXLD = new HObject(), ho_Cross = new HObject(), ho_ImageMedian = new HObject(), ho_ConnectedRegions = new HObject(), ho_SelectedRegions = new HObject();
            HTuple hv_Area, hv_Row, hv_Column, hv_PointOrder;
            ho_ImageMedian.Dispose();
            HOperatorSet.MedianImage(image, out ho_ImageMedian, "circle", 20, "mirrored");
            ho_Regions.Dispose();
            HOperatorSet.Threshold(ho_ImageMedian, out ho_Regions, 10, 120);
            ho_ConnectedRegions.Dispose();
            HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
            ho_SelectedRegions.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions, out ho_SelectedRegions, "area",
                "and", 240994, 5000000);
            ho_RegionTrans.Dispose();
            HOperatorSet.ShapeTrans(ho_SelectedRegions, out ho_RegionTrans, "convex");
            ho_ImageResult.Dispose();
            HOperatorSet.PaintRegion(ho_RegionTrans, image, out ho_ImageResult,
                5, "fill");
            ho_RegionDilation.Dispose();
            HOperatorSet.DilationCircle(ho_Regions, out ho_RegionDilation, 20);
            ho_ImageReduced.Dispose();
            HOperatorSet.ReduceDomain(ho_ImageResult, ho_RegionDilation, out ho_ImageReduced
                );
            ho_Edges.Dispose();
            HOperatorSet.EdgesSubPix(ho_ImageReduced, out ho_Edges, "canny", 10, 10, 60);
            ho_SelectedXLD.Dispose();
            HOperatorSet.SelectShapeXld(ho_Edges, out ho_SelectedXLD, (new HTuple("circularity")).TupleConcat(
                "contlength"), "and", (new HTuple(0.29899)).TupleConcat(995.58), (new HTuple(1)).TupleConcat(
                5000));
            HOperatorSet.AreaCenterXld(ho_SelectedXLD, out hv_Area, out hv_Row, out hv_Column,
                out hv_PointOrder);
            ho_Cross.Dispose();
            HOperatorSet.GenCrossContourXld(out ho_Cross, hv_Row, hv_Column, 36, 0);

            cCenterPara.CircleRow = hv_Row;
            cCenterPara.CircleColumn = hv_Column;
            cCenterPara.CircleContour = ho_SelectedXLD;
            cCenterPara.Cross = ho_Cross;
            CenterPara = cCenterPara;
        }
        #endregion
        #region 显示旋转中心轮廓
        public void ShowCirCleCenterContours(CircleCenterParam CentPara, HTuple hwin)
        {
            if (CentPara.Cross != null)
            {
                HOperatorSet.SetLineWidth(hwin, 3);
                HOperatorSet.SetColor(hwin, "green");
                //显示轮廓
                HOperatorSet.DispObj(CentPara.CircleContour, hwin);
                HOperatorSet.DispObj(CentPara.Cross, hwin);
            }
        }
        #endregion
        #region 阀位置标定找圆心
        public void FindValveCircle(HObject image, out CalibraValveParam cvp)
        {
            cvp = null;
            cvp = new CalibraValveParam();
            //拟合圆
            ho_Regions = new HObject();
            HObject ho_RegionTrans = new HObject(), ho_ImageResult = new HObject(), ho_RegionDilation = new HObject(), ho_ImageReduced = new HObject(), ho_Edges = new HObject(), ho_SelectedXLD = new HObject(), ho_Cross = new HObject(), ho_ImageMedian = new HObject(), ho_ConnectedRegions = new HObject(), ho_SelectedRegions = new HObject();
            HTuple hv_Area, hv_Row, hv_Column, hv_PointOrder;
            ho_ImageMedian.Dispose();
            HOperatorSet.MedianImage(image, out ho_ImageMedian, "circle", 20, "mirrored");
            ho_Regions.Dispose();
            HOperatorSet.Threshold(ho_ImageMedian, out ho_Regions, 10, 120);
            ho_ConnectedRegions.Dispose();
            HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
            ho_SelectedRegions.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions, out ho_SelectedRegions, "area",
                "and", 240994, 5000000);
            ho_RegionTrans.Dispose();
            HOperatorSet.ShapeTrans(ho_SelectedRegions, out ho_RegionTrans, "convex");
            ho_ImageResult.Dispose();
            HOperatorSet.PaintRegion(ho_RegionTrans, image, out ho_ImageResult,
                5, "fill");
            ho_RegionDilation.Dispose();
            HOperatorSet.DilationCircle(ho_Regions, out ho_RegionDilation, 20);
            ho_ImageReduced.Dispose();
            HOperatorSet.ReduceDomain(ho_ImageResult, ho_RegionDilation, out ho_ImageReduced
                );
            ho_Edges.Dispose();
            HOperatorSet.EdgesSubPix(ho_ImageReduced, out ho_Edges, "canny", 10, 10, 60);
            ho_SelectedXLD.Dispose();
            HOperatorSet.SelectShapeXld(ho_Edges, out ho_SelectedXLD, (new HTuple("circularity")).TupleConcat(
                "contlength"), "and", (new HTuple(0.29899)).TupleConcat(995.58), (new HTuple(1)).TupleConcat(
                5000));
            HOperatorSet.AreaCenterXld(ho_SelectedXLD, out hv_Area, out hv_Row, out hv_Column,
                out hv_PointOrder);
            ho_Cross.Dispose();
            HOperatorSet.GenCrossContourXld(out ho_Cross, hv_Row, hv_Column, 36, 0);


            cvp.CircleCenterRow = hv_Row;
            cvp.CircleCenterColumn = hv_Column;
            cvp.CircleContour = ho_SelectedXLD;
            cvp.CircleCenterContour = ho_Cross;
        }
        
        #endregion
        #region 选择模板中心
        public void SetModelCenter(ref HTuple ModelID, ref ModelParamers modelParam, HTuple Hwin)
        {
            HTuple hv_Row1, hv_Column1;
            //画点
            HOperatorSet.DrawPoint(Hwin, out hv_Row1, out hv_Column1);
            //显示点位置的十字
            HOperatorSet.SetLineWidth(Hwin, 3);
            HOperatorSet.SetColor(Hwin, "green");
            //显示轮廓
            HOperatorSet.SetLineWidth(Hwin, 1);
            HOperatorSet.SetColor(Hwin, "green");
            HOperatorSet.DispCross(Hwin, hv_Row1, hv_Column1, 12, 0);
            //设置模板中心偏移量
            double offSetX = hv_Row1 - modelParam.CreateModelRow;
            double offSetY = hv_Column1 - modelParam.CreateModelColumn;
            HOperatorSet.SetShapeModelOrigin(ModelID, offSetX, offSetY);
            modelParam.CreateModelRow = hv_Row1;
            modelParam.CreateModelColumn = hv_Column1;
        }
        #endregion
        #region 显示旋转中心点
        public void DrawCircleCenter(HTuple Hwin, HTuple hv_Row1, HTuple hv_Column1)
        {
            //显示点位置的十字
            HOperatorSet.SetLineWidth(Hwin, 3);
            HOperatorSet.SetColor(Hwin, "green");
            HOperatorSet.DispCross(Hwin, hv_Row1, hv_Column1, 12, 0);
        }
        #endregion
        #region 抓针阀的圆获得针阀的位置
        public void GetValvePosition(HObject image, out double[] valvePosition)
        {
            valvePosition = new double[2];
            valvePosition[0] = 0;
            valvePosition[1] = 0;
        }
        #endregion

        #region Halcon算子
        public void disp_message(HTuple hv_WindowHandle, HTuple hv_String, HTuple hv_CoordSystem,
    HTuple hv_Row, HTuple hv_Column, HTuple hv_Color, HTuple hv_Box)
        {



            // Local iconic variables 

            // Local control variables 

            HTuple hv_Red = null, hv_Green = null, hv_Blue = null;
            HTuple hv_Row1Part = null, hv_Column1Part = null, hv_Row2Part = null;
            HTuple hv_Column2Part = null, hv_RowWin = null, hv_ColumnWin = null;
            HTuple hv_WidthWin = null, hv_HeightWin = null, hv_MaxAscent = null;
            HTuple hv_MaxDescent = null, hv_MaxWidth = null, hv_MaxHeight = null;
            HTuple hv_R1 = new HTuple(), hv_C1 = new HTuple(), hv_FactorRow = new HTuple();
            HTuple hv_FactorColumn = new HTuple(), hv_UseShadow = null;
            HTuple hv_ShadowColor = null, hv_Exception = new HTuple();
            HTuple hv_Width = new HTuple(), hv_Index = new HTuple();
            HTuple hv_Ascent = new HTuple(), hv_Descent = new HTuple();
            HTuple hv_W = new HTuple(), hv_H = new HTuple(), hv_FrameHeight = new HTuple();
            HTuple hv_FrameWidth = new HTuple(), hv_R2 = new HTuple();
            HTuple hv_C2 = new HTuple(), hv_DrawMode = new HTuple();
            HTuple hv_CurrentColor = new HTuple();
            HTuple hv_Box_COPY_INP_TMP = hv_Box.Clone();
            HTuple hv_Color_COPY_INP_TMP = hv_Color.Clone();
            HTuple hv_Column_COPY_INP_TMP = hv_Column.Clone();
            HTuple hv_Row_COPY_INP_TMP = hv_Row.Clone();
            HTuple hv_String_COPY_INP_TMP = hv_String.Clone();

            // Initialize local and output iconic variables 
            //This procedure displays text in a graphics window.
            //
            //Input parameters:
            //WindowHandle: The WindowHandle of the graphics window, where
            //   the message should be displayed
            //String: A tuple of strings containing the text message to be displayed
            //CoordSystem: If set to 'window', the text position is given
            //   with respect to the window coordinate system.
            //   If set to 'image', image coordinates are used.
            //   (This may be useful in zoomed images.)
            //Row: The row coordinate of the desired text position
            //   If set to -1, a default value of 12 is used.
            //Column: The column coordinate of the desired text position
            //   If set to -1, a default value of 12 is used.
            //Color: defines the color of the text as string.
            //   If set to [], '' or 'auto' the currently set color is used.
            //   If a tuple of strings is passed, the colors are used cyclically
            //   for each new textline.
            //Box: If Box[0] is set to 'true', the text is written within an orange box.
            //     If set to' false', no box is displayed.
            //     If set to a color string (e.g. 'white', '#FF00CC', etc.),
            //       the text is written in a box of that color.
            //     An optional second value for Box (Box[1]) controls if a shadow is displayed:
            //       'true' -> display a shadow in a default color
            //       'false' -> display no shadow (same as if no second value is given)
            //       otherwise -> use given string as color string for the shadow color
            //
            //Prepare window
            HOperatorSet.GetRgb(hv_WindowHandle, out hv_Red, out hv_Green, out hv_Blue);
            HOperatorSet.GetPart(hv_WindowHandle, out hv_Row1Part, out hv_Column1Part, out hv_Row2Part,
                out hv_Column2Part);
            HOperatorSet.GetWindowExtents(hv_WindowHandle, out hv_RowWin, out hv_ColumnWin,
                out hv_WidthWin, out hv_HeightWin);
            HOperatorSet.SetPart(hv_WindowHandle, 0, 0, hv_HeightWin - 1, hv_WidthWin - 1);
            //
            //default settings
            if ((int)(new HTuple(hv_Row_COPY_INP_TMP.TupleEqual(-1))) != 0)
            {
                hv_Row_COPY_INP_TMP = 12;
            }
            if ((int)(new HTuple(hv_Column_COPY_INP_TMP.TupleEqual(-1))) != 0)
            {
                hv_Column_COPY_INP_TMP = 12;
            }
            if ((int)(new HTuple(hv_Color_COPY_INP_TMP.TupleEqual(new HTuple()))) != 0)
            {
                hv_Color_COPY_INP_TMP = "";
            }
            //
            hv_String_COPY_INP_TMP = ((("" + hv_String_COPY_INP_TMP) + "")).TupleSplit("\n");
            //
            //Estimate extentions of text depending on font size.
            HOperatorSet.GetFontExtents(hv_WindowHandle, out hv_MaxAscent, out hv_MaxDescent,
                out hv_MaxWidth, out hv_MaxHeight);
            if ((int)(new HTuple(hv_CoordSystem.TupleEqual("window"))) != 0)
            {
                hv_R1 = hv_Row_COPY_INP_TMP.Clone();
                hv_C1 = hv_Column_COPY_INP_TMP.Clone();
            }
            else
            {
                //Transform image to window coordinates
                hv_FactorRow = (1.0 * hv_HeightWin) / ((hv_Row2Part - hv_Row1Part) + 1);
                hv_FactorColumn = (1.0 * hv_WidthWin) / ((hv_Column2Part - hv_Column1Part) + 1);
                hv_R1 = ((hv_Row_COPY_INP_TMP - hv_Row1Part) + 0.5) * hv_FactorRow;
                hv_C1 = ((hv_Column_COPY_INP_TMP - hv_Column1Part) + 0.5) * hv_FactorColumn;
            }
            //
            //Display text box depending on text size
            hv_UseShadow = 1;
            hv_ShadowColor = "gray";
            if ((int)(new HTuple(((hv_Box_COPY_INP_TMP.TupleSelect(0))).TupleEqual("true"))) != 0)
            {
                if (hv_Box_COPY_INP_TMP == null)
                    hv_Box_COPY_INP_TMP = new HTuple();
                hv_Box_COPY_INP_TMP[0] = "#fce9d4";
                hv_ShadowColor = "#f28d26";
            }
            if ((int)(new HTuple((new HTuple(hv_Box_COPY_INP_TMP.TupleLength())).TupleGreater(
                1))) != 0)
            {
                if ((int)(new HTuple(((hv_Box_COPY_INP_TMP.TupleSelect(1))).TupleEqual("true"))) != 0)
                {
                    //Use default ShadowColor set above
                }
                else if ((int)(new HTuple(((hv_Box_COPY_INP_TMP.TupleSelect(1))).TupleEqual(
                    "false"))) != 0)
                {
                    hv_UseShadow = 0;
                }
                else
                {
                    hv_ShadowColor = hv_Box_COPY_INP_TMP[1];
                    //Valid color?
                    try
                    {
                        HOperatorSet.SetColor(hv_WindowHandle, hv_Box_COPY_INP_TMP.TupleSelect(
                            1));
                    }
                    // catch (Exception) 
                    catch (HalconException HDevExpDefaultException1)
                    {
                        HDevExpDefaultException1.ToHTuple(out hv_Exception);
                        hv_Exception = "Wrong value of control parameter Box[1] (must be a 'true', 'false', or a valid color string)";
                        throw new HalconException(hv_Exception);
                    }
                }
            }
            if ((int)(new HTuple(((hv_Box_COPY_INP_TMP.TupleSelect(0))).TupleNotEqual("false"))) != 0)
            {
                //Valid color?
                try
                {
                    HOperatorSet.SetColor(hv_WindowHandle, hv_Box_COPY_INP_TMP.TupleSelect(0));
                }
                // catch (Exception) 
                catch (HalconException HDevExpDefaultException1)
                {
                    HDevExpDefaultException1.ToHTuple(out hv_Exception);
                    hv_Exception = "Wrong value of control parameter Box[0] (must be a 'true', 'false', or a valid color string)";
                    throw new HalconException(hv_Exception);
                }
                //Calculate box extents
                hv_String_COPY_INP_TMP = (" " + hv_String_COPY_INP_TMP) + " ";
                hv_Width = new HTuple();
                for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_String_COPY_INP_TMP.TupleLength()
                    )) - 1); hv_Index = (int)hv_Index + 1)
                {
                    HOperatorSet.GetStringExtents(hv_WindowHandle, hv_String_COPY_INP_TMP.TupleSelect(
                        hv_Index), out hv_Ascent, out hv_Descent, out hv_W, out hv_H);
                    hv_Width = hv_Width.TupleConcat(hv_W);
                }
                hv_FrameHeight = hv_MaxHeight * (new HTuple(hv_String_COPY_INP_TMP.TupleLength()
                    ));
                hv_FrameWidth = (((new HTuple(0)).TupleConcat(hv_Width))).TupleMax();
                hv_R2 = hv_R1 + hv_FrameHeight;
                hv_C2 = hv_C1 + hv_FrameWidth;
                //Display rectangles
                HOperatorSet.GetDraw(hv_WindowHandle, out hv_DrawMode);
                HOperatorSet.SetDraw(hv_WindowHandle, "fill");
                //Set shadow color
                HOperatorSet.SetColor(hv_WindowHandle, hv_ShadowColor);
                if ((int)(hv_UseShadow) != 0)
                {
                    HOperatorSet.DispRectangle1(hv_WindowHandle, hv_R1 + 1, hv_C1 + 1, hv_R2 + 1, hv_C2 + 1);
                }
                //Set box color
                HOperatorSet.SetColor(hv_WindowHandle, hv_Box_COPY_INP_TMP.TupleSelect(0));
                HOperatorSet.DispRectangle1(hv_WindowHandle, hv_R1, hv_C1, hv_R2, hv_C2);
                HOperatorSet.SetDraw(hv_WindowHandle, hv_DrawMode);
            }
            //Write text.
            for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_String_COPY_INP_TMP.TupleLength()
                )) - 1); hv_Index = (int)hv_Index + 1)
            {
                hv_CurrentColor = hv_Color_COPY_INP_TMP.TupleSelect(hv_Index % (new HTuple(hv_Color_COPY_INP_TMP.TupleLength()
                    )));
                if ((int)((new HTuple(hv_CurrentColor.TupleNotEqual(""))).TupleAnd(new HTuple(hv_CurrentColor.TupleNotEqual(
                    "auto")))) != 0)
                {
                    HOperatorSet.SetColor(hv_WindowHandle, hv_CurrentColor);
                }
                else
                {
                    HOperatorSet.SetRgb(hv_WindowHandle, hv_Red, hv_Green, hv_Blue);
                }
                hv_Row_COPY_INP_TMP = hv_R1 + (hv_MaxHeight * hv_Index);
                HOperatorSet.SetTposition(hv_WindowHandle, hv_Row_COPY_INP_TMP, hv_C1);
                HOperatorSet.WriteString(hv_WindowHandle, hv_String_COPY_INP_TMP.TupleSelect(
                    hv_Index));
            }
            //Reset changed window settings
            HOperatorSet.SetRgb(hv_WindowHandle, hv_Red, hv_Green, hv_Blue);
            HOperatorSet.SetPart(hv_WindowHandle, hv_Row1Part, hv_Column1Part, hv_Row2Part,
                hv_Column2Part);

            return;
        }
        #endregion
    }
}
