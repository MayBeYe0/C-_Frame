﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HalconDotNet;

namespace ViewControl
{
    public partial class HalconView : UserControl
    {
        //缩放图片触发事件
        public delegate void HMouseDelegate(object sender);
        public event HMouseDelegate HMouseWheelEvent;
        private void OnHMouseWheelEvent()
        {   //定义一个局部变量，将事件对象赋值给该变量，防止多线程情况取消事件
            HMouseDelegate mEvent = HMouseWheelEvent;
            if (mEvent != null)
                mEvent(this);//事件触发
        }
        #region 属性字段
        private HObject ho_img;//显示图片
        public HObject Image 
        { 
            get
            {
                return ho_img;
            }
            set
            {
                ho_img = value;
            }
        }
        private HWindow hwin1;
        //图像缩放
        public bool IsZoom = true;
        private halconWindow wch = new halconWindow();
        bool flag_but_down = false;  //是否移动图像
        HTuple btn_down_row = 0;
        HTuple btn_down_col = 0;
        HTuple btn_state = 0;
        #endregion
        public HalconView()
        {
            InitializeComponent();
            hwin1 = hWindowControl1.HalconWindow;
        }
        public HWindowControl HWindowControl
        {
            get
            {
                return this.hWindowControl1;
            }
            set
            { }
        }
        public HWindow HalconWindow
        {
            get { return this.hwin1; }
            set { }
        }
        public void DispImage(HObject img)
        {
            if (ho_img != null)
            {
                ho_img.Dispose();  //释放图片内存
            }
            HOperatorSet.CopyImage(img, out ho_img);
            HOperatorSet.DispObj(ho_img, hwin1);
        }
        #region 图像缩放
        private void hWindowControl1_HMouseWheel(object sender, HMouseEventArgs e)
        {
            if (IsZoom)  //是否缩放
            {
                if (ho_img == null) return;
                HTuple mode = e.Delta;
                HTuple button_state;
                HTuple mouse_post_row, mouse_pose_col;
                try
                {
                    HOperatorSet.GetMposition(hWindowControl1.HalconWindow, out mouse_post_row, out mouse_pose_col, out button_state);
                }
                catch
                {
                    return;
                }
                wch.DispImageZoom(ho_img, hWindowControl1, mode, mouse_post_row, mouse_pose_col);
                OnHMouseWheelEvent();
            }
        }
        private void hWindowControl1_HMouseMove(object sender, HMouseEventArgs e)
        {
            if (IsZoom)  //是否缩放
            {
                if (ho_img == null) return;
                if (flag_but_down) { wch.DispImageMove(ho_img, hWindowControl1, btn_down_row, btn_down_col); }
                else
                {
                    return;
                }
                OnHMouseWheelEvent();
            }
        }
        private void hWindowControl1_HMouseDown(object sender, HMouseEventArgs e)
        {
            if (IsZoom)  //是否缩放
            {
                flag_but_down = true;
                if (ho_img == null) return;
                try
                {
                    HOperatorSet.GetMposition(hWindowControl1.HalconWindow, out btn_down_row, out btn_down_col, out btn_state);
                }
                catch
                {
                    return;
                } 
            }
        }
        private void hWindowControl1_HMouseUp(object sender, HMouseEventArgs e)
        {
            if (IsZoom)  //是否缩放
            {
                flag_but_down = false;  
            }
        }
        #endregion
        #region 图像自适应
        private void bt_adaptative_Click(object sender, EventArgs e)
        {
            wch.DispImageFit(ho_img, hWindowControl1); 
        }
        #endregion

    }
}
