﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;
using System.Windows.Forms;

namespace ViewControl
{
    public class halconWindow
    {
        private int current_beginRow, current_beginCol, current_endRow, current_endCol;
        private int zoom_beginRow, zoom_beginCol, zoom_endRow, zoom_endCol;
        public HTuple X = new HTuple();
        public HTuple Y = new HTuple();
        public void DispImageFit(HObject t_image, HWindowControl hw_ctrl)
        {
            if (t_image != null)
            {
                hw_ctrl.HalconWindow.ClearWindow();
                HTuple hWindowHandle = hw_ctrl.HalconWindow;
                HTuple hw_width;
                HTuple hw_height;
                HOperatorSet.GetImageSize(t_image, out hw_width, out hw_height);
                //int hw_width = hw_ctrl.Size.Width;
                //int hw_height = hw_ctrl.Size.Height;

                HTuple width, height;
                HOperatorSet.GetImageSize(t_image, out width, out height);
                if (1.0 * width[0].I / hw_width > 1.0 * height[0].I / hw_height)
                {
                    double real = 1.0 * width[0].I / hw_width;
                    HOperatorSet.SetPart(hWindowHandle, 0, 0, real * hw_height, real * hw_width);
                    //X = real * hw_width;
                    //Y = real * hw_height;
                    HOperatorSet.DispObj(t_image, hWindowHandle);
                }
                else
                {
                    double real = 1.0 * height[0].I / hw_height;
                    HOperatorSet.SetPart(hWindowHandle, 0, 0, real * hw_height, real * hw_width);
                    //X = real * hw_width;
                    //Y = real * hw_height;
                    HOperatorSet.DispObj(t_image, hWindowHandle);
                }
            }
        }
        public void DispImageMove(HObject image, HWindowControl hw_ctrl, int btn_down_row, int btn_down_col)
        {
            if (image == null) return;
            try
            {
                int current_beginRow, current_beginCol, current_endRow, current_endCol, mouse_post_row, mouse_pose_col, button_state;
                hw_ctrl.HalconWindow.GetPart(out current_beginRow, out current_beginCol, out current_endRow, out current_endCol);
                hw_ctrl.HalconWindow.GetMposition(out mouse_post_row, out mouse_pose_col, out button_state);
                hw_ctrl.HalconWindow.SetPaint(new HTuple("default"));
                hw_ctrl.HalconWindow.SetPart(current_beginRow + btn_down_row - mouse_post_row, current_beginCol + btn_down_col - mouse_pose_col, current_endRow + btn_down_row - mouse_post_row, current_endCol + btn_down_col - mouse_pose_col);
                //hWindowControl1.HalconWindow.ClearWindow();
                //hWindowControl1.HalconWindow.DispObj(image);
                //hWindowControl1.HalconWindow.GetMposition(out btn_down_row, out btn_down_col, out btn_state);
                HOperatorSet.SetSystem("flush_graphic", "false");
                HOperatorSet.ClearWindow(hw_ctrl.HalconWindow);
                HOperatorSet.SetSystem("flush_graphic", "true");
                HOperatorSet.DispObj(image, hw_ctrl.HalconWindow);
                hw_ctrl.HalconWindow.GetPart(out current_beginRow, out current_beginCol, out current_endRow, out current_endCol);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void DispImageZoom(HObject t_image, HWindowControl hw_ctrl, HTuple mode, double Mouse_row, double Mouse_col)
        {
            if (t_image != null)
            {
                HTuple width, height;
                HOperatorSet.GetImageSize(t_image, out width, out height);
                int hv_imageWidth, hv_imageHeight;
                hv_imageWidth = width;
                hv_imageHeight = height;
                try
                {
                    hw_ctrl.HalconWindow.GetPart(out current_beginRow, out current_beginCol, out current_endRow, out current_endCol);
                }
                catch (Exception)
                {
                    return;
                }
                if (mode > 0)//图像放大
                {
                    zoom_beginRow = (int)(current_beginRow + (Mouse_row - current_beginRow) * 0.100d);
                    zoom_beginCol = (int)(current_beginCol + (Mouse_col - current_beginCol) * 0.100d);
                    zoom_endRow = (int)(current_endRow - (current_endRow - Mouse_row) * 0.100d);
                    zoom_endCol = (int)(current_endCol - (current_endCol - Mouse_col) * 0.100d);
                }
                else//图像缩小
                {
                    zoom_beginRow = (int)(Mouse_row - (Mouse_row - current_beginRow) / 0.900d);
                    zoom_beginCol = (int)(Mouse_col - (Mouse_col - current_beginCol) / 0.900d);
                    zoom_endRow = (int)(Mouse_row + (current_endRow - Mouse_row) / 0.900d);
                    zoom_endCol = (int)(Mouse_col + (current_endCol - Mouse_col) / 0.900d);
                }

                try
                {
                    int hw_width, hw_height;
                    hw_width = hw_ctrl.WindowSize.Width;
                    hw_height = hw_ctrl.WindowSize.Height;

                    bool _isOutOfArea = true;
                    bool _isOutOfSize = true;
                    bool _isOutOfPixel = true;//避免像素过大

                    _isOutOfArea = zoom_beginRow >= hv_imageHeight || zoom_beginRow >= hv_imageWidth || zoom_endRow <= 0 || zoom_endCol <= 0;
                    _isOutOfSize = (zoom_endRow - zoom_beginRow) > hv_imageHeight * 3 || (zoom_endCol - zoom_beginCol) > hv_imageWidth * 3;
                    _isOutOfPixel = hw_height / (zoom_endRow - zoom_beginRow) > 30 || hw_width / (zoom_endCol - zoom_beginCol) > 30;

                    if (_isOutOfArea || _isOutOfSize)
                    {
                        DispImageFit(t_image, hw_ctrl);
                        //HOperatorSet.SetSystem("flush_graphic", "false");
                        //hw_ctrl.HalconWindow.ClearWindow();
                        //HOperatorSet.SetSystem("flush_graphic", "true");
                        //hw_ctrl.HalconWindow.SetPaint(new HTuple("default"));
                        //hw_ctrl.HalconWindow.SetPart(zoom_beginRow, zoom_beginCol, zoom_endRow, zoom_endCol);
                    }
                    else if (!_isOutOfPixel)
                    {
                        HOperatorSet.SetSystem("flush_graphic", "false");
                        hw_ctrl.HalconWindow.ClearWindow();
                        HOperatorSet.SetSystem("flush_graphic", "true");
                        hw_ctrl.HalconWindow.SetPaint(new HTuple("default"));
                        hw_ctrl.HalconWindow.SetPart(zoom_beginRow, zoom_beginCol, zoom_endRow, zoom_endCol);
                        //hw_ctrl.HalconWindow.DispObj(t_image);
                    }
                }
                catch (Exception)
                {
                    DispImageFit(t_image, hw_ctrl);
                    //throw;
                }

            }

        }
    }
}
