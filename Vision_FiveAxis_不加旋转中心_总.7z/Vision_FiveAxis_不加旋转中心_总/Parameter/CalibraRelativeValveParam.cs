﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parameter
{
    [Serializable]
    public class CalibraRelativeValveParam
    {
        //针头记录标准位置X坐标
        public double ValveStandX = 0;
        //针头记录标准位置Y坐标
        public double ValveStandY = 0;
        //针头实际X坐标
        public double ValveRealX = 0;
        //针头实际Y坐标
        public double ValveRealY = 0;
        //针头补偿偏移量X
        public double OffsetX = 0;
        //针头补偿偏移量Y
        public double OffsetY = 0;
    }
}
