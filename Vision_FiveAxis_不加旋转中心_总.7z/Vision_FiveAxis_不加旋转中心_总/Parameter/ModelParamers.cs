﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;

namespace Parameter
{
    [Serializable]
    public class ModelParamers
    {
        public int MinContrast { get; set; }  //最小灰度值
        public int MaxContrast { get; set; }  //最大灰度值
        public int MinContrastThres { get; set; }  //最小对比度
        public double ScaleMin { get; set; }  //最小缩放比例
        public double ScaleMax { get; set; }  //最大缩放比例
        public double MinScore { get; set; }  //最小分数
        public HTuple NumLevels { get; set; }  //金字塔层数
        public int MinNum { get; set; }  //最小组件数
        public int AngleStart { get; set; }  //起始角度
        public int AngleExtent { get; set; }  //角度范围
        public HObject ModelContours;  //模板轮廓
        
        //模板区域的中心坐标
        public HTuple CreateModelRow;  //创建模板的区域中心横坐标
        public HTuple CreateModelColumn;  //创建模板的区域中心列坐标
        public double CreateModelX;  //创建模板的区域中心X世界坐标
        public double CreateModelY;  //创建模板的区域中心Y世界坐标
        public string CreateModelHexX;  //创建模板的区域中心X 16进制
        public string CreateModelHexY;  //创建模板的区域中心Y 16进制
        public double CreateModelToValveX;  //创建模板的中心对应阀的X世界坐标
        public double CreateModelToValveY;  //创建模板的中心对应阀的Y世界坐标
        public double ModelOffsetX = 0;  //模板中心X补偿量
        public double ModelOffsetY = 0;  //模板中心Y补偿量
        public double DetX = 0;
        public double DetY = 0;
        [NonSerialized]
        public HTuple FindModelRow;  //查找模板的区域中心横坐标
        [NonSerialized]
        public HTuple FindModelColumn;  //查找模板的区域中心列坐标
        [NonSerialized]
        public HTuple FindModelAngle;  //查找模板的区域中心的角度
        //模板偏移量
        [NonSerialized]
        public double OffsetX;  //模板的实际X偏差
        [NonSerialized]
        public double OffsetY;  //模板的实际Y偏差
        [NonSerialized]
        public string OffsetHexX;  //模板的16进制实际X偏差
        [NonSerialized]
        public string OffsetHexY;  //模板的16进制实际Y偏差
        [NonSerialized]
        public string OffsetHexU;  //模板的16进制实际U偏差
        //模板查找区域
        public HTuple FindAreaRowLeft;  //查找区域的左上横坐标
        public HTuple FindAreaColumnLeft;  //查找区域的左上纵坐标
        public HTuple FindAreaRowRight;  //查找区域的右下横坐标
        public HTuple FindAreaColumnRight;  //查找区域的右下纵坐标

        //模板结果
        [NonSerialized]
        public bool ModelResult;  //模板结果
        
        public ModelParamers()
        {
            MinContrast = 35;
            MaxContrast = 45;
            MinContrastThres = 5;
            ScaleMin = 0.9;
            ScaleMax = 1.1;
            MinScore = 0.5;
            NumLevels = "auto";
            MinNum = 20;
            AngleStart = -45;
            AngleExtent = 90;
            FindAreaRowLeft = 0;
            FindAreaColumnLeft = 0;
            FindAreaRowRight = 3000;
            FindAreaColumnRight = 3000;
            ModelResult = false;
        }

    }
}
