﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parameter
{
    [Serializable]
    public class CalibraHeightCheckParam
    {
        //是否启用高度防呆
        public bool isHeightCheck = false;
        //标准高度
        public double HeightNormol;
        //高度上限
        public double HeightUpp;
        //高度下限
        public double HeightDown;

    }
}
