﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parameter
{
    [Serializable]
    public class CalibraAAxisParam
    {
        public bool isAAxisCheck = false;  //是否开启A轴校正功能
        public double Height1 = 0;  //位置1的高度值
        public double Height2 = 0;  //位置2的高度值
        public double MechanY1 = 0;  //位置1的世界Y坐标
        public double MechanY2 = 1;  //位置2的世界Y坐标
        public double Angle = -10000;  //模板角度
    }
}
