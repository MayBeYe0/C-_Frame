﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;

namespace Parameter
{
    public class PosInfo
    {
        public HTuple Rows  { get; set; }//像素行坐标
        public HTuple Columns { get; set; }//像素列坐标
        public HObject RegionObjs { get; set; }//区域
        public HTuple CountsObj  { get; set; }//个数
        public HTuple EnX { get; set; } //实际X位置
        public HTuple EnY { get; set; } //实际Y位置
        public HObject  Contours { get; set; }//轮廓
        public HTuple  Angles { get; set; }//角度
        public HObject CircleContours { get; set; }//圆形轮廓
        public HObject CrossContours { get; set; }//十字中心
        public HTuple ModelIndex  { get; set; }//模型索引
        public PosInfo()
        {
            CountsObj = 0;
            Rows = new HTuple();
            Columns = new HTuple();
            EnX = new HTuple();
            EnY = new HTuple();
        }
    }
}
