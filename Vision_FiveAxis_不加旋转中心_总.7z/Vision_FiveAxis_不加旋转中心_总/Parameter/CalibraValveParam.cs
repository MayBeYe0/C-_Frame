﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;

namespace Parameter
{
    public class CalibraValveParam
    {
        public HTuple CircleCenterRow = new HTuple();  //圆心的横坐标
        public HTuple CircleCenterColumn = new HTuple();  //圆心的纵坐标
        public double CircleCenterX = 0;  //圆心的X世界坐标
        public double CircleCenterY = 0;  //圆心的Y世界坐标
        public HObject CircleContour = new HObject();  //圆的轮廓
        public HObject CircleCenterContour = new HObject();  //圆的中心
    }
}
