﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;

namespace Parameter
{
    [Serializable]
    public class CircleCenterParam
    {
        public HTuple CircleRow { get; set; }  //拟合圆的行坐标像素
        public HTuple CircleColumn { get; set; }  //拟合圆的列坐标像素
        public HTuple EnX { get; set; }  //拟合圆的X坐标世界
        public HTuple EnY { get; set; }  //拟合圆的Y坐标世界
        public HTuple CircleCenterRow { get; set; }  //圆心的行坐标像素
        public HTuple CircleCenterColumn { get; set; }  //圆心的列坐标像素
        public HTuple CircleCenterX { get; set; }  //圆心的行坐标世界
        public HTuple CircleCenterY { get; set; }  //圆心的列坐标世界
        public HTuple CircleRadius { get; set; }  //圆的半径像素
        public HTuple CircleRadiusWor { get; set; }  //圆的半径像素
        public HObject CircleContour { get; set; }  //拟合圆的轮廓
        public HObject Cross { get; set; }  //中心十字
        public CircleCenterParam()
        {
            EnX = new HTuple();
            EnY = new HTuple();
            CircleContour = new HObject();
            Cross = new HObject();
        }
    }
}
