﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parameter
{
    [Serializable]
    public class CalibraNinePointParam
    {
        public int MedianValue = 20;  //中值滤波参数
        public int MinArea = 240994;  //区域最小值
        public int MaxArea = 5000000;  //区域最大值
        public int MinGray = 10;  //最小灰度值
        public int MaxGray = 120;  //最大灰度值
    }
}
