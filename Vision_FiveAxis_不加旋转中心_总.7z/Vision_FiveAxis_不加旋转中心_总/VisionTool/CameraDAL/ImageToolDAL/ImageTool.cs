﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;

namespace VisionTool.ImageToolDAL
{
    public class ImageTool
    {
        public HWindowControl windowControl;
        public enum Tool
        {
            采集图像 = 0,

        }
        /// <summary>
        /// 工具运行
        /// </summary>
        public virtual void Run()
        {}

        /// <summary>
        /// 工具初始化
        /// </summary>
        public virtual void Ini()
        {}

        /// <summary>
        /// 工具名
        /// </summary>
        /// <returns></returns>
        public virtual string ToolName()
        {
            return "";
        }
    }
}
