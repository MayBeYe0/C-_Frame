﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VisionTool.ImageToolDAL
{
    public class FlowExecuteDAL
    {
        #region 工具声明
        AcqFifoTool acqFifoTool;
        #endregion
        #region 执行流程工具
        public void FlowExecute(ImageTool it)
        {
            if (it is AcqFifoTool)  //采集图像
            {
                acqFifoTool = it as AcqFifoTool;
                acqFifoTool.Run();
            }
        }
        #endregion
    }
}
