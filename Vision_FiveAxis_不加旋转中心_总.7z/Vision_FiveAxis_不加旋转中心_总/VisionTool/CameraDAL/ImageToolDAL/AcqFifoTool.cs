﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;
using System.Windows.Forms;
using System.Diagnostics;

namespace VisionTool.ImageToolDAL
{
    public class AcqFifoTool :ImageTool
    {
        #region 属性字段
        public long timer;
        public HObject outImage = new HObject();  //图像
        public string[] imgPaths;  //路径
        public string name;  //工具名称
        #endregion
        #region 运行一次
        public override void Run()
        {
            Stopwatch watch = new Stopwatch();
            watch.Start();
            toolRun();
            watch.Stop();
            timer = watch.ElapsedMilliseconds;
        }
        #endregion
        public override string ToolName()
        {
            return name;
        }
        #region 工具初始化
        public override void Ini()
        {
            name = Tool.采集图像.ToString();
        }
        #endregion
        #region 流程运行
        private void toolRun()
        {
            ReadImage();
        }
        #endregion
        #region 读取图片
        public void ReadImage()
        {
            for (int i = 0; i < imgPaths.Length; i++)
            {
                outImage.Dispose();
                HOperatorSet.ReadImage(out outImage, imgPaths[i]);
            }
        }
        #endregion
    }
}