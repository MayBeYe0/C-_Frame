﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Parameter;
using HalconDotNet;
using System.IO;
using System.Windows.Forms;

namespace MathCal
{
    public class mathCal
    {
        #region 九点标定矩阵
        public static HTuple NinePointCabli(PosInfo posInf)
        {
            HTuple hv_HomMat2D = null;
            if (posInf != null)
            {
                HOperatorSet.VectorToHomMat2d(posInf.Columns, posInf.Rows, posInf.EnX, posInf.EnY, out hv_HomMat2D);
            }
            return hv_HomMat2D;
        }
        #endregion
        #region 保存九点标定矩阵
        public static bool SaveNineHomMat2d(string path, HTuple HomMat2d)
        {
            if (path == null)
            {
                return false;
            }
            else
            {
                try
                {
                    HOperatorSet.WriteTuple(HomMat2d, path);
                    return true;

                }
                catch (Exception)
                {

                    return false;
                }
            }
        }
        #endregion
        #region 读取九点标定矩阵
        public static bool ReadCabliPointNine(string path, out HTuple HomMat2D)
        {
            HomMat2D = new HTuple();
            if (path != null && File.Exists(path))
            {
                try
                {
                    HOperatorSet.ReadTuple(path, out HomMat2D);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        #endregion
        #region 计算偏移量
        public void CalOffset(HTuple NineHomMat2D, ref ModelParamers modelPara)
        {
            HTuple hv_Qx1, hv_Qy1, hv_Qx2, hv_Qy2;
            //换算成世界坐标
            HOperatorSet.AffineTransPoint2d(NineHomMat2D, modelPara.CreateModelColumn, modelPara.CreateModelRow, out hv_Qx1, out hv_Qy1);
            HOperatorSet.AffineTransPoint2d(NineHomMat2D, modelPara.FindModelColumn, modelPara.FindModelRow, out hv_Qx2, out hv_Qy2);
            //计算偏移值
            modelPara.OffsetX = hv_Qx1 - hv_Qx2;
            modelPara.OffsetY = hv_Qy1 - hv_Qy2;

            hv_Qx1 = null; hv_Qy1 = null; hv_Qx2 = null; hv_Qy2 = null;
        }
        #endregion
        #region 计算模板中心世界坐标
        public void CalModelXY(HTuple NineHomMat2D, ref ModelParamers modelPara)
        {
            HTuple hv_Qx1, hv_Qy1;
            //换算成世界坐标
            HOperatorSet.AffineTransPoint2d(NineHomMat2D, modelPara.CreateModelColumn, modelPara.CreateModelRow, out hv_Qx1, out hv_Qy1);
            //传值
            modelPara.CreateModelX = hv_Qx1;
            modelPara.CreateModelY = hv_Qy1;
            hv_Qx1 = null; hv_Qy1 = null;
        }
        #endregion
        #region 偏差值换算成指令
        public void OffsetToHex(ref ModelParamers modelPara)
        {
            //X偏差
            int numX = Convert.ToInt32(modelPara.OffsetX * 100000);
            string HexX = Convert.ToString(numX, 16);
            if (HexX.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexX.Length; i++)
                {
                    result += "0";
                }
                result += HexX;
                modelPara.OffsetHexX = result;
            }
            else
            {
                modelPara.OffsetHexX = Convert.ToString(numX, 16);
            }
            //Y偏差
            int numY = Convert.ToInt32(modelPara.OffsetY * 100000);
            string HexY = Convert.ToString(numY, 16);
            if (HexY.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexY.Length; i++)
                {
                    result += "0";
                }
                result += HexY;
                modelPara.OffsetHexY = result;
            }
            else
            {
                modelPara.OffsetHexY = Convert.ToString(numY, 16);
            }
            //角度偏差
            HTuple radAngle = (new HTuple(modelPara.FindModelAngle)).TupleDeg();  //弧度转换成角度
            int numA = Convert.ToInt32(((double)radAngle) * 100000);
            string HexA = Convert.ToString(numA, 16);
            if (HexA.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexA.Length; i++)
                {
                    result += "0";
                }
                result += HexA;
                modelPara.OffsetHexU = result;
            }
            else
            {
                modelPara.OffsetHexU = Convert.ToString(numA, 16);
            }

            HexX = null; HexY = null; HexA = null;
        }
        #endregion
        #region A轴偏差值换算成指令
        public string AAngleToHex(double AAngle)
        {
            //角度偏差
            int numA = Convert.ToInt32(AAngle * 100000);
            string HexA = Convert.ToString(numA, 16);
            if (HexA.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexA.Length; i++)
                {
                    result += "0";
                }
                result += HexA;
                return result;
            }
            else
            {
                return Convert.ToString(numA, 16);
            }
        }
        #endregion
        #region 模板坐标换算成指令
        public void ModelCenterToHex(ref ModelParamers modelPara)
        {
            //X偏差
            int numX = Convert.ToInt32(modelPara.CreateModelToValveX * 100000);
            string HexX = Convert.ToString(numX, 16);
            if (HexX.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexX.Length; i++)
                {
                    result += "0";
                }
                result += HexX;
                modelPara.CreateModelHexX = result;
            }
            else
            {
                modelPara.CreateModelHexX = Convert.ToString(numX, 16);
            }
            //Y偏差
            int numY = Convert.ToInt32(modelPara.CreateModelToValveY * 100000);
            string HexY = Convert.ToString(numY, 16);
            if (HexY.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexY.Length; i++)
                {
                    result += "0";
                }
                result += HexY;
                modelPara.CreateModelHexY = result;
            }
            else
            {
                modelPara.CreateModelHexY = Convert.ToString(numY, 16);
            }

            HexX = null; HexY = null;
        }
        #endregion
        #region 保存模板
        public void WriteModel(HTuple model)
        {
            //选择文件
            string fileName = "";
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Title = "请选择文件";
            fileDialog.Filter = "所有文件(*.*)|*.shm*";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = fileDialog.FileName;
            }
            //保存文件
            if (model != null)
            {
                HOperatorSet.WriteShapeModel(model, fileName);
            }
            fileDialog.Dispose();
        }
        #endregion
        #region 打开模板
        public HTuple OpenModel()
        { 
            //选择文件
            string fileName = "";
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = false;
            fileDialog.Title = "请选择文件";
            fileDialog.Filter = "所有文件(*.*)|(*.shm*)";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = fileDialog.FileName;
            }
        
            //打开文件
            HTuple hv_ModelID;
            HOperatorSet.ReadShapeModel(fileName, out hv_ModelID);
            return hv_ModelID;
        }
        #endregion
        #region 计算圆心
        public void GetCenterCircle(ref CircleCenterParam CenPara)
        {
            HObject ho_Contour = new HObject();
            HTuple hv_Row1, hv_Column1, hv_Radius, hv_StartPhi, hv_EndPhi, hv_PointOrder;
            HOperatorSet.GenContourPolygonXld(out ho_Contour, CenPara.EnX, CenPara.EnY);
            HOperatorSet.FitCircleContourXld(ho_Contour, "algebraic", -1, 0, 0, 3, 2, out hv_Row1,
                out hv_Column1, out hv_Radius, out hv_StartPhi, out hv_EndPhi, out hv_PointOrder);

            CenPara.CircleCenterX = hv_Row1;
            CenPara.CircleCenterY = hv_Column1;
            CenPara.CircleRadiusWor = hv_Radius;
            ho_Contour.Dispose(); hv_Row1 = null; hv_Column1 = null; hv_Radius = null; hv_StartPhi = null; hv_EndPhi = null; hv_PointOrder = null;
        }
        #endregion
        #region 计算C轴旋转后偏移量
        public void CalOffsetRotate(HTuple NineHomMat2D, CircleCenterParam cirCenPara, ModelParamers modelPara, out double[] offset)
        {
            offset = new double[2];
            HTuple hv_Qx1, hv_Qy1, hv_Qx2, hv_Qy2, hv_Qx3, hv_Qy3, hv_HomMat2D1, hv_HomMat2D2, hv_Qx0, hv_Qy0;
            //求模板中心对应的世界坐标
            HOperatorSet.AffineTransPoint2d(NineHomMat2D, modelPara.CreateModelColumn, modelPara.CreateModelRow, out hv_Qx1, out hv_Qy1);
            HOperatorSet.AffineTransPoint2d(NineHomMat2D, modelPara.FindModelColumn, modelPara.FindModelRow, out hv_Qx0, out hv_Qy0);
            //求模板中心旋转后的点的坐标
            HOperatorSet.VectorAngleToRigid(cirCenPara.CircleCenterX, cirCenPara.CircleCenterY, 0, cirCenPara.CircleCenterX,
                cirCenPara.CircleCenterY, -modelPara.FindModelAngle, out hv_HomMat2D1);
            HOperatorSet.AffineTransPoint2d(hv_HomMat2D1, hv_Qx0, hv_Qy0, out hv_Qx2, out hv_Qy2);
            //求模板中心旋转前后的XY偏移量
            HOperatorSet.VectorAngleToRigid(hv_Qx1, hv_Qy1, 0, hv_Qx2, hv_Qy2, 0, out hv_HomMat2D2);
            HOperatorSet.AffineTransPoint2d(hv_HomMat2D2, 0, 0, out hv_Qx3, out hv_Qy3);
            offset[0] = hv_Qx3;
            offset[1] = hv_Qy3;
        }
        #endregion
        #region 计算A轴旋转角度
        public void CalAAxisCheckAngle(ref CalibraAAxisParam caap, double[] HeightNew)
        {
            HTuple hv_Angle;
            HOperatorSet.AngleLl(caap.MechanY1, caap.Height1, caap.MechanY2, caap.Height2, caap.MechanY1, HeightNew[0], caap.MechanY2, HeightNew[1], out hv_Angle);
            double AAngle = hv_Angle.TupleDeg();
            caap.Angle = AAngle;
        }
        #endregion
        #region 解析OPTEX返回的16进制结果
        public string OptexHexToValue(string Data)
        {
            string decStr = string.Empty;
            //删除开头02，结尾03字符
            Data = Data.Replace(" ", "");
            Data = Data.Replace("0x", "");
            Data = Data.Substring(2, Data.Length - 4);
            //将结果转换为ASCII码
            if (Data.Length % 2 != 0)
            {
                Data += " ";
            }
            for (int i = 0; i < Data.Length / 2; i++)
            {
                int a = Convert.ToInt32(Data.Substring(i * 2, 2), 16);
                decStr += ((char)a).ToString();
            }
            return decStr;
        }
        #endregion
        #region 十进制的值换算成16进制字符串
        public string ValueToHex(double value)
        {
            int numY = Convert.ToInt32(value * 100000);
            string HexY = Convert.ToString(numY, 16);
            if (HexY.Length != 8)
            {
                string result = null;
                for (int i = 0; i < 8 - HexY.Length; i++)
                {
                    result += "0";
                }
                result += HexY;
                return result;
            }
            else
            {
                return  Convert.ToString(numY, 16);
            }
        }
        #endregion
    }
}
