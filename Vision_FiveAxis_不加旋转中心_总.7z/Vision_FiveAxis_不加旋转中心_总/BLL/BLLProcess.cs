﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Communicate;
using System.Threading;
using Camera;
using HalconDotNet;
using ImageTool1212;
using Parameter;
using System.Windows.Forms;
using MathCal;
using fairsionCameraLib;

namespace BLL
{
    public class BLLProcess
    {
        #region 属性字段
        public Thread threadSend;
        public HObject outImage = new HObject();
        public communicate comm = new communicate();  //TCP
        public SerialPortCommu SPComm1 = new SerialPortCommu();  //串口1
        public SerialPortCommu SPComm2 = new SerialPortCommu();  //串口2
        public imageTool1212 it = new imageTool1212();
        public mathCal math = new mathCal();
        public HTuple ModelID = null;  //模板句柄
        public HTuple NineHomMat2D = null;  //九点标定矩阵
        double[] height = new double[2];  //测量的高度数据，0是高度1,1是高度2
        public string ip = "192.168.1.114";
        public string port = "502";
        double heightNow;  //实际高度防呆测量的值
        #endregion
        #region 九点标定
        public int AutoNineCalibration(AMKS camera_AMKS, ref PosInfo NinePointPix, HTuple hwi, SerialPortParamer SPP,out string info, CalibraNinePointParam CNPP)
        {
            #region 初始化
            info = null;  //初始化消息
            int isTrue = 0;  //线程返回值0是ok 1是ng
            try
            {
                int isConnect = ServerConnect();  //服务器连接
                if (isConnect != 0)
                {
                    info = "通信失败";
                    comm.IsConnect = false;
                    return 1;
                }
            }
            catch
            {
                info = "服务器连接失败";
                comm.IsConnect = false;
                return 1;
            }
            try
            {
                SerialPort1Connect(SPP);  //串口1连接
            }
            catch
            {
                info = "串口1连接失败";
                SPComm1.isConnect = false;
                return 1;
            }
            #endregion
            for (int i = 0; i < 9; i++)  //九个点循环九次
            {
                #region 等待拍照信号
                threadSend = new Thread(() => { isTrue = CommuniEvent(); });
                threadSend.IsBackground = true;
                threadSend.Start();  //持续发送指令等待拍照信号
                threadSend.Join();
                if (isTrue == 1)
                {
                    info = "等待拍照错误";
                    return 1;
                }
                #endregion
                #region 拍照
                try
                {
                    SPComm1.SendData("SA0255#");
                    Thread.Sleep(150);
                    camera_AMKS.GrabImageOne(out outImage);  //开始拍照
                    SPComm1.SendData("SA0000#");
                    it.ShowImage(outImage, hwi);  //显示图像
                }
                catch
                {
                    info = "拍照错误";
                    return 1;
                }
                #endregion
                comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 02");  //发送指令3
                it.FindCircle(outImage, ref NinePointPix, CNPP);  //拟合圆
                it.ShowNineCalibContours(NinePointPix, hwi);  //显示拟合圆的轮廓
                Thread.Sleep(500);
                if (comm.ReceiveMessage != "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回指令3
                {
                    info = "修改指令错误";
                    return 1;
                }
            }
            return 0;
        }
        #endregion
        #region 标定线程事件
        int CommuniEvent()
        {
            while (true)
            {
                int i;
                for (i = 0; i < 10; i++)
                {
                    try
                    {
                        comm.SendMessage("0C C0 00 00 00 06 01 03 3B CE 00 02");  //发送指令1
                        Thread.Sleep(500);
                        bool isEqu = string.Equals(comm.ReceiveMessage, "0C C0 00 00 00 07 01 03 04 00 00 00 01 ");
                        if (isEqu)  //返回指令2
                        {
                            return 0;
                        }
                    }
                    catch
                    {
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    Application.DoEvents();
                }
                if (i > 9 )  //返回指令2不对，退出
                {
                    return 1;
                }
            }
        }
        #endregion
        #region 程序运行(返回值0正常，1测量错误)
        /// <summary>
        /// 程序运行
        /// </summary>
        /// <param name="camera_AMKS">相机类</param>
        /// <param name="hwi">窗口句柄</param>
        /// <param name="modelPara">模板参数</param>
        /// <param name="info">返回信息</param>
        /// <param name="SPP1">串口1信息</param>
        /// <param name="SPP2">串口2信息</param>
        /// <param name="fileName">任务所在文件名称</param>
        /// <param name="cirCenPara">旋转圆心参数</param>
        /// <param name="CAAP">A轴校正参数</param>
        /// <param name="CHCP">高度防呆功能参数</param>
        /// <returns></returns>
        public int RunProgram(AMKS camera_AMKS, HTuple hwi, ref ModelParamers modelPara, out string info,
            SerialPortParamer SPP1,SerialPortParamer SPP2, string fileName, CircleCenterParam cirCenPara, CalibraAAxisParam CAAP, CalibraHeightCheckParam CHCP)
        {
            #region 初始状态检查
            info = null; modelPara.ModelResult = false;  //初始化报错信息
            int isTrue = 0;  //线程返回值0是ok 1是ng
            try
            {
                int isConnect = ServerConnect();  //服务器连接
                if (isConnect != 0)
                {
                    info = "通信失败";
                    comm.IsConnect = false;
                    return 1;
                }
            }
            catch
            {
                info = "通信失败";
                comm.IsConnect = false;
                return 1;
            }
            try
            {
                SerialPort1Connect(SPP1);  //串口1连接
            }
            catch
            {
                info = "通信失败";
                SPComm1.isConnect = false;
                return 1;
            }
            try
            {
                SerialPort2Connect(SPP2);  //串口2连接
            }
            catch
            {
                info = "通信失败";
                SPComm2.isConnect = false;
                return 1;
            }
            try
            {
                ReadNinePointMatrix();  //读取九点矩阵
            }
            catch
            {
                info = "读取标定矩阵错误";
                return 1;
            }
            #endregion
            #region 高度防呆功能
            if (CHCP.isHeightCheck == true)
            {
                #region 高度防呆位置到位信号
                threadSend = new Thread(() => isTrue = WaitProEvent());
                threadSend.IsBackground = true;
                threadSend.Start();  //持续发送指令等待拍照信号
                threadSend.Join();
                if (isTrue != 0)
                {
                    info = "高度防呆等待到位信号错误";
                    comm.thread.Abort();  //关闭接收线程
                    return 1;
                }
                #endregion
                #region 测量产品高度
                try
                {
                    SPComm2.SendDataHex("02 4D 45 41 53 55 52 45 03");
                    Thread.Sleep(100);
                    string heightHex1 = SPComm2.ReceiveDataHex();  //接受的16进制数据
                    string heightDec1 = math.OptexHexToValue(heightHex1);  //将16进制数据转换成对应的ASCII码
                    heightNow = double.Parse(heightDec1);
                }
                catch
                {
                    info = "高度防呆位置高度测量错误";
                    return 1;
                }
                #endregion
                #region 判断产品位置是否正确
                if (heightNow >= CHCP.HeightDown && heightNow <= CHCP.HeightUpp)
                {
                    #region 发送高度测量完成指令
                    try
                    {
                        if (SendToHuaHeightOK() == 1)
                        {
                            info = "返回高度防呆OK指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "高度防呆测量完成指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                }
                else
                {
                    #region 发送NG
                    try
                    {
                        if (SendToHuaNG() == 0)
                        {
                            info = "测量NG";
                            return 0;
                        }
                        else
                        {
                            info = "返回高度防呆NG指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "高度防呆NG指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                }
                #endregion
            }
            #endregion
            #region 相机拍照
            threadSend = new Thread(() => isTrue = WaitProEvent());
            threadSend.IsBackground = true;
            threadSend.Start();  //持续发送指令等待拍照信号
            threadSend.Join();
            if (isTrue != 0)
            {
                info = "相机拍照等待到位信号错误";
                comm.thread.Abort();
                return 1;
            }
            try
            {
                SPComm1.SendData("SA0255#");
            }
            catch
            {
                info = "串口1通信错误";
                return 1;
            }
            Thread.Sleep(150);
            try
            {
                camera_AMKS.GrabImageOne(out outImage);  //开始拍照
                SPComm1.SendData("SA0000#");
                it.ShowImage(outImage, hwi);  //显示图像
            }
            catch
            {
                info = "拍照错误";
                return 1;
            }
            try
            {
                if (ModelID == null)
                {
                    ModelID = it.ReadModel(fileName + ".shm");  //读取模板句柄 
                }
                it.FindCrossModel(outImage, ModelID, ref modelPara);  //查找模板
            }
            catch
            {
                info = "查找模板错误";
                return 1;
            }
            
            #endregion
            #region 测量OK
            if ((int)(new HTuple((new HTuple(modelPara.FindModelRow.TupleLength())).TupleGreater(0))) != 0)  //测量OK
            {
                #region 显示模板
                try
                {
                    it.GetModelContour(ModelID, ref modelPara);
                    it.ShowModelContours(modelPara, hwi);
                }
                catch
                {
                    info = "获取模板错误";
                    return 1;
                }
                #endregion
                #region 不加旋转中心的偏移
                //math.CalOffset(NineHomMat2D, ref modelPara);  //计算偏差值
                #endregion
                #region 加旋转中心的偏移
                try
                {
                    double[] DetXY = new double[2];
                    math.CalOffsetRotate(NineHomMat2D, cirCenPara, modelPara, out DetXY);
                    modelPara.OffsetX = -DetXY[0];
                    modelPara.OffsetY = -DetXY[1];
                    DetXY = null;  //释放
                }
                catch
                {
                    info = "计算旋转中心偏移量错误";
                    return 1;
                }
                #endregion
                #region 是否增加A轴旋转功能
                if (CAAP.isAAxisCheck == true)  //增加A轴校正功能
                {
                    //初始化变量
                    height[0] = 0; height[1] = 0; CAAP.Angle = 0;  //A轴校正角度
                    #region 发送相机拍照完成指令
                    try
                    {
                        if (SendToHuaCameraFinish() == 1)
                        {
                            info = "返回相机拍照完成指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "相机拍照完成指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region A轴测量位置1到位信号
                    threadSend = new Thread(() => isTrue = WaitProEvent());
                    threadSend.IsBackground = true;
                    threadSend.Start();  //持续发送指令等待拍照信号
                    threadSend.Join();
                    if (isTrue != 0)
                    {
                        info = "A轴测量位置1等待到位信号错误";
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 测量位置1的高度
                    try
                    {
                        SPComm2.SendDataHex("02 4D 45 41 53 55 52 45 03");
                        Thread.Sleep(100);
                        string heightHex1 = SPComm2.ReceiveDataHex();  //接受的16进制数据
                        string heightDec1 = math.OptexHexToValue(heightHex1);  //将16进制数据转换成对应的ASCII码
                        height[0] = double.Parse(heightDec1);
                    }
                    catch
                    {
                        info = "测高位置1错误";
                        return 1;
                    }
                    #endregion
                    #region 测高位置1完成指令
                    try
                    {
                        if (SendToHuaAHeight1Finish() == 1)
                        {
                            info = "返回A轴校正测量位置1完成指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "A轴校正测量位置1完成指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region A轴测量位置2到位信号
                    threadSend = new Thread(() => isTrue = WaitProEvent());
                    threadSend.IsBackground = true;
                    threadSend.Start();  //持续发送指令等待拍照信号
                    threadSend.Join();
                    if (isTrue != 0)
                    {
                        info = "A轴测量位置2等待到位信号错误";
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 测量位置2
                    try
                    {
                        SPComm2.SendDataHex("02 4D 45 41 53 55 52 45 03");
                        Thread.Sleep(100);
                        string heightHex2 = SPComm2.ReceiveDataHex();  //接受的16进制数据
                        string heightDec2 = math.OptexHexToValue(heightHex2);  //将16进制数据转换成对应的ASCII码
                        height[1] = double.Parse(heightDec2);
                    }
                    catch
                    {
                        info = "测高位置2错误";
                        return 1;
                    }
                    #endregion
                    #region 判断A轴角度
                    //计算A轴校正偏差值
                    try
                    {
                        math.CalAAxisCheckAngle(ref CAAP, height);
                        CAAP.Angle = Math.Round(CAAP.Angle, 3);
                    }
                    catch
                    {
                        info = "高度计算错误";
                        return 1;
                    }
                    //判断A轴角度是否过大
                    if (CAAP.Angle > 10 || CAAP.Angle < -10)
                    {
                        info = "A轴角度超限";
                        #region 发送NG
                        try
                        {
                            if (SendToHuaNG() == 0)
                            {
                                info = "测量NG";
                                return 0;
                            }
                            else
                            {
                                info = "返回高度防呆NG指令错误";
                                return 1;
                            }
                        }
                        catch
                        {
                            info = "高度防呆NG指令通信失败";
                            comm.IsConnect = false;
                            comm.thread.Abort();
                            return 1;
                        }
                        #endregion
                    }
                    
                    #endregion
                    #region 结果转换
                    //A轴偏差值转换成16进制字符串
                    string SendDataA = "00 F0 00 00 00 0B 01 10 3B DB 00 02 04 " + math.AAngleToHex(CAAP.Angle);
                    //XYC轴偏差值转换成16进制字符串
                    math.OffsetToHex(ref modelPara);  
                    string SendDataX = "00 F0 00 00 00 0B 01 10 3B D8 00 02 04 ";
                    SendDataX += modelPara.OffsetHexX;
                    string SendDataY = "00 F0 00 00 00 0B 01 10 3B D9 00 02 04 ";
                    SendDataY += modelPara.OffsetHexY;
                    string SendDataC = "00 F0 00 00 00 0B 01 10 3B DC 00 02 04 ";
                    SendDataC += modelPara.OffsetHexU;
                    #endregion
                    #region 发送X坐标给华中
                    try
                    {
                        if (SendToHuaXPosition(SendDataX) == 1)  //返回指令6X
                        {
                            info = "返回X坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "X坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送Y坐标给华中
                    try
                    {
                        if (SendToHuaYPosition(SendDataY) == 1)  //返回指令6Y
                        {
                            info = "返回Y坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "Y坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送C坐标给华中
                    try
                    {
                        if (SendToHuaCPosition(SendDataC) == 1)  //返回指令6C
                        {
                            info = "返回C坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "C坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送A坐标给华中
                    try
                    {
                        if (SendToHuaAPosition(SendDataA) == 1)
                        {
                            info = "返回A坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "A坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送OK指令给华中
                    try
                    {
                        if (SendToHuaOK() == 1)  //返回修改OK指令成功
                        {
                            info = "返回OK指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "OK指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 返回结果信息
                    //返回测量结果
                    info += "OffsetX =";
                    info += modelPara.OffsetX.ToString("f3");
                    info += " OffsetY =";
                    info += modelPara.OffsetY.ToString("f3");
                    info += " OffsetC =";
                    info += ((double)((new HTuple(modelPara.FindModelAngle)).TupleDeg())).ToString("f3");
                    info += " OffsetA =";
                    info += CAAP.Angle.ToString("f3");
                    //测量结果
                    modelPara.ModelResult = true;
                    #endregion
                }
                else  //不增加A轴校正功能
                {
                    #region 结果转换
                    //XYC轴偏差值转换成16进制字符串
                    math.OffsetToHex(ref modelPara);
                    string SendDataX = "00 F0 00 00 00 0B 01 10 3B D8 00 02 04 ";
                    SendDataX += modelPara.OffsetHexX;
                    string SendDataY = "00 F0 00 00 00 0B 01 10 3B D9 00 02 04 ";
                    SendDataY += modelPara.OffsetHexY;
                    string SendDataC = "00 F0 00 00 00 0B 01 10 3B DC 00 02 04 ";
                    SendDataC += modelPara.OffsetHexU;
                    #endregion
                    #region 发送X坐标给华中
                    try
                    {
                        if (SendToHuaXPosition(SendDataX) == 1)  //返回指令6X
                        {
                            info = "返回X坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "X坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送Y坐标给华中
                    try
                    {
                        if (SendToHuaYPosition(SendDataY) == 1)  //返回指令6Y
                        {
                            info = "返回Y坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "Y坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送C坐标给华中
                    try
                    {
                        if (SendToHuaCPosition(SendDataC) == 1)  //返回指令6C
                        {
                            info = "返回C坐标指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "C坐标指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 发送OK指令给华中
                    try
                    {
                        if (SendToHuaOK() == 1)  //返回修改OK指令成功
                        {
                            info = "返回OK指令错误";
                            return 1;
                        }
                    }
                    catch
                    {
                        info = "OK指令通信失败";
                        comm.IsConnect = false;
                        comm.thread.Abort();
                        return 1;
                    }
                    #endregion
                    #region 返回结果信息
                    //返回测量结果
                    info += "OffsetX =";
                    info += modelPara.OffsetX.ToString("f3");
                    info += " OffsetY =";
                    info += modelPara.OffsetY.ToString("f3");
                    info += " OffsetC =";
                    info += ((double)((new HTuple(modelPara.FindModelAngle)).TupleDeg())).ToString("f3");
                    //测量结果
                    modelPara.ModelResult = true;
                    #endregion
                }
                #endregion
            }
            #endregion
            #region 测量NG，发送NG信号
            else
            {
                #region 发送NG
                try
                {
                    if (SendToHuaNG() == 0)
                    {
                        info = "测量NG";
                        return 1;
                    }
                    else
                    {
                        info = "返回NG指令错误";
                        return 1;
                    }
                }
                catch
                {
                    info = "NG指令通信失败";
                    comm.IsConnect = false;
                    comm.thread.Abort();
                    return 1;
                }
                #endregion
            }
            #endregion
            #region 返回信息
            return 0;
            #endregion
        }
        #endregion
        #region 上料线程事件
        int WaitProEvent()
        {
            while (true)
            {
                int i;
                try
                {
                    comm.SendMessage("0C C0 00 00 00 06 01 03 3B CE 00 02");  //发送指令1
                }
                catch
                {
                    comm.IsConnect = false;
                    comm.thread.Abort();
                    return 1;
                }
                Thread.Sleep(50);
                bool isEqu = string.Equals(comm.ReceiveMessage, "0C C0 00 00 00 07 01 03 04 00 00 00 01 ");  //返回指令2
                if (isEqu)  //返回指令2
                {
                    for (i = 0; i < 20; i++)  //循环发送，防止指令未接收到
                    {
                        try
                        {
                            comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 02");  //发送指令3
                        }
                        catch
                        {
                            comm.IsConnect = false;
                            comm.thread.Abort();
                            return 1;
                        }
                        Thread.Sleep(50);
                        if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回指令4
                        {
                            return 0;
                        }
                    }
                    if (i > 19)  //返回指令4不对，退出
                    {
                        return 1;
                    }
                }
            }
        }
        #endregion
        #region 服务器连接
        public int ServerConnect()
        {
            int isConnect = 0;
            if (!comm.IsConnect)
            {
                isConnect = comm.ConnectServer(ip, port);  //连接服务器
            }
            return isConnect;
        }
        #endregion
        #region 串口1连接
        public void SerialPort1Connect(SerialPortParamer SPP1)
        {
            if (!SPComm1.isConnect)
            {
                SPComm1.OpenSerialPort(SPP1);
            }
        }
        #endregion
        #region 串口2连接
        public void SerialPort2Connect(SerialPortParamer SPP2)
        {
            if (!SPComm2.isConnect)
            {
                SPComm2.OpenSerialPort(SPP2);
            }
        }
        #endregion
        #region 发送ok信号给华中
        int SendToHuaOK()
        {
            comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 03 ");  //发送指令OK
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回修改OK指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region 发送ng信号给华中
        int SendToHuaNG()
        {
            comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 04 ");  //发送指令NG
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回修改NG指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region 高度防呆完成指令
        int SendToHuaHeightOK()
        {
            comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 07 ");  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region 发送相机拍照完成指令
        int SendToHuaCameraFinish()
        {
            comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 05 ");  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        } 
        #endregion
        #region A轴校正位置1完成指令
        int SendToHuaAHeight1Finish()
        {
            comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 06 ");  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B CE 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        } 
        #endregion
        #region X坐标发送给华中
        int SendToHuaXPosition(string XPosition)
        {
            comm.SendMessage(XPosition);  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B D8 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region Y坐标发送给华中
        int SendToHuaYPosition(string YPosition)
        {
            comm.SendMessage(YPosition);  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B D9 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region C坐标发送给华中
        int SendToHuaCPosition(string CPosition)
        {
            comm.SendMessage(CPosition);  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B DC 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region A坐标发送给华中
        int SendToHuaAPosition(string APosition)
        {
            comm.SendMessage(APosition);  //发送指令测高位置1完成
            Thread.Sleep(80);
            if (comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B DB 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region 读取九点标定矩阵
        void ReadNinePointMatrix()
        {
            if (NineHomMat2D == null)
            {
                NineHomMat2D = it.ReadMatric();
            }
        }
        #endregion

    }
}