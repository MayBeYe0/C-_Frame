﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Windows.Forms;

namespace Communicate
{
    public class SerialPortCommu
    {
        #region 属性字段
        SerialPort sp = new SerialPort();
        public bool isConnect = false;  //判断串口是否打开
        #endregion
        #region 打开串口
        public void OpenSerialPort(SerialPortParamer SPP)
        {
            if (!sp.IsOpen)
            {
                sp.PortName = SPP.ComPort;  //串口号
                sp.BaudRate = SPP.ComBaudRate;  //波特率
                sp.DataBits = SPP.ComDataBits;  //数据位
                sp.Parity = (Parity)Enum.Parse(typeof(Parity), SPP.ComParity);  //校验位
                sp.StopBits = (StopBits)Enum.Parse(typeof(StopBits), SPP.ComStopBits);  //停止位
                try
                {
                    sp.Open();  //打开串口
                    isConnect = true;
                }
                catch
                {
                    isConnect = false;
                    Console.WriteLine("串口打开失败");
                }
            }
        }
        #endregion
        #region 发送数据
        public void SendData(string sendStr)
        {
            byte[] bufferSend = Encoding.Default.GetBytes(sendStr);
            sp.Write(bufferSend, 0, bufferSend.Length);
        }
        #endregion
        #region 发送16进制数据
        public void SendDataHex(string sendStr)
        {
            sendStr = sendStr.Replace(" ", "");
            sendStr = sendStr.Replace("0x", "");
            if (sendStr.Length % 2 != 0)
            {
                sendStr += " ";
            }
            byte[] buffer = new byte[sendStr.Length / 2];
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = Convert.ToByte(sendStr.Substring(i * 2, 2), 16);
            }
            sp.Write(buffer, 0, buffer.Length);
        }
        #endregion
        #region 接受数据
        public string ReceiveData()
        {
            int count = sp.BytesToRead;
            byte[] buffer = new byte[count];
            sp.Read(buffer, 0, buffer.Length);
            return Encoding.Default.GetString(buffer);
        }
        #endregion
        #region 接受16进制数据
        public string ReceiveDataHex()
        {
            string hexStr = string.Empty;
            int count = sp.BytesToRead;
            byte[] buffer = new byte[count];
            sp.Read(buffer, 0, buffer.Length);
            for (int i = 0; i < buffer.Length; i++)
            {
                hexStr += buffer[i].ToString("X2");
                hexStr += " ";
            }
            return hexStr;
        }
        #endregion
    }
    [Serializable]
    public class SerialPortParamer
    {
        public string ComPort;  //串口号
        public int ComBaudRate;  //波特率
        public int ComDataBits;  //数据位
        public string ComParity;  //校验位
        public string ComStopBits;  //停止位
        public SerialPortParamer()
        {
            ComPort = "COM1";
            ComBaudRate = 19200;
            ComDataBits = 8;
            ComParity = "None";
            ComStopBits = "1";
        }
    }
}
