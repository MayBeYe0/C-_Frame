﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Net;

namespace Communicate
{
    public class communicate
    {
        #region 属性字段
        Socket socketClinet;//创建Socket对象
        public Thread thread;
        public bool IsConnect = false;//是否连接成功
        public string ReceiveMessage = null;
        #endregion
        #region 连接服务器
        public int ConnectServer(string ip, string port)
        {
            //第一步:调用Socket对象初始化，IP4协议|Socke字节流|TCP协议
            socketClinet = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //第二步设置IP端口
            IPEndPoint ipe = new IPEndPoint(IPAddress.Parse(ip), int.Parse(port));
            //第三步:Connect使用函数来连接服务器
            IAsyncResult iasyn = socketClinet.BeginConnect(ip, int.Parse(port), null, null);  //异步连接
            IsConnect = iasyn.AsyncWaitHandle.WaitOne(2000, true);
            if (!IsConnect)
            {
                return 1;
            }
            //socketClinet.Connect(ipe);  //同步连接
            //IsConnect = true;
            //第四步：创建一个监听线程来专门接收服务器发送过来的内容，然后显示
            thread = new Thread(CheckReceiveMsg);
            thread.IsBackground = true;
            thread.Start();
            return 0;
            //try
            //{
            //    socketClinet.Connect(ipe);
            //    IsConnect = true;//判断是否连接成功
            //}
            //catch
            //{
            //    IsConnect = false;//连接失败
            //}
            //if (IsConnect == true)
            //{
            //    //第四步：创建一个监听线程来专门接收服务器发送过来的内容，然后显示
            //    thread = new Thread(CheckReceiveMsg);
            //    thread.IsBackground = true;
            //    thread.Start();
            //}
        }
        #endregion
        #region 断开服务器
        public void BreakServer()
        {
            socketClinet.Close();
        }
        #endregion
        /// <summary>
        /// 监听
        /// </summary>
        void CheckReceiveMsg()
        {
            while (true)
            {
                //创建Byte字节缓冲区，专门用来接收内容
                byte[] buffer = new byte[1024 * 1024];
                //设置获取消息的长度
                int length = -1;
                //接收服务器发送过来的消息
                try
                {
                    //接收字节的长度->
                    length = socketClinet.Receive(buffer);
                }
                catch
                {
                    break;
                }
                //判断返回的内容是否大于-1
                if (length > 0)
                {
                    //string msg = Encoding.Default.GetString(buffer, 0, length);
                    ReceiveMessage = ValueToHexStr(buffer, length);
                }
                else
                {
                    socketClinet.Close();
                    break;
                }
            }
        }
        #region 发送
        public void SendMessage(string info)
        {
            byte[] bufferSend = HexToValue(info.Trim());
            socketClinet.Send(bufferSend);
        }
        #endregion
        #region  数值转换成16进制字符串
        public string ValueToHexStr(byte[] buffer, int length)
        {
            string hexStr = string.Empty;
            for (int i = 0; i < length; i++)
            {
                hexStr += buffer[i].ToString("X2");
                hexStr += " ";
            }
            return hexStr;
        }
        #endregion
        #region  16进制写法的字符串转成数值
        public byte[] HexToValue(string sendStr)
        {
            sendStr = sendStr.Replace(" ", "");
            sendStr = sendStr.Replace("0x", "");
            if (sendStr.Length % 2 != 0)
            {
                sendStr += " ";
            }
            byte[] buffer = new byte[sendStr.Length / 2];
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = Convert.ToByte(sendStr.Substring(i * 2, 2), 16);
            }
            return buffer;
        }
        #endregion
    }
}
