﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;

namespace Camera
{
    public class EventArgsDAL : EventArgs
    {
        /// <summary>
        /// 图像
        /// </summary>
        public HObject Image
        { get; set; }
    }
}
