﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;

namespace DrawImage
{
    public enum FBAYER_ARITHMETIC
    {
        ARITH_NEAREST_NEIGHBER = 0x10000000,				//最邻近插值
        ARITH_AVERAGE_NEIGHBER = 0x10000001,				//邻域平均插值
        ARITH_COLOR_CORRELATION = 0x10000002,				//色彩相关插值
        ARITH_NEAREST_NEIGHBER_ENHANCE = 0x10000003			//最邻近插值和色彩增强联合
    }

    public enum FPixelColorFilter
    {
        NO_BAYER = 0,
        Bayer_RG = 1,
        Bayer_GB = 2,
        Bayer_GR = 3,
        Bayer_BG = 4
    }
    
    // 图像格式
    public enum FFILETYPE
    {
	    FileType_Raw = 0,
	    FileType_Bmp = 1,
	    FileType_Jpeg = 2,
	    FileType_Png  = 3
    };
}