﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using fairsionCameraLib;
using HalconDotNet;
using DrawImage;
using System.Threading;
using System.Drawing.Imaging;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Camera
{
    
    public class AMKS
    {
        public delegate void GrapImageDelegate(object sender, EventArgsDAL e);
        public event GrapImageDelegate GrapImageEvent;  //采集事件
        #region 属性字段
        EventArgsDAL _EventArgs = new EventArgsDAL();
        public DeviceManagerClass pManager = null;
        long lCameraCount = 0;
        ICamera pCamera = null;
        IntPtr pSrcBuffer;
        //IntPtr pColorBuffer;
        emTrans_Mode eTrans_Mode = emTrans_Mode.TRANS_Continuous;
        //FPixelColorFilter fcBayerPattern = FPixelColorFilter.Bayer_RG;
        bool bTriggerSucceed = false;
        int iWidth = 0;
        int iHeight = 0;
        int iColor = 0;
        public static HObject image = new HObject();
        HTuple hv_Width, hv_Height;
        Thread thread = null;  //实时采集线程
        bool m_bShowFlag = false;  //实时采集状态判断
        bool m_bRun = false;  //停止实时采集
        public int a = 0;
        #endregion
        private void OnGrapImageEvent(EventArgsDAL e)
        {   //定义一个局部变量，将事件对象赋值给该变量，防止多线程情况取消事件
            GrapImageDelegate mEvent = this.GrapImageEvent;
            if (mEvent != null)
            {
                mEvent(this, e);//事件触发
            }
        }
        #region 初始化相机
        public void Initialize()
        {
            // 初始化相机
            pManager = new DeviceManagerClass();
            if (null == pManager)
            {
                //Console.Write("COM component create failed!");
                return;
            }
            pManager.Initialize();
            //获取相机信息
            lCameraCount = pManager.GetCameraCount(2000);
            if (0 == lCameraCount)
            {
                //Console.WriteLine("No camera is online!");
                return;
            }
            // 获取相机链表中的第一个相机
            pCamera = pManager.GetCamera(0);
            if (null == pCamera)
            {
                //Console.WriteLine("Get camera failed!");
                return;
            }
        }
        #endregion
        #region 打开相机
        public void Open()
        {
            //打开相机
            pCamera.Open();
            if (!pCamera.IsOpen())
            {
                //Console.WriteLine("Open camera failed!");
                return;
            }
        }
        #endregion
        #region 判断相机是否打开
        public bool IsOpen()
        {
            return pCamera.IsOpen();
        }
        #endregion
        #region 拍照（一次）
        public void GrabImageOne(out HObject image)
        {
            if (pManager == null)
            {
                Initialize();  //初始化相机
                Console.WriteLine("IniCamera");
            }
            if (!pCamera.IsOpen())
            {
                Open();  //打开相机
            }
            image = null;
            // 获取当前图像宽高
            // Get image width and height
            iWidth = pCamera.GetValue("Width");
            iHeight = pCamera.GetValue("Height");
            pSrcBuffer = Marshal.AllocHGlobal(iWidth * iHeight);
            // 设置传输模式
            // Set Trans mode
            pCamera.SetTransMode(eTrans_Mode);
            // 启动传输
            // Start capture
            pCamera.StartCapture();
            if (!pCamera.IsCapturing())
            {
                Console.WriteLine("Start capture failed!");
                return;
            }
            bTriggerSucceed = pCamera.IsGrabSucceeded(2000);
            if (bTriggerSucceed)
            {
                // CopyImageBufferEx接口32位程序建议用pSrcBuffer.ToInt32()，64位程序建议用pSrcBuffer.ToInt64()。
                if (pCamera.CopyImageBufferEx(pSrcBuffer.ToInt32(), iWidth * iHeight))
                {
                    if (iColor == 0)
                    {
                        // 8位灰度图像
                        Bitmap grayMap = ReturnBmp(iWidth, iHeight, pSrcBuffer);
                        Rectangle rect = new Rectangle(0, 0, grayMap.Width, grayMap.Height);
                        BitmapData srcBmpData = grayMap.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format8bppIndexed);
                        HOperatorSet.GenImage1(out image, "byte", grayMap.Width, grayMap.Height, srcBmpData.Scan0);
                        HOperatorSet.MirrorImage(image, out image, "column");
                        HOperatorSet.WriteImage(image, "bmp", 0, "gray.bmp");
                        _EventArgs.Image = image;
                        OnGrapImageEvent(_EventArgs);
                        grayMap.UnlockBits(srcBmpData);
                        grayMap.Dispose();
                    }
                    else
                    {
                        // 8位彩色图像，进行bayer插值
                        //Bitmap testBmp = ReturnRgbBmp(iWidth, iHeight, pColorBuffer);
                        //testBmp.Save("color.bmp");
                    }
                }
            }
            else
            {
                Console.WriteLine("Trigger failed!");
            }
            // 停止传输和关闭相机
            // Stop and close camera
            pCamera.StopCapture();
            //pCamera.Close();
            Marshal.FreeCoTaskMem(pSrcBuffer);  //释放资源
        }
        #endregion
        #region 停止实时采集
        public void StopGrapImage()
        {
            if (m_bShowFlag)
            {
                m_bRun = false;
            }
        }
        #endregion
        #region 实时采集
        public void GrabImageContinue()
        {
            thread = new Thread(grabImageContinue);
            thread.IsBackground = true;
            thread.Start();
        }
        #endregion
        #region 线程函数
        void grabImageContinue()
        {
            if (pManager == null)
            {
                Initialize();  //初始化相机
                Open();  //打开相机
            }

            m_bShowFlag = true;//设置运行状态
            m_bRun = true;

            image = new HObject();
            // 获取当前图像宽高
            iWidth = pCamera.GetValue("Width");
            iHeight = pCamera.GetValue("Height");

            pSrcBuffer = Marshal.AllocHGlobal(iWidth * iHeight);
            //pColorBuffer = Marshal.AllocHGlobal(iWidth * iHeight * 3);

            // 获取彩色滤光片格式
            // Get color filter format
            //iColor = pCamera.GetValue("PixelColorFilter");
            //if (iColor == 1)
            //    fcBayerPattern = FPixelColorFilter.Bayer_RG;
            //else if (iColor == 2)
            //    fcBayerPattern = FPixelColorFilter.Bayer_GB;
            //else if (iColor == 3)
            //    fcBayerPattern = FPixelColorFilter.Bayer_GR;
            //else if (iColor == 4)
            //    fcBayerPattern = FPixelColorFilter.Bayer_BG;

            // 设置传输模式
            // Set Trans mode
            pCamera.SetTransMode(eTrans_Mode);

            // 启动传输
            // Start capture
            pCamera.StartCapture();
            if (!pCamera.IsCapturing())
            {
                Console.WriteLine("Start capture failed!");
                return;
            }
            // 显示的图片数量
            // Show image count
            while (m_bRun)
            {
                bTriggerSucceed = pCamera.IsGrabSucceeded(200);
                if (bTriggerSucceed)
                {
                    // CopyImageBufferEx接口32位程序建议用pSrcBuffer.ToInt32()，64位程序建议用pSrcBuffer.ToInt64()。
                    if (pCamera.CopyImageBufferEx(pSrcBuffer.ToInt32(), iWidth * iHeight))
                    {
                        if (iColor == 0)
                        {
                            // 8位灰度图像
                            Bitmap grayMap = ReturnBmp(iWidth, iHeight, pSrcBuffer);
                            grayMap.Save("gray.bmp");
                            Rectangle rect = new Rectangle(0, 0, grayMap.Width, grayMap.Height);
                            BitmapData srcBmpData = grayMap.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format8bppIndexed);
                            HOperatorSet.GenImage1(out image, "byte", grayMap.Width, grayMap.Height, srcBmpData.Scan0);
                            HOperatorSet.MirrorImage(image, out image, "column");
                            _EventArgs.Image = image;
                            OnGrapImageEvent(_EventArgs);
                            grayMap.UnlockBits(srcBmpData);
                            HOperatorSet.GetImageSize(image, out hv_Width, out hv_Height);
                            //if (OneTime < 1)
                            //{
                            //    HOperatorSet.SetPart(pictureBox.HalconWindow, 0, 0, hv_Height, hv_Width);
                            //    OneTime++;
                            //}
                        }
                        else
                        {
                            // 8位彩色图像，进行bayer插值
                            //Bitmap testBmp = ReturnRgbBmp(iWidth, iHeight, pColorBuffer);
                            //testBmp.Save("color.bmp");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Trigger failed!");
                }
            }
        }
        #endregion
        #region 关闭相机
        public void CloseCamera()
        {
            if (pCamera != null)
            {
                pCamera.StopCapture(); //停止传输
                pCamera.Close();  //关闭相机
                //释放所有相机资源
                pManager.Terminate();
                pManager = null;
            }
        }
        #endregion
        #region 返回8位灰度图像Bitmap
        public static Bitmap ReturnBmp(int Width, int Height, IntPtr pImageData)
        {
            Bitmap resultBitmap = new Bitmap(Width, Height, System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
            MemoryStream curImageStream = new MemoryStream();
            resultBitmap.Save(curImageStream, System.Drawing.Imaging.ImageFormat.Bmp);
            curImageStream.Flush();
            int bitmapDataSize = ((Width * 8 + 31) / 32 * 4) * Height;
            int dataOffset = 1078;
            int paletteStart = 54;
            int paletteEnd = dataOffset;
            int color = 0;
            for (int i = paletteStart; i < paletteEnd; i += 4)
            {
                byte[] tempColor = new byte[4];
                tempColor[0] = (byte)color;
                tempColor[1] = (byte)color;
                tempColor[2] = (byte)color;
                tempColor[3] = (byte)0;
                color++;

                curImageStream.Position = i;
                curImageStream.Write(tempColor, 0, 4);
            }
            byte[] destImageData = new byte[bitmapDataSize];
            Marshal.Copy(pImageData, destImageData, 0, Width * Height);
            curImageStream.Position = dataOffset;
            curImageStream.Write(destImageData, 0, bitmapDataSize);
            curImageStream.Flush();
            resultBitmap.Dispose();
            resultBitmap = new Bitmap(curImageStream);
            curImageStream.Dispose();
            return resultBitmap;
        }
        #endregion
        #region 返回24位RGB图像Bitmap
        public static Bitmap ReturnRgbBmp(int Width, int Height, IntPtr pImageData)
        {
            Bitmap resultBitmap = new Bitmap(Width, Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            MemoryStream curImageStream = new MemoryStream();
            resultBitmap.Save(curImageStream, System.Drawing.Imaging.ImageFormat.Bmp);
            curImageStream.Flush();

            int curPadNum = ((Width * 8 + 31) / 32 * 4) - Width;

            int bitmapDataSize = ((Width * 8 + 31) / 32 * 4) * Height * 3;

            int dataOffset = 54;

            byte[] destImageData = new byte[bitmapDataSize];
            Marshal.Copy(pImageData, destImageData, 0, 3 * Width * Height);

            curImageStream.Position = dataOffset;

            curImageStream.Write(destImageData, 0, bitmapDataSize);

            curImageStream.Flush();

            resultBitmap = new Bitmap(curImageStream);

            return resultBitmap;

        }
        #endregion
        #region 设置曝光时间
        public void SetExpose(int expose)
        {
            if (pCamera.IsAvailable("ExposureTimeRaw"))
            {
                // 获取和设置曝光时间
                // Get and set ExpouseTime
                pCamera.SetValue("ExposureTimeRaw", expose);
            }
        }
        #endregion
        #region 设置增益
        public void SetGain(int gain)
        {
            if (pCamera.IsAvailable("GainRaw"))
            {
                // Get and set Gain
                pCamera.SetValue("GainRaw", gain);
            }
        }
        #endregion
        #region 读取曝光时间
        public int GetExpose()
        {
            // 曝光时间是否有效
            // ExposureTime is available or not
            if (pCamera.IsAvailable("ExposureTimeRaw"))
            {
                // 获取和设置曝光时间
                // Get and set ExpouseTime
                return pCamera.GetValue("ExposureTimeRaw");
                //Console.WriteLine("ExposureTime:        {0}", iCount);
            }
            return 0;
        }
        #endregion
        #region 读取增益
        public int GetGain()
        {
            // 增益是否有效
            // Gain is available or not
            if (pCamera.IsAvailable("GainRaw"))
            {
                // Get and set Gain
                return pCamera.GetValue("GainRaw");
                //Console.WriteLine("Gain:        {0}", iCount);
            }
            return 0;
        }
        #endregion
        #region 保存相机参数
        public void SaveCamPara()
        {
            // 保存相机配置到当前项目路径
            // Save the camera configuration to the current project directory
            pCamera.SaveConfigure("./cameraConfigure.ini");
        }
        #endregion
        #region 读取相机参数
        public void ReadCamPara()
        {
            // 加载之前保存的相机配置文件
            // Load the configuration file under the specified path
            pCamera.LoadConfigure("./cameraConfigure.ini");
        }
        #endregion
    }
}
