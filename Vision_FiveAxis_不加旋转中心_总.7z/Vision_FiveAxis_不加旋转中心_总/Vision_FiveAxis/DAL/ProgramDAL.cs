﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VisionTool.ImageToolDAL;

namespace Vision_FiveAxis
{
    public class ProgramDAL
    {
        #region 运行流程
        public static int ProgramRun(List<ImageTool> tool, FlowExecuteDAL flowExecute)
        {
            foreach (ImageTool it in tool)
            {
                if (it is AcqFifoTool)
                {
                    flowExecute.FlowExecute(it);
                }
            }
            return 0;
        }
        #endregion
        
    }
}
