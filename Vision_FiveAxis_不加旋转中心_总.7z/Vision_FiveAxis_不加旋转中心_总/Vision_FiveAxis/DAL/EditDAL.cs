﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VisionTool.ImageToolDAL;
using HalconDotNet;

namespace Vision_FiveAxis.DAL
{
    public class EditDAL
    {
        #region 添加工具
        public static void Add(ListView listView, List<ImageTool> tool, ImageTool it, string[] str, HWindowControl hwin)
        {
            listView.BeginUpdate();
            it.Ini();  //初始化
            it.windowControl = hwin;
            tool.Add(it);
            ListViewItem item = listView.Items.Add(str[0]);  //编号
            item.SubItems.Add(str[1]);  //工具
            item.SubItems.Add(str[2]);  //工具描述
            item.SubItems.Add(str[3]);  //结果
            item.SubItems.Add(str[4]);  //耗时
            listView.EndUpdate();
        }
        #endregion
    }
}
