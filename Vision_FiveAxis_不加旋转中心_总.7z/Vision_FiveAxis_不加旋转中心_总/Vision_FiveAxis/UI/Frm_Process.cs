﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HalconDotNet;
using VisionTool.ImageToolDAL;
using Vision_FiveAxis.BLL;

namespace Vision_FiveAxis
{
    public partial class Frm_Process : Form
    {
        #region 属性字段
        public List<ImageTool> tool = new List<ImageTool>();  //工具集合
        FlowExecuteDAL flowExecute1 = new FlowExecuteDAL();  //流程对象
        //单例窗体
        private static Frm_Process _instance;
        public static Frm_Process Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Frm_Process();
                }
                return _instance;
            }
        }
        #endregion
        private Frm_Process()
        {
            InitializeComponent();
            this.TopLevel = false;
        }
        #region 双击打开窗口
        private void lv_process_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListView listView = (ListView)sender;
            if (listView.SelectedItems.Count == 0) return;
            string selectedItem = listView.SelectedItems[0].ToString();
            int index = listView.SelectedItems[0].Index;//选中一行集合索引

            if (tool[index] as AcqFifoTool is AcqFifoTool)  //打开选中工具的设置
            {
                AcqFifoTool acqFifoTool = tool[index] as AcqFifoTool;
                frm_AcqFifo.Instance.Show();
            }
        }
        #endregion
        #region 运行
        public void Run()
        {
            ProgramBLL.Run(tool, flowExecute1);
        }
        #endregion
        #region 窗体事件
        private void Frm_Process_Load(object sender, EventArgs e)
        {
            Frm_Tools.SelectToolEvent += Frm_Tools_SelectToolEvent;
        }
        #endregion
        #region 工具窗体选择工具事件的方法
        private void Frm_Tools_SelectToolEvent(string type)
        {
            AddTool(type);
        }
        #endregion
        #region 添加工具到流程中
        public void AddTool(string type)
        {
            string s = "1";
            int index = -1;
            foreach (ListViewItem lvItem in lv_process.SelectedItems)
            {
                index = lvItem.Index;
            }
            if (index > 0)
            {
                s = (index + 1).ToString();  //选中一行集合索引
            }
            else
            {
                s = (tool.Count + 1).ToString();
            }
            if (type == ImageTool.Tool.采集图像.ToString())
            {
                string[] str = new string[] { s, type, "", "NG", "0ms" };
                ImageTool imageTool = new AcqFifoTool();
                EditBLL.Add(lv_process, tool, imageTool, str, Frm_ShowImage.Instance.halconView1.HWindowControl);
            }
        }
        #endregion

    }
}
