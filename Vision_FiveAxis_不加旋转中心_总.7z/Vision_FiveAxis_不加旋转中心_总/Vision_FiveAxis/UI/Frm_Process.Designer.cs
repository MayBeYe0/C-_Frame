﻿namespace Vision_FiveAxis
{
    partial class Frm_Process
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lv_process = new System.Windows.Forms.ListView();
            this.编号 = new System.Windows.Forms.ColumnHeader();
            this.工具名称 = new System.Windows.Forms.ColumnHeader();
            this.描述 = new System.Windows.Forms.ColumnHeader();
            this.结果 = new System.Windows.Forms.ColumnHeader();
            this.耗时 = new System.Windows.Forms.ColumnHeader();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lv_process);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(285, 588);
            this.panel1.TabIndex = 0;
            // 
            // lv_process
            // 
            this.lv_process.BackColor = System.Drawing.Color.White;
            this.lv_process.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lv_process.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.编号,
            this.工具名称,
            this.描述,
            this.结果,
            this.耗时});
            this.lv_process.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_process.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lv_process.FullRowSelect = true;
            this.lv_process.GridLines = true;
            this.lv_process.Location = new System.Drawing.Point(0, 0);
            this.lv_process.Margin = new System.Windows.Forms.Padding(0);
            this.lv_process.Name = "lv_process";
            this.lv_process.Size = new System.Drawing.Size(285, 588);
            this.lv_process.TabIndex = 0;
            this.lv_process.UseCompatibleStateImageBehavior = false;
            this.lv_process.View = System.Windows.Forms.View.Details;
            this.lv_process.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lv_process_MouseDoubleClick);
            // 
            // 编号
            // 
            this.编号.Text = "编号";
            this.编号.Width = 40;
            // 
            // 工具名称
            // 
            this.工具名称.Text = "工具名称";
            this.工具名称.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.工具名称.Width = 80;
            // 
            // 描述
            // 
            this.描述.Text = "描述";
            this.描述.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.描述.Width = 80;
            // 
            // 结果
            // 
            this.结果.Text = "结果";
            this.结果.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.结果.Width = 40;
            // 
            // 耗时
            // 
            this.耗时.Text = "耗时";
            this.耗时.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.耗时.Width = 40;
            // 
            // Frm_Process
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 588);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Process";
            this.Text = "流程";
            this.Load += new System.EventHandler(this.Frm_Process_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lv_process;
        private System.Windows.Forms.ColumnHeader 编号;
        private System.Windows.Forms.ColumnHeader 工具名称;
        private System.Windows.Forms.ColumnHeader 描述;
        private System.Windows.Forms.ColumnHeader 结果;
        private System.Windows.Forms.ColumnHeader 耗时;
    }
}