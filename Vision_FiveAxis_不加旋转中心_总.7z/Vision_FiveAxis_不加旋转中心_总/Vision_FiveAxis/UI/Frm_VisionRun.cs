﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.IO.Ports;
using HalconDotNet;
using Camera;
using BLL;
using Parameter;
using System.Runtime.Serialization.Formatters.Binary;
using Communicate;
using Data;

namespace Vision_FiveAxis
{
    public partial class Frm_VisionRun : Form
    {
        #region 属性字段
        private static Frm_VisionRun _instance;
        public static Frm_VisionRun Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Frm_VisionRun();
                }
                return _instance;
            }
        }
        //窗口句柄
        public HTuple hwi = Frm_ShowImage.Instance.halconView1.HalconWindow;
        //图像
        public HObject outImage;
        HTuple hv_Width, hv_Height;
        //流程
        public BLLProcess bll = new BLLProcess();
        //模板参数
        public ModelParamers modelPara = new ModelParamers();
        //相机接口
        public AMKS camera_AMKS = new AMKS();
        //串口1参数
        public SerialPortParamer SPP1 = new SerialPortParamer();
        //串口2参数
        public SerialPortParamer SPP2 = new SerialPortParamer();
        //连续运行线程
        Thread threadRun;
        //模板保存信息文件名字
        public string fileName = null;
        //旋转中心参数
        public CircleCenterParam cirCenPara = new CircleCenterParam();
        //A轴校正参数
        public CalibraAAxisParam CAAP = new CalibraAAxisParam();
        //高度防呆参数
        public CalibraHeightCheckParam CHCP = new CalibraHeightCheckParam();
        //九点标定参数
        public CalibraNinePointParam CNPP = new CalibraNinePointParam();
        #endregion
        private Frm_VisionRun()
        {
            InitializeComponent();
            //最大化显示
            this.WindowState = FormWindowState.Maximized;
            //this.MaximumSize = new Size(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);
        }
        #region 初始化布局
        protected void Frm_InitialDock()
        {
            //Frm_Log.Instance.Show(this.pl_ShowDock, DockState.DockBottom);
            //Frm_Result.Instance.Show(this.pl_ShowDock, DockState.DockRight);
            //Frm_Process.Instance.Show(this.pl_ShowDock, DockState.DockLeft);
            //Frm_ShowImage.Instance.Show(this.pl_ShowDock);
            //this.pl_ShowDock.DockLeftPortion = 0.1;
            //this.pl_ShowDock.DockRightPortion = 0.23;
            this.pl_ShowDock1.Controls.Add(Frm_Process.Instance);
            this.pl_ShowDock2.Controls.Add(Frm_Result.Instance);
            this.pl_ShowDock3.Controls.Add(Frm_Log.Instance);
            this.pl_ShowDock4.Controls.Add(Frm_Tools.Instance);
            this.pl_ShowDock5.Controls.Add(Frm_ShowImage.Instance);
            Frm_Log.Instance.Dock = DockStyle.Fill;
            Frm_Result.Instance.Dock = DockStyle.Fill;
            Frm_Process.Instance.Dock = DockStyle.Fill;
            Frm_ShowImage.Instance.Dock = DockStyle.Fill;
            Frm_Tools.Instance.Dock = DockStyle.Fill;
            Frm_Log.Instance.Show();
            Frm_Result.Instance.Show();
            Frm_Process.Instance.Show();
            Frm_ShowImage.Instance.Show();
            Frm_Tools.Instance.Show();
        }
        #endregion
        #region 关闭窗体
        private void bt_CloseWindow_Click_1(object sender, EventArgs e)
        {
            camera_AMKS.CloseCamera();  //关闭相机
            if (threadRun != null)
            {
                threadRun.Abort();
            }
            if (bll.comm.thread != null)
            {
                bll.comm.thread.Abort();
            }
            if (bll.threadSend != null)
            {
                bll.threadSend.Abort();
            }
            //System.Environment.Exit(0);  //关闭消息
            this.Close();  //关闭窗体
        }
        #endregion
        #region 最小化窗体
        private void bt_MinWindow_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion
        #region 单次运行
        private void bt_Run_Click(object sender, EventArgs e)
        {
            #region 禁止功能
            bt_RunContinue.Enabled = false;
            toolStrip1.Enabled = false;
            bt_Run.Enabled = false;
            Frm_Process.Instance.Enabled = false;
            cb_AAxisCheck.Enabled = false;
            cb_HeightCheck.Enabled = false;
            #endregion
            //string info = null;
            //bll.RunProgram(camera_AMKS, Frm_ShowImage.Instance.halconView1.HalconWindow, ref modelPara, out info, SPP1, SPP2, fileName, cirCenPara, CAAP, CHCP);
            //outImage = bll.outImage;
            //Frm_Log.Instance.AddLog(0, info);
            //Frm_Result.Instance.AddResultData();
            Frm_Process.Instance.Run();  //运行
            #region 开启功能
            bt_RunContinue.Enabled = true;
            toolStrip1.Enabled = true;
            bt_Run.Enabled = true;
            Frm_Process.Instance.Enabled = true;
            cb_AAxisCheck.Enabled = true;
            cb_HeightCheck.Enabled = true;
            #endregion
        }
        #endregion
        #region 连续运行
        private void bt_RunContinue_Click(object sender, EventArgs e)
        {
            if (bt_RunContinue.Text == "连续运行")
            {
                #region 禁止功能
                bt_Run.Enabled = false;
                toolStrip1.Enabled = false;
                Frm_Process.Instance.Enabled = false;
                cb_AAxisCheck.Enabled = false;
                cb_HeightCheck.Enabled = false;
                #endregion
                threadRun = new Thread(RunMethod);
                threadRun.IsBackground = true;
                threadRun.Start();
                bt_RunContinue.Text = "停止运行";
            }
            else
            {
                #region 开启功能
                bt_Run.Enabled = true;
                toolStrip1.Enabled = true;
                Frm_Process.Instance.Enabled = true;
                cb_AAxisCheck.Enabled = true;
                cb_HeightCheck.Enabled = true;
                #endregion
                try
                {
                    threadRun.Abort();
                    bll.comm.thread.Abort();
                    bll.threadSend.Abort();
                }
                catch
                {
                    Frm_Log.Instance.AddLog(0, "结束线程错误");
                }
                bll.comm.IsConnect = false;
                bt_RunContinue.Text = "连续运行";
            }
        }

        void RunMethod()
        {
            while (true)
            {
                string info = null;
                int runNumb = bll.RunProgram(camera_AMKS, Frm_ShowImage.Instance.halconView1.HalconWindow, ref modelPara, out info, SPP1, SPP2, fileName, cirCenPara, CAAP, CHCP);
                if (runNumb != 0)
                {
                    Invoke(new Action(() =>
                    {
                        bt_RunContinue.Text = "连续运行";
                        #region 开启功能
                        bt_Run.Enabled = true;
                        toolStrip1.Enabled = true;
                        Frm_Process.Instance.Enabled = true;
                        cb_AAxisCheck.Enabled = true;
                        cb_HeightCheck.Enabled = true;
                        #endregion
                    }));
                    break;
                }
                outImage = bll.outImage;
                Frm_Log.Instance.AddLog(0, info);
                Frm_Result.Instance.AddResultData();
            }
        }
        #endregion
        #region 客户端
        private void 客户端ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_TCPClient.Instance.ShowDialog();
        }
        #endregion
        #region 服务器
        private void 服务器ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        #endregion
        #region 相机窗体拍照显示事件
        public void camera_GrabImageEvent(object sender, EventArgsDAL e)
        {
            if (outImage != null)
            {
                outImage.Dispose();
            }
            HOperatorSet.ClearWindow(hwi);
            HOperatorSet.CopyImage(e.Image, out outImage);
            HOperatorSet.GetImageSize(outImage, out hv_Width, out hv_Height);
            HOperatorSet.SetPart(hwi, 0, 0, hv_Height, hv_Width);
            HOperatorSet.DispObj(outImage, hwi);
            Frm_ShowImage.Instance.halconView1.Image = e.Image;
        }
        #endregion
        #region 窗体事件
        private void Frm_VisionRun_Load(object sender, EventArgs e)
        {
            Frm_InitialDock();
            //frm_CreateShapeModel.Instance.changeModelPara += ChangeModelPara;
            //初始化相机
            try
            {
                camera_AMKS.Initialize();  //初始化相机
                camera_AMKS.Open();  //打开相机
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化相机失败");
            }
            //读取模板参数
            try
            {
                fileName = INI.ContentValue("Model", "fileName", "./modelConfigure");
                Deserialize(modelPara, fileName + ".viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化模板参数错误");
            }
            //读取相机参数
            try
            {
                camera_AMKS.ReadCamPara();
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "加载相机参数失败");
            }
            try
            {
                //读取串口一参数
                Deserialize(SPP1, "SerialPort1.viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化串口一参数错误");
            }
            try
            {
                //读取串口二参数
                Deserialize(SPP2, "SerialPort2.viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化串口二参数错误");
            }
            try
            {
                //读取旋转中心参数
                Deserialize(cirCenPara, "CircleCenterPara.viso");
            }
            catch (Exception)
            {
                Frm_Log.Instance.AddLog(1, "初始化旋转中心参数错误");
            }
            try
            {
                //读取A轴校正参数
                Deserialize(CAAP, "CalibraAAxisParam.viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化A轴标定参数错误");
            }
            try
            {
                //读取高度防呆参数
                Deserialize(CHCP, "CalibraHeightCheckParam.viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化高度防呆参数错误");
            }
            //A轴校正开关初始化
            try
            {
                if (CAAP.isAAxisCheck)
                {
                    cb_AAxisCheck.Checked = true;
                }
                else
                {
                    cb_AAxisCheck.Checked = false;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化A轴开启功能错误");
            }
            //高度防呆开关初始化
            try
            {
                if (CHCP.isHeightCheck)
                {
                    cb_HeightCheck.Checked = true;
                }
                else
                {
                    cb_HeightCheck.Checked = false;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化高度防呆功能错误");
            }
            //读取九点标定参数
            try
            {
                Deserialize(CNPP, @"Parameter\calibraNinePointParam.viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "初始化九点标定参数错误");
            }
        }
        #endregion
        #region 委托传模板参数
        public void ChangeModelPara(ModelParamers Param)
        {
            this.modelPara = Param;
        }
        #endregion
        #region 序列化反序列化
        //序列化
        public void Serialize(Object obj, string path)
        {
            FileStream fs = new FileStream(path, FileMode.Create);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fs, obj);
            fs.Close();
        }
        //反序列化
        public void Deserialize(Object obj, string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            if (obj == modelPara)
            {
                modelPara = (ModelParamers)formatter.Deserialize(fs);
            }
            else if (obj == SPP1)
            {
                SPP1 = (SerialPortParamer)formatter.Deserialize(fs);
            }
            else if (obj == SPP2)
            {
                SPP2 = (SerialPortParamer)formatter.Deserialize(fs);
            }
            else if (obj == cirCenPara)
            {
                cirCenPara = (CircleCenterParam)formatter.Deserialize(fs);
            }
            else if (obj == CAAP)
            {
                CAAP = (CalibraAAxisParam)formatter.Deserialize(fs);
            }
            else if (obj == CHCP)
            {
                CHCP = (CalibraHeightCheckParam)formatter.Deserialize(fs);
            }
            else if (obj == CNPP)
            {
                CNPP = (CalibraNinePointParam)formatter.Deserialize(fs);
            }
            else if (obj == frm_CalibraRelativeValve.Instance.CRVP)
            {
                frm_CalibraRelativeValve.Instance.CRVP = (CalibraRelativeValveParam)formatter.Deserialize(fs);
            }
            else
            {
                Frm_Log.Instance.AddLog(1,"初始化参数错误");
            }
            fs.Close();
        }
        #endregion
        #region 串口通讯1
        private void 串口通讯ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_SerialPort.Instance.Show();
        }
        #endregion
        #region 读取程序
        private void 读取ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "请选择文件";
            ofd.Filter = "所有文件(*viso*)|*.viso*";
            ofd.RestoreDirectory = true;
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                bool isCon = ofd.FileName.Contains('.');
                if (isCon)
                {
                    string[] nameArray = ofd.FileName.Split('.');
                    fileName = nameArray[0];
                }
                else
                {
                    fileName = ofd.FileName;
                }
            }
            try
            {
                Deserialize(modelPara, fileName + "viso");
                INI.WritePrivateProfileString("Model", "fileName", fileName, "./modelConfigure");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "文件读取错误");
                return;
            }
        }
        #endregion
        #region 保存程序
        private void 保存ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "请选择文件夹";
            sfd.Filter = "所有文件(*viso*)|*.viso*";
            sfd.RestoreDirectory = true;
            sfd.FilterIndex = 1;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                bool isCon = sfd.FileName.Contains('.');
                if (isCon)
                {
                    string[] nameArray = sfd.FileName.Split('.');
                    fileName = nameArray[0];
                }
                else
                {
                    fileName = sfd.FileName;
                }
            }
            try
            {
                Serialize(modelPara, fileName + ".viso");  //保存模板参数
                INI.WritePrivateProfileString("Model", "fileName", fileName, "./modelConfigure");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "文件保存错误");
                return;
            }
        }
        #endregion
        #region A轴校正功能开关
        private void cb_AAxisCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_AAxisCheck.CheckState == CheckState.Checked)  //开启A轴校正功能
            {
                CAAP.isAAxisCheck = true;
                try
                {
                    Serialize(CAAP, "CalibraAAxisParam.viso");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "保存A轴校正参数失败");
                }
            }
            else  //关闭A轴校正功能
            {
                CAAP.isAAxisCheck = false;
                try
                {
                    Serialize(CAAP, "CalibraAAxisParam.viso");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "保存A轴校正参数失败");
                }
            }
        }
        #endregion
        #region 串口通讯2
        private void 串口通讯2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_SerialPort2.Instance.Show();
        }
        #endregion
        #region 高度防呆功能
        private void cb_HeightCheck_CheckedChanged(object sender, EventArgs e)
        {
            #region 网络连接
            if (!bll.comm.IsConnect)
            {
                int isConnect = bll.comm.ConnectServer(bll.ip, bll.port);  //连接服务器
                if (isConnect != 0)
                {
                    Frm_Log.Instance.AddLog(1, "TCP连接失败，设置高度防呆错误");
                    bll.comm.IsConnect = false;
                    return;
                }
            }
            #endregion
            if (cb_HeightCheck.CheckState == CheckState.Checked)
            {
                #region 发送指令启用高度防呆
                try
                {
                    bll.comm.SendMessage("00 F0 00 00 00 0B 01 10 3C 00 00 02 04 00 00 00 01");  //发送指令3
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "通信失败");
                    bll.comm.IsConnect = false;
                    bll.comm.thread.Abort();
                    return;
                }
                CHCP.isHeightCheck = true;
                Frm_Log.Instance.AddLog(1, "启用高度防呆功能");
                try
                {
                    Serialize(CHCP, "CalibraHeightCheckParam.viso");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "保存高度防呆功能参数失败");
                }
                #endregion
            }
            else
            {
                #region 发送指令关闭高度防呆
                try
                {
                    bll.comm.SendMessage("00 F0 00 00 00 0B 01 10 3C 00 00 02 04 00 00 00 00");  //发送指令3
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "通信失败");
                    bll.comm.IsConnect = false;
                    bll.comm.thread.Abort();
                    return;
                }
                CHCP.isHeightCheck = false;
                Frm_Log.Instance.AddLog(1, "关闭高度防呆功能");
                try
                {
                    Serialize(CHCP, "CalibraHeightCheckParam.viso");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "保存高度防呆功能参数失败");
                }
                #endregion
            }
        }
        #endregion
    }
}
