﻿namespace Vision_FiveAxis
{
    partial class Frm_VisionRun
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_VisionRun));
            this.panel1 = new System.Windows.Forms.Panel();
            this.bt_MinWindow = new System.Windows.Forms.Button();
            this.bt_CloseWindow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.读取ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.保存ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.串口通讯ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.串口通讯2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cb_HeightCheck = new System.Windows.Forms.CheckBox();
            this.cb_AAxisCheck = new System.Windows.Forms.CheckBox();
            this.bt_RunContinue = new System.Windows.Forms.Button();
            this.bt_Run = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pl_ShowDock = new System.Windows.Forms.Panel();
            this.pl_ShowDock3 = new System.Windows.Forms.Panel();
            this.pl_ShowDock5 = new System.Windows.Forms.Panel();
            this.pl_ShowDock2 = new System.Windows.Forms.Panel();
            this.Dock1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pl_ShowDock4 = new System.Windows.Forms.Panel();
            this.pl_ShowDock1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.pl_ShowDock.SuspendLayout();
            this.Dock1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel1.Controls.Add(this.bt_MinWindow);
            this.panel1.Controls.Add(this.bt_CloseWindow);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1034, 30);
            this.panel1.TabIndex = 2;
            // 
            // bt_MinWindow
            // 
            this.bt_MinWindow.BackColor = System.Drawing.Color.LightGray;
            this.bt_MinWindow.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_MinWindow.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_MinWindow.Image = global::Vision_FiveAxis.Properties.Resources.minus;
            this.bt_MinWindow.Location = new System.Drawing.Point(968, 0);
            this.bt_MinWindow.Margin = new System.Windows.Forms.Padding(0);
            this.bt_MinWindow.Name = "bt_MinWindow";
            this.bt_MinWindow.Size = new System.Drawing.Size(33, 30);
            this.bt_MinWindow.TabIndex = 10;
            this.bt_MinWindow.UseVisualStyleBackColor = false;
            this.bt_MinWindow.Click += new System.EventHandler(this.bt_MinWindow_Click_1);
            // 
            // bt_CloseWindow
            // 
            this.bt_CloseWindow.BackColor = System.Drawing.Color.LightGray;
            this.bt_CloseWindow.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_CloseWindow.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_CloseWindow.Image = global::Vision_FiveAxis.Properties.Resources.close;
            this.bt_CloseWindow.Location = new System.Drawing.Point(1001, 0);
            this.bt_CloseWindow.Margin = new System.Windows.Forms.Padding(0);
            this.bt_CloseWindow.Name = "bt_CloseWindow";
            this.bt_CloseWindow.Size = new System.Drawing.Size(33, 30);
            this.bt_CloseWindow.TabIndex = 9;
            this.bt_CloseWindow.UseVisualStyleBackColor = false;
            this.bt_CloseWindow.Click += new System.EventHandler(this.bt_CloseWindow_Click_1);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 30);
            this.label1.TabIndex = 4;
            this.label1.Text = "AimkseVision";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.toolStrip1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 30);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1034, 25);
            this.panel2.TabIndex = 3;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.AliceBlue;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1034, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.读取ToolStripMenuItem,
            this.保存ToolStripMenuItem1});
            this.toolStripDropDownButton1.Enabled = false;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(45, 22);
            this.toolStripDropDownButton1.Text = "文件";
            // 
            // 读取ToolStripMenuItem
            // 
            this.读取ToolStripMenuItem.Name = "读取ToolStripMenuItem";
            this.读取ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.读取ToolStripMenuItem.Text = "读取";
            this.读取ToolStripMenuItem.Click += new System.EventHandler(this.读取ToolStripMenuItem_Click);
            // 
            // 保存ToolStripMenuItem1
            // 
            this.保存ToolStripMenuItem1.Name = "保存ToolStripMenuItem1";
            this.保存ToolStripMenuItem1.Size = new System.Drawing.Size(100, 22);
            this.保存ToolStripMenuItem1.Text = "保存";
            this.保存ToolStripMenuItem1.Click += new System.EventHandler(this.保存ToolStripMenuItem1_Click);
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.串口通讯ToolStripMenuItem,
            this.串口通讯2ToolStripMenuItem});
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(45, 22);
            this.toolStripDropDownButton3.Text = "通讯";
            // 
            // 串口通讯ToolStripMenuItem
            // 
            this.串口通讯ToolStripMenuItem.Name = "串口通讯ToolStripMenuItem";
            this.串口通讯ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.串口通讯ToolStripMenuItem.Text = "串口通讯1";
            this.串口通讯ToolStripMenuItem.Click += new System.EventHandler(this.串口通讯ToolStripMenuItem_Click);
            // 
            // 串口通讯2ToolStripMenuItem
            // 
            this.串口通讯2ToolStripMenuItem.Name = "串口通讯2ToolStripMenuItem";
            this.串口通讯2ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.串口通讯2ToolStripMenuItem.Text = "串口通讯2";
            this.串口通讯2ToolStripMenuItem.Click += new System.EventHandler(this.串口通讯2ToolStripMenuItem_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.cb_HeightCheck);
            this.panel5.Controls.Add(this.cb_AAxisCheck);
            this.panel5.Controls.Add(this.bt_RunContinue);
            this.panel5.Controls.Add(this.bt_Run);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 55);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1034, 35);
            this.panel5.TabIndex = 5;
            // 
            // cb_HeightCheck
            // 
            this.cb_HeightCheck.AutoSize = true;
            this.cb_HeightCheck.Dock = System.Windows.Forms.DockStyle.Right;
            this.cb_HeightCheck.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_HeightCheck.Location = new System.Drawing.Point(860, 0);
            this.cb_HeightCheck.Name = "cb_HeightCheck";
            this.cb_HeightCheck.Size = new System.Drawing.Size(91, 35);
            this.cb_HeightCheck.TabIndex = 5;
            this.cb_HeightCheck.Text = "高度防呆";
            this.cb_HeightCheck.UseVisualStyleBackColor = true;
            this.cb_HeightCheck.CheckedChanged += new System.EventHandler(this.cb_HeightCheck_CheckedChanged);
            // 
            // cb_AAxisCheck
            // 
            this.cb_AAxisCheck.AutoSize = true;
            this.cb_AAxisCheck.Dock = System.Windows.Forms.DockStyle.Right;
            this.cb_AAxisCheck.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_AAxisCheck.Location = new System.Drawing.Point(951, 0);
            this.cb_AAxisCheck.Name = "cb_AAxisCheck";
            this.cb_AAxisCheck.Size = new System.Drawing.Size(83, 35);
            this.cb_AAxisCheck.TabIndex = 4;
            this.cb_AAxisCheck.Text = "A轴校正";
            this.cb_AAxisCheck.UseVisualStyleBackColor = true;
            this.cb_AAxisCheck.CheckedChanged += new System.EventHandler(this.cb_AAxisCheck_CheckedChanged);
            // 
            // bt_RunContinue
            // 
            this.bt_RunContinue.Dock = System.Windows.Forms.DockStyle.Left;
            this.bt_RunContinue.Location = new System.Drawing.Point(75, 0);
            this.bt_RunContinue.Margin = new System.Windows.Forms.Padding(0);
            this.bt_RunContinue.Name = "bt_RunContinue";
            this.bt_RunContinue.Size = new System.Drawing.Size(75, 35);
            this.bt_RunContinue.TabIndex = 3;
            this.bt_RunContinue.Text = "连续运行";
            this.bt_RunContinue.UseVisualStyleBackColor = true;
            this.bt_RunContinue.Click += new System.EventHandler(this.bt_RunContinue_Click);
            // 
            // bt_Run
            // 
            this.bt_Run.Dock = System.Windows.Forms.DockStyle.Left;
            this.bt_Run.Location = new System.Drawing.Point(0, 0);
            this.bt_Run.Margin = new System.Windows.Forms.Padding(0);
            this.bt_Run.Name = "bt_Run";
            this.bt_Run.Size = new System.Drawing.Size(75, 35);
            this.bt_Run.TabIndex = 0;
            this.bt_Run.Text = "单次运行";
            this.bt_Run.UseVisualStyleBackColor = true;
            this.bt_Run.Click += new System.EventHandler(this.bt_Run_Click);
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 736);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1034, 20);
            this.panel4.TabIndex = 6;
            // 
            // pl_ShowDock
            // 
            this.pl_ShowDock.Controls.Add(this.pl_ShowDock3);
            this.pl_ShowDock.Controls.Add(this.pl_ShowDock5);
            this.pl_ShowDock.Controls.Add(this.pl_ShowDock2);
            this.pl_ShowDock.Controls.Add(this.Dock1);
            this.pl_ShowDock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pl_ShowDock.Location = new System.Drawing.Point(0, 90);
            this.pl_ShowDock.Name = "pl_ShowDock";
            this.pl_ShowDock.Size = new System.Drawing.Size(1034, 646);
            this.pl_ShowDock.TabIndex = 9;
            // 
            // pl_ShowDock3
            // 
            this.pl_ShowDock3.BackColor = System.Drawing.Color.White;
            this.pl_ShowDock3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pl_ShowDock3.Location = new System.Drawing.Point(280, 544);
            this.pl_ShowDock3.Margin = new System.Windows.Forms.Padding(1);
            this.pl_ShowDock3.Name = "pl_ShowDock3";
            this.pl_ShowDock3.Size = new System.Drawing.Size(466, 102);
            this.pl_ShowDock3.TabIndex = 0;
            // 
            // pl_ShowDock5
            // 
            this.pl_ShowDock5.BackColor = System.Drawing.Color.White;
            this.pl_ShowDock5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pl_ShowDock5.Location = new System.Drawing.Point(280, 0);
            this.pl_ShowDock5.Name = "pl_ShowDock5";
            this.pl_ShowDock5.Size = new System.Drawing.Size(466, 646);
            this.pl_ShowDock5.TabIndex = 3;
            // 
            // pl_ShowDock2
            // 
            this.pl_ShowDock2.BackColor = System.Drawing.Color.White;
            this.pl_ShowDock2.Dock = System.Windows.Forms.DockStyle.Right;
            this.pl_ShowDock2.Location = new System.Drawing.Point(746, 0);
            this.pl_ShowDock2.Name = "pl_ShowDock2";
            this.pl_ShowDock2.Size = new System.Drawing.Size(288, 646);
            this.pl_ShowDock2.TabIndex = 1;
            // 
            // Dock1
            // 
            this.Dock1.BackColor = System.Drawing.Color.White;
            this.Dock1.Controls.Add(this.tableLayoutPanel1);
            this.Dock1.Dock = System.Windows.Forms.DockStyle.Left;
            this.Dock1.Location = new System.Drawing.Point(0, 0);
            this.Dock1.Name = "Dock1";
            this.Dock1.Size = new System.Drawing.Size(280, 646);
            this.Dock1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.pl_ShowDock4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pl_ShowDock1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(280, 646);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pl_ShowDock4
            // 
            this.pl_ShowDock4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pl_ShowDock4.Location = new System.Drawing.Point(0, 0);
            this.pl_ShowDock4.Margin = new System.Windows.Forms.Padding(0);
            this.pl_ShowDock4.Name = "pl_ShowDock4";
            this.pl_ShowDock4.Size = new System.Drawing.Size(280, 323);
            this.pl_ShowDock4.TabIndex = 0;
            // 
            // pl_ShowDock1
            // 
            this.pl_ShowDock1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pl_ShowDock1.Location = new System.Drawing.Point(0, 323);
            this.pl_ShowDock1.Margin = new System.Windows.Forms.Padding(0);
            this.pl_ShowDock1.Name = "pl_ShowDock1";
            this.pl_ShowDock1.Size = new System.Drawing.Size(280, 323);
            this.pl_ShowDock1.TabIndex = 1;
            // 
            // Frm_VisionRun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 756);
            this.Controls.Add(this.pl_ShowDock);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "Frm_VisionRun";
            this.Text = "AMKS";
            this.Load += new System.EventHandler(this.Frm_VisionRun_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.pl_ShowDock.ResumeLayout(false);
            this.Dock1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt_MinWindow;
        private System.Windows.Forms.Button bt_CloseWindow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button bt_Run;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bt_RunContinue;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem 读取ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 保存ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripMenuItem 串口通讯ToolStripMenuItem;
        private System.Windows.Forms.CheckBox cb_AAxisCheck;
        private System.Windows.Forms.ToolStripMenuItem 串口通讯2ToolStripMenuItem;
        private System.Windows.Forms.CheckBox cb_HeightCheck;
        private System.Windows.Forms.Panel pl_ShowDock;
        private System.Windows.Forms.Panel pl_ShowDock5;
        private System.Windows.Forms.Panel pl_ShowDock2;
        private System.Windows.Forms.Panel Dock1;
        private System.Windows.Forms.Panel pl_ShowDock3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel pl_ShowDock4;
        private System.Windows.Forms.Panel pl_ShowDock1;

    }
}

