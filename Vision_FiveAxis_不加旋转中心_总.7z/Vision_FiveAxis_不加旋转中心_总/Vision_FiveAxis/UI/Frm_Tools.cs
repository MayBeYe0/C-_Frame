﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VisionTool.ImageToolDAL;

namespace Vision_FiveAxis
{
    public partial class Frm_Tools : Form
    {
        #region 属性字段
        public delegate void SelectDelegate(string type);
        public static event SelectDelegate SelectToolEvent;  //定义事件在流程窗体增加工具
        //单例窗体
        private static Frm_Tools _instance;
        public static Frm_Tools Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Frm_Tools();
                }
                return _instance;
            }
        }
        #endregion
        public Frm_Tools()
        {
            InitializeComponent();
            this.TopLevel = false;
        }

        #region 窗体事件
        private void Frm_Tools_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.CenterToParent();
            this.tvw_Tools.ImageList = this.imageList1;
            #region 图像处理
            TreeNode imageAcaquisitionNode = tvw_Tools.Nodes.Add("", "图像处理", 0, 0);
            {
                imageAcaquisitionNode.Nodes.Add("", ImageTool.Tool.采集图像.ToString(), 2, 2);
            }
            #endregion
        }
        #endregion
        #region TreeView控件双击事件
        private void tvw_Tools_DoubleClick(object sender, EventArgs e)
        {
            string type = tvw_Tools.SelectedNode.Text;
            SelectToolEvent(type);
        }
        #endregion
        
        
    }
}
