﻿namespace Vision_FiveAxis
{
    partial class Frm_Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lv_res = new System.Windows.Forms.ListView();
            this.日期 = new System.Windows.Forms.ColumnHeader();
            this.结果 = new System.Windows.Forms.ColumnHeader();
            this.X偏移量 = new System.Windows.Forms.ColumnHeader();
            this.Y偏移量 = new System.Windows.Forms.ColumnHeader();
            this.C偏移量 = new System.Windows.Forms.ColumnHeader();
            this.A偏移量 = new System.Windows.Forms.ColumnHeader();
            this.lv_result = new System.Windows.Forms.ListView();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lv_res);
            this.panel1.Controls.Add(this.lv_result);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(506, 467);
            this.panel1.TabIndex = 0;
            // 
            // lv_res
            // 
            this.lv_res.BackColor = System.Drawing.Color.White;
            this.lv_res.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lv_res.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.日期,
            this.结果,
            this.X偏移量,
            this.Y偏移量,
            this.C偏移量,
            this.A偏移量});
            this.lv_res.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_res.Location = new System.Drawing.Point(0, 0);
            this.lv_res.Name = "lv_res";
            this.lv_res.Size = new System.Drawing.Size(506, 467);
            this.lv_res.TabIndex = 1;
            this.lv_res.UseCompatibleStateImageBehavior = false;
            this.lv_res.View = System.Windows.Forms.View.Details;
            // 
            // 日期
            // 
            this.日期.Text = "日期";
            this.日期.Width = 120;
            // 
            // 结果
            // 
            this.结果.Text = "结果";
            this.结果.Width = 50;
            // 
            // X偏移量
            // 
            this.X偏移量.Text = "X偏移量(mm)";
            this.X偏移量.Width = 80;
            // 
            // Y偏移量
            // 
            this.Y偏移量.Text = "Y偏移量(mm)";
            this.Y偏移量.Width = 80;
            // 
            // C偏移量
            // 
            this.C偏移量.Text = "C偏移量(度)";
            this.C偏移量.Width = 80;
            // 
            // A偏移量
            // 
            this.A偏移量.Text = "A偏移量(度)";
            this.A偏移量.Width = 80;
            // 
            // lv_result
            // 
            this.lv_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_result.Location = new System.Drawing.Point(0, 0);
            this.lv_result.Name = "lv_result";
            this.lv_result.Size = new System.Drawing.Size(506, 467);
            this.lv_result.TabIndex = 0;
            this.lv_result.UseCompatibleStateImageBehavior = false;
            // 
            // Frm_Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 467);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Result";
            this.Text = "结果信息";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lv_result;
        private System.Windows.Forms.ListView lv_res;
        private System.Windows.Forms.ColumnHeader 日期;
        private System.Windows.Forms.ColumnHeader X偏移量;
        private System.Windows.Forms.ColumnHeader Y偏移量;
        private System.Windows.Forms.ColumnHeader C偏移量;
        private System.Windows.Forms.ColumnHeader 结果;
        private System.Windows.Forms.ColumnHeader A偏移量;
    }
}