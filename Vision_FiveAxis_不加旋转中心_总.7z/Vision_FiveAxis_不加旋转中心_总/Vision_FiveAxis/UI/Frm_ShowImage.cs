﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HalconDotNet;

namespace Vision_FiveAxis
{
    public partial class Frm_ShowImage : Form
    {
        #region 属性字段
        //单例窗体
        private static Frm_ShowImage _instance;
        public static Frm_ShowImage Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Frm_ShowImage();
                }
                return _instance;
            }
        }
        #endregion
        public Frm_ShowImage()
        {
            InitializeComponent();
            this.TopLevel = false;
        }
        //显示图像事件
        private void halconView1_HMouseWheelEvent(object sender)
        {
            HOperatorSet.DispObj(Frm_VisionRun.Instance.outImage, halconView1.HalconWindow);
        }
    }
}
