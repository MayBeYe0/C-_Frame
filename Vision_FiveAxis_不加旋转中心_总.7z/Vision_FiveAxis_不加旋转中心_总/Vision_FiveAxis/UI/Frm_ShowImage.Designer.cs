﻿namespace Vision_FiveAxis
{
    partial class Frm_ShowImage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            HalconDotNet.HWindow hWindow1 = new HalconDotNet.HWindow();
            this.panel1 = new System.Windows.Forms.Panel();
            this.halconView1 = new ViewControl.HalconView();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.halconView1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(705, 459);
            this.panel1.TabIndex = 1;
            // 
            // halconView1
            // 
            this.halconView1.BackColor = System.Drawing.SystemColors.Window;
            this.halconView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.halconView1.HalconWindow = hWindow1;
            this.halconView1.Image = null;
            this.halconView1.Location = new System.Drawing.Point(0, 0);
            this.halconView1.Name = "halconView1";
            this.halconView1.Size = new System.Drawing.Size(705, 459);
            this.halconView1.TabIndex = 0;
            this.halconView1.HMouseWheelEvent += new ViewControl.HalconView.HMouseDelegate(this.halconView1_HMouseWheelEvent);
            // 
            // Frm_ShowImage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 459);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_ShowImage";
            this.Text = "图像窗口";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        internal ViewControl.HalconView halconView1;
    }
}