﻿namespace Vision_FiveAxis
{
    partial class Frm_Log
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lv_log = new System.Windows.Forms.ListView();
            this.时间 = new System.Windows.Forms.ColumnHeader();
            this.日志信息 = new System.Windows.Forms.ColumnHeader();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lv_log);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(701, 225);
            this.panel1.TabIndex = 0;
            // 
            // lv_log
            // 
            this.lv_log.BackColor = System.Drawing.Color.White;
            this.lv_log.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lv_log.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.时间,
            this.日志信息});
            this.lv_log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_log.HoverSelection = true;
            this.lv_log.Location = new System.Drawing.Point(0, 0);
            this.lv_log.Name = "lv_log";
            this.lv_log.RightToLeftLayout = true;
            this.lv_log.Size = new System.Drawing.Size(701, 225);
            this.lv_log.TabIndex = 0;
            this.lv_log.UseCompatibleStateImageBehavior = false;
            this.lv_log.View = System.Windows.Forms.View.Details;
            // 
            // 时间
            // 
            this.时间.Text = "时间";
            this.时间.Width = 80;
            // 
            // 日志信息
            // 
            this.日志信息.Text = "日志信息";
            this.日志信息.Width = 500;
            // 
            // Frm_Log
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 225);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "Frm_Log";
            this.Text = "日志信息";
            this.Load += new System.EventHandler(this.Frm_Log_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lv_log;
        private System.Windows.Forms.ColumnHeader 时间;
        private System.Windows.Forms.ColumnHeader 日志信息;

    }
}