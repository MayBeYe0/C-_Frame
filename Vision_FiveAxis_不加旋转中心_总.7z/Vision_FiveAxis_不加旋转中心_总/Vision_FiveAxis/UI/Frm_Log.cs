﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Vision_FiveAxis
{
    public partial class Frm_Log : Form
    {
        #region 属性字段
        //单例窗体
        private static Frm_Log _instance;
        public static Frm_Log Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Frm_Log();
                }
                return _instance;
            }
        }
        #endregion
        private Frm_Log()
        {
            InitializeComponent();
            this.TopLevel = false;
        }
        #region 日志
        public void AddLog(int index, string infor)
        {
            if (lv_log.InvokeRequired)
            {
                Invoke(new Action(() =>
                {
                    if (lv_log.Items.Count < 30)
                    {
                        ListViewItem lv = new ListViewItem(DateTime.Now.ToString("HH:mm:ss"), index);
                        lv.SubItems.Add(infor);
                        lv_log.Items.Insert(0, lv);
                    }
                    else
                    {
                        ListViewItem lv = new ListViewItem(DateTime.Now.ToString("HH:mm:ss"), index);
                        lv.SubItems.Add(infor);
                        lv_log.Items.RemoveAt(lv_log.Items.Count - 1);
                        lv_log.Items.Insert(0, lv);
                    }
                }));
            }
            else
            {
                ListViewItem lv = new ListViewItem(DateTime.Now.ToString("HH:mm:ss"), index);
                lv.SubItems.Add(infor);
                lv_log.Items.Insert(0, lv);
            }
        }
        #endregion
        #region 窗体事件
        private void Frm_Log_Load(object sender, EventArgs e)
        {

        }
        #endregion
        


    }
}
