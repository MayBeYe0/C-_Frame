﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ReadCSVFile;

namespace Vision_FiveAxis
{
    public partial class Frm_Result : Form
    {
        #region 属性字段
        //单例窗体
        private static Frm_Result _instance;
        public static Frm_Result Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Frm_Result();
                }
                return _instance;
            }
        }
        #endregion
        private Frm_Result()
        {
            InitializeComponent();
            this.TopLevel = false;
        }
        #region 添加结果数据
        public void AddResultData()
        {
            #region 结果OK
            if (Frm_VisionRun.Instance.modelPara.ModelResult)  //结果OK
            {
                #region 跨线程访问
                if (lv_res.InvokeRequired)  //跨线程访问
                {
                    Invoke(new Action(() =>
                    {
                        ListViewItem lvi = new ListViewItem(DateTime.Now.ToString());
                        lvi.SubItems.Add("OK");
                        lvi.SubItems.Add(Frm_VisionRun.Instance.modelPara.OffsetX.ToString("f3"));
                        lvi.SubItems.Add(Frm_VisionRun.Instance.modelPara.OffsetY.ToString("f3"));
                        lvi.SubItems.Add(((double)Frm_VisionRun.Instance.modelPara.FindModelAngle).ToString("f3"));
                        if (lv_res.Items.Count < 99)
                        {
                            lv_res.Items.Add(lvi);
                        }
                        else
                        {
                            lv_res.Items.RemoveAt(0);
                            lv_res.Items.Add(lvi);
                        }
                        List<string[]> result = new List<string[]>();
                        if (lv_res.Items.Count == 1)
                        {
                            result.Add(new string[] { "日期", "结果", "X偏移", "Y偏移", "C角度", "A角度" });
                        }
                        result.Add(new string[] { DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "OK", Frm_VisionRun.Instance.modelPara.OffsetX.ToString("f3"), Frm_VisionRun.Instance.modelPara.OffsetY.ToString("f3"), ((double)Frm_VisionRun.Instance.modelPara.FindModelAngle).ToString("f3"), ((double)Frm_VisionRun.Instance.CAAP.Angle).ToString("f3") });
                        string FileName = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
                        string FilePath = "D:" + "\\" + FileName + ".CSV";
                        try
                        {
                            CSV.WriteCSV(FilePath, result, true);
                        }
                        catch
                        {
                            Frm_Log.Instance.AddLog(1, "保存数据失败");
                        }
                    }));
                }
                #endregion
                #region 本线程访问
                else  //本线程访问
                {
                    ListViewItem lvi = new ListViewItem(DateTime.Now.ToString());
                    lvi.SubItems.Add("OK");
                    lvi.SubItems.Add(Frm_VisionRun.Instance.modelPara.OffsetX.ToString("f3"));
                    lvi.SubItems.Add(Frm_VisionRun.Instance.modelPara.OffsetY.ToString("f3"));
                    lvi.SubItems.Add(((double)Frm_VisionRun.Instance.modelPara.FindModelAngle).ToString("f3"));
                    if (lv_res.Items.Count < 99)
                    {
                        lv_res.Items.Add(lvi);
                    }
                    else
                    {
                        lv_res.Items.RemoveAt(0);
                        lv_res.Items.Add(lvi);
                    }
                    List<string[]> result = new List<string[]>();
                    if (result.Count == 0)
                    {
                        result.Add(new string[] { "日期", "结果", "X偏移", "Y偏移", "角度", "A角度" });
                    }
                    result.Add(new string[] { DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "OK", Frm_VisionRun.Instance.modelPara.OffsetX.ToString("f3"), Frm_VisionRun.Instance.modelPara.OffsetY.ToString("f3"), ((double)Frm_VisionRun.Instance.modelPara.FindModelAngle).ToString("f3"), ((double)Frm_VisionRun.Instance.CAAP.Angle).ToString("f3") });
                    string FileName = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
                    string FilePath = "D:" + "\\" + FileName + ".CSV";
                    try
                    {
                        CSV.WriteCSV(FilePath, result, true);
                    }
                    catch
                    {
                        Frm_Log.Instance.AddLog(1, "保存数据失败");
                    }
                }
                #endregion
            }
            #endregion
            #region 结果NG
            else  //结果NG
            {
                #region 跨线程访问
                if (lv_res.InvokeRequired)  //跨线程访问
                {
                    Invoke(new Action(() =>
                    {
                        ListViewItem lvi = new ListViewItem(DateTime.Now.ToString());
                        lvi.SubItems.Add("NG");
                        lvi.SubItems.Add("10000.000");
                        lvi.SubItems.Add("10000.000");
                        lvi.SubItems.Add("10000.000");
                        lvi.SubItems.Add("10000.000");
                        if (lv_res.Items.Count < 99)
                        {
                            lv_res.Items.Add(lvi);
                        }
                        else
                        {
                            lv_res.Items.RemoveAt(0);
                            lv_res.Items.Add(lvi);
                        }
                        List<string[]> result = new List<string[]>();
                        if (result.Count == 0)
                        {
                            result.Add(new string[] { "日期", "结果", "X偏移", "Y偏移", "角度", "A角度" });
                        }
                        result.Add(new string[] { DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "NG", "10000.000", "10000.000", "10000.000", "10000.000" });
                        string FileName = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
                        string FilePath = "D:" + "\\" + FileName + ".CSV";
                        try
                        {
                            CSV.WriteCSV(FilePath, result, true);
                        }
                        catch
                        {
                            Frm_Log.Instance.AddLog(1, "保存数据失败");
                        }
                    }));
                }
                #endregion
                #region 本线程访问
                else  //本线程访问
                {
                    ListViewItem lvi = new ListViewItem(DateTime.Now.ToString());
                    lvi.SubItems.Add("NG");
                    lvi.SubItems.Add("10000.000");
                    lvi.SubItems.Add("10000.000");
                    lvi.SubItems.Add("10000.000");
                    lvi.SubItems.Add("10000.000");
                    if (lv_res.Items.Count < 99)
                    {
                        lv_res.Items.Add(lvi);
                    }
                    else
                    {
                        lv_res.Items.RemoveAt(0);
                        lv_res.Items.Add(lvi);
                    }
                    List<string[]> result = new List<string[]>();
                    if (result.Count == 0)
                    {
                        result.Add(new string[] { "日期", "结果", "X偏移", "Y偏移", "角度", "A角度" });
                    }
                    result.Add(new string[] { DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "NG", "10000.000", "10000.000", "10000.000", "10000.000" });
                    string FileName = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
                    string FilePath = "D:" + "\\" + FileName + ".CSV";
                    try
                    {
                        CSV.WriteCSV(FilePath, result, true);
                    }
                    catch
                    {
                        Frm_Log.Instance.AddLog(1, "保存数据失败");
                    }
                }
                #endregion
            }
            #endregion
        }
        #endregion
    }
}
