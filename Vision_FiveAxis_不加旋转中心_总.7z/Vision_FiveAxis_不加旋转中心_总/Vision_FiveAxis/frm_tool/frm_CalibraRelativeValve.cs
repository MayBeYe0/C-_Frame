﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HalconDotNet;
using System.Threading;
using ImageTool1212;
using Parameter;
using MathCal;

namespace Vision_FiveAxis
{
    public partial class frm_CalibraRelativeValve : Form
    {
        #region 单实例
        private static frm_CalibraRelativeValve _instance;
        public static frm_CalibraRelativeValve Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_CalibraRelativeValve();
                }
                return _instance;
            }
        }
        #endregion
        #region 属性字段
        HObject outImage = new HObject();  //图像
        imageTool1212 it = new imageTool1212();  //图像处理对象
        public CalibraRelativeValveParam CRVP = new CalibraRelativeValveParam();  //标定阀参数
        public mathCal math = new mathCal();
        #endregion
        public frm_CalibraRelativeValve()
        {
            InitializeComponent();
        }
        #region 获取针阀标准位置
        private void bt_GetPosition_Click(object sender, EventArgs e)
        {
            #region 拍照
            //串口连接
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm1.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm1.OpenSerialPort(Frm_VisionRun.Instance.SPP1);
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "串口通讯1失败");
                return;
            }
            Thread.Sleep(150);
            //相机拍照
            try
            {
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0255#");
                Frm_VisionRun.Instance.camera_AMKS.GrabImageOne(out outImage);  //开始拍照
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0000#");
                it.ShowImage(outImage, Frm_ShowImage.Instance.halconView1.HalconWindow);  //显示图像
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "拍照错误");
                return;
            }
            #endregion
            #region 抓圆获取标准位置坐标
            double[] valvePosition = new double[2];
            it.GetValvePosition(outImage, out valvePosition);
            CRVP.ValveStandX = valvePosition[0];
            CRVP.ValveStandY = valvePosition[1];
            #endregion
            #region 在界面显示坐标值
            tb_ValveX.Text = CRVP.ValveStandX.ToString("f3");
            tb_ValveY.Text = CRVP.ValveStandY.ToString("f3");
            #endregion
            #region 保存标准位置的值
            Frm_VisionRun.Instance.Serialize(CRVP, @"Parameter\CalibraRelativeValveParam.viso");
            #endregion
        }
        #endregion
        #region 校正针阀位置
        private void bt_CheckValve_Click(object sender, EventArgs e)
        {
            #region 初始化通信连接
            //和华中数控的TCP连接
            try
            {
                int isConnect = Frm_VisionRun.Instance.bll.ServerConnect();  //服务器连接
                if (isConnect != 0)
                {
                    Frm_Log.Instance.AddLog(0, "通信失败");
                    Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                    return;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(0, "通信失败");
                Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                return;
            }
            //串口连接
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm1.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm1.OpenSerialPort(Frm_VisionRun.Instance.SPP1);
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "串口通讯1失败");
                return;
            }
            #endregion
            #region 拍照
            try
            {
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0255#");
                Thread.Sleep(150);
                Frm_VisionRun.Instance.camera_AMKS.GrabImageOne(out outImage);  //开始拍照
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0000#");
                it.ShowImage(outImage, Frm_ShowImage.Instance.halconView1.HalconWindow);  //显示图像
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "拍照错误");
                return;
            }
            #endregion
            #region 抓圆获取坐标
            double[] valvePosition = new double[2];
            it.GetValvePosition(outImage, out valvePosition);
            CRVP.ValveRealX = valvePosition[0];
            CRVP.ValveRealY = valvePosition[1];
            #endregion
            #region 计算偏差值
            double ValveOffsetX = CRVP.ValveRealX - CRVP.ValveStandX;
            double ValveOffsetY = CRVP.ValveRealY - CRVP.ValveStandY;
            #endregion
            #region 发送补偿值给华中数控
            //偏差值转成16进制字符串
            string ValveOffsetXHex = math.ValueToHex(ValveOffsetX);
            string ValveOffsetYHex = math.ValueToHex(ValveOffsetY);
            //发送X字符串
            try
            {
                if (SendToHuaXOffset(ValveOffsetXHex) == 1)
                {
                    Frm_Log.Instance.AddLog(1, "返回X坐标指令错误");
                    return;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "发送X偏移量错误");
                return;
            }
            //发送Y字符串
            try
            {
                if (SendToHuaYOffset(ValveOffsetYHex) == 1)
                {
                    Frm_Log.Instance.AddLog(1, "返回Y坐标指令错误");
                    return;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "发送Y偏移量错误");
                return;
            }
            #endregion
            #region 在界面显示补偿值
            tb_OffsetX.Text = ValveOffsetX.ToString("f3");
            tb_OffsetY.Text = ValveOffsetY.ToString("f3");
            #endregion
            #region 保存补偿值
            try
            {
                Frm_VisionRun.Instance.Serialize(CRVP, @"Parameter\CalibraRelativeValveParam.viso");
                Frm_Log.Instance.AddLog(0, "保存成功");
            }
            catch
            {
                Frm_Log.Instance.AddLog(0, "保存失败");
                return;
            }
            #endregion
        }
        #endregion
        #region 窗体事件
        private void frm_CalibraRelativeValve_Load(object sender, EventArgs e)
        {
            this.FormClosing += frm_CalibraRelativeValve_FormClosing;  //注册窗口关闭事件
            #region 初始化参数标准位置的值和补偿值
            try
            {
                Frm_VisionRun.Instance.Deserialize(CRVP, @"Parameter\CalibraRelativeValveParam.viso");
            }
            catch
            {
                Frm_Log.Instance.AddLog(0, "初始化参数错误");
                return;
            }
            tb_ValveX.Text = CRVP.ValveStandX.ToString("f3");
            tb_ValveY.Text = CRVP.ValveStandY.ToString("f3");
            tb_OffsetX.Text = CRVP.OffsetX.ToString("f3");
            tb_OffsetY.Text = CRVP.OffsetY.ToString("f3");
            #endregion
        }
        #endregion
        #region 窗体关闭
        void frm_CalibraRelativeValve_FormClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        #region 发送X补偿量给华中数控
        int SendToHuaXOffset(string XOffset)
        {
            Frm_VisionRun.Instance.bll.comm.SendMessage(XOffset);  //发送指令X偏移量
            Thread.Sleep(80);
            if (Frm_VisionRun.Instance.bll.comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B D8 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region 发送Y补偿量给华中数控
        int SendToHuaYOffset(string YOffset)
        {
            Frm_VisionRun.Instance.bll.comm.SendMessage(YOffset);  //发送指令Y偏移量
            Thread.Sleep(80);
            if (Frm_VisionRun.Instance.bll.comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B D8 00 02 ")  //返回修改测高位置1完成指令成功
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        #endregion
        #region 确认参数
        private void bt_sure_Click(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.Serialize(CRVP, @"Parameter\CalibraRelativeValveParam.viso");
                Frm_Log.Instance.AddLog(0, "保存成功");
            }
            catch
            {
                Frm_Log.Instance.AddLog(0, "保存失败");
                return;
            }
        }
        #endregion
        #region 取消
        private void bt_cancel_Click(object sender, EventArgs e)
        {
            try
            {
                _instance = null;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "关闭窗体失败");
                return;
            }
            this.Close();
        }
        #endregion
    }
}
