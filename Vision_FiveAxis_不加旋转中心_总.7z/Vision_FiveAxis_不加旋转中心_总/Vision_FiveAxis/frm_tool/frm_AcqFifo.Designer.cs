﻿namespace Vision_FiveAxis
{
    partial class frm_AcqFifo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            HalconDotNet.HWindow hWindow1 = new HalconDotNet.HWindow();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bt_AcqFifoSure = new System.Windows.Forms.Button();
            this.bt_Cancel = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.halconView1 = new ViewControl.HalconView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_DownImage = new System.Windows.Forms.Button();
            this.bt_UpImage = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_ReadImagePath = new System.Windows.Forms.TextBox();
            this.bt_ReadImage = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1026, 642);
            this.panel2.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel4, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1026, 642);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1026, 21);
            this.panel3.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Controls.Add(this.bt_AcqFifoSure);
            this.panel4.Controls.Add(this.bt_Cancel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 612);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1026, 30);
            this.panel4.TabIndex = 1;
            // 
            // bt_AcqFifoSure
            // 
            this.bt_AcqFifoSure.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_AcqFifoSure.Location = new System.Drawing.Point(876, 0);
            this.bt_AcqFifoSure.Name = "bt_AcqFifoSure";
            this.bt_AcqFifoSure.Size = new System.Drawing.Size(75, 30);
            this.bt_AcqFifoSure.TabIndex = 4;
            this.bt_AcqFifoSure.Text = "确定";
            this.bt_AcqFifoSure.UseVisualStyleBackColor = true;
            this.bt_AcqFifoSure.Click += new System.EventHandler(this.bt_AcqFifoSure_Click);
            // 
            // bt_Cancel
            // 
            this.bt_Cancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_Cancel.Location = new System.Drawing.Point(951, 0);
            this.bt_Cancel.Name = "bt_Cancel";
            this.bt_Cancel.Size = new System.Drawing.Size(75, 30);
            this.bt_Cancel.TabIndex = 5;
            this.bt_Cancel.Text = "取消";
            this.bt_Cancel.UseVisualStyleBackColor = true;
            this.bt_Cancel.Click += new System.EventHandler(this.bt_Cancel_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.halconView1);
            this.panel5.Controls.Add(this.groupBox1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 21);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1026, 591);
            this.panel5.TabIndex = 2;
            // 
            // halconView1
            // 
            this.halconView1.Dock = System.Windows.Forms.DockStyle.Right;
            this.halconView1.HalconWindow = hWindow1;
            this.halconView1.Image = null;
            this.halconView1.Location = new System.Drawing.Point(387, 0);
            this.halconView1.Name = "halconView1";
            this.halconView1.Size = new System.Drawing.Size(639, 591);
            this.halconView1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_DownImage);
            this.groupBox1.Controls.Add(this.bt_UpImage);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_ReadImagePath);
            this.groupBox1.Controls.Add(this.bt_ReadImage);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 591);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "相机设置";
            // 
            // bt_DownImage
            // 
            this.bt_DownImage.Location = new System.Drawing.Point(248, 54);
            this.bt_DownImage.Name = "bt_DownImage";
            this.bt_DownImage.Size = new System.Drawing.Size(71, 34);
            this.bt_DownImage.TabIndex = 11;
            this.bt_DownImage.Text = "下一张";
            this.bt_DownImage.UseVisualStyleBackColor = true;
            this.bt_DownImage.Click += new System.EventHandler(this.bt_DownImage_Click);
            // 
            // bt_UpImage
            // 
            this.bt_UpImage.Location = new System.Drawing.Point(159, 54);
            this.bt_UpImage.Name = "bt_UpImage";
            this.bt_UpImage.Size = new System.Drawing.Size(71, 34);
            this.bt_UpImage.TabIndex = 10;
            this.bt_UpImage.Text = "上一张";
            this.bt_UpImage.UseVisualStyleBackColor = true;
            this.bt_UpImage.Click += new System.EventHandler(this.bt_UpImage_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(10, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 19);
            this.label4.TabIndex = 9;
            this.label4.Text = "路径：";
            // 
            // tb_ReadImagePath
            // 
            this.tb_ReadImagePath.Location = new System.Drawing.Point(79, 104);
            this.tb_ReadImagePath.Name = "tb_ReadImagePath";
            this.tb_ReadImagePath.Size = new System.Drawing.Size(277, 26);
            this.tb_ReadImagePath.TabIndex = 8;
            // 
            // bt_ReadImage
            // 
            this.bt_ReadImage.Location = new System.Drawing.Point(12, 54);
            this.bt_ReadImage.Name = "bt_ReadImage";
            this.bt_ReadImage.Size = new System.Drawing.Size(132, 34);
            this.bt_ReadImage.TabIndex = 7;
            this.bt_ReadImage.Text = "打 开 图 片";
            this.bt_ReadImage.UseVisualStyleBackColor = true;
            this.bt_ReadImage.Click += new System.EventHandler(this.bt_ReadImage_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1026, 642);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // frm_AcqFifo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 642);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_AcqFifo";
            this.Text = "采集图像";
            this.Load += new System.EventHandler(this.frm_AcqFifo_Load);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bt_AcqFifoSure;
        private System.Windows.Forms.Button bt_Cancel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private ViewControl.HalconView halconView1;
        private System.Windows.Forms.TextBox tb_ReadImagePath;
        private System.Windows.Forms.Button bt_ReadImage;
        private System.Windows.Forms.Button bt_DownImage;
        private System.Windows.Forms.Button bt_UpImage;
        private System.Windows.Forms.Label label4;

    }
}