﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using MathCal;

namespace Vision_FiveAxis
{
    public partial class frm_CalibraAAxis : Form
    {
        #region 属性字段
        //单例窗体
        private static frm_CalibraAAxis _instance;
        public static frm_CalibraAAxis Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_CalibraAAxis();
                }
                return _instance;
            }
        }
        public mathCal math = new mathCal();
        #endregion
        private frm_CalibraAAxis()
        {
            InitializeComponent();
        }
        #region 位置1测量高度
        private void bt_position1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm2.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm2.OpenSerialPort(Frm_VisionRun.Instance.SPP2);
                }
                Frm_VisionRun.Instance.bll.SPComm2.SendDataHex("02 4D 45 41 53 55 52 45 03");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "通讯失败");
                return;
            }
            Thread.Sleep(50);
            try
            {
                string height1 = Frm_VisionRun.Instance.bll.SPComm2.ReceiveDataHex();
                string heightDec1 = math.OptexHexToValue(height1);  //将16进制数据转换成对应的ASCII码
                Frm_VisionRun.Instance.CAAP.Height1 = double.Parse(heightDec1);  //传给参数类
                tb_position1.Text = Frm_VisionRun.Instance.CAAP.Height1.ToString("f3");  //显示
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "数据获取失败");
                return;
            }
            //给华中发送命令走到下一个点位
            if (!Frm_VisionRun.Instance.bll.comm.IsConnect)
            {
                try
                {
                    Frm_VisionRun.Instance.bll.comm.ConnectServer(Frm_VisionRun.Instance.bll.ip, Frm_VisionRun.Instance.bll.port);  //连接服务器
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "通讯失败");
                    return;
                }
            }
            try
            {
                Frm_VisionRun.Instance.bll.comm.SendMessage("00 F0 00 00 00 0B 01 10 3B CE 00 02 04 00 00 00 06 ");  //发送指令测高位置1完成
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "通讯失败");
                return;
            }
        }
        #endregion
        #region 位置2测量高度
        private void bt_position2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm2.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm2.OpenSerialPort(Frm_VisionRun.Instance.SPP2);
                }
                Frm_VisionRun.Instance.bll.SPComm2.SendDataHex("02 4D 45 41 53 55 52 45 03");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "通讯失败");
                return;
            }
            Thread.Sleep(50);
            try
            {
                string height2 = Frm_VisionRun.Instance.bll.SPComm2.ReceiveDataHex();
                string heightDec2 = math.OptexHexToValue(height2);  //将16进制数据转换成对应的ASCII码
                Frm_VisionRun.Instance.CAAP.Height2 = double.Parse(heightDec2);  //传给参数类
                tb_position2.Text = Frm_VisionRun.Instance.CAAP.Height2.ToString("f3");  //显示
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "数据获取失败");
                return;
            }
        }
        #endregion
        #region 修改Y1的坐标
        private void tb_positionY1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.CAAP.MechanY1 = double.Parse(tb_positionY1.Text);
            }
            catch
            {
                return;
            }
        }
        #endregion
        #region 修改Y2的坐标
        private void tb_positionY2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.CAAP.MechanY2 = double.Parse(tb_positionY2.Text);
            }
            catch
            {
                return;
            }
        }
        #endregion
        #region 窗体事件
        private void frm_CalibraAAxis_Load(object sender, EventArgs e)
        {
            this.FormClosing += frm_CalibraAAxisClosing;  //注册窗口关闭事件
            #region 初始化参数
            tb_position1.Text = Frm_VisionRun.Instance.CAAP.Height1.ToString("f3");
            tb_position2.Text = Frm_VisionRun.Instance.CAAP.Height2.ToString("f3");
            tb_positionY1.Text = Frm_VisionRun.Instance.CAAP.MechanY1.ToString("f3");
            tb_positionY2.Text = Frm_VisionRun.Instance.CAAP.MechanY2.ToString("f3");
            #endregion
        }
        void frm_CalibraAAxisClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        #region 确认
        private void bt_sure_Click(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CAAP, "CalibraAAxisParam.viso");  //保存A轴标定参数
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "保存参数失败");
                return;
            }
        }
        #endregion
        #region 取消
        private void bt_cancel_Click(object sender, EventArgs e)
        {
            try
            {
                _instance = null;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "关闭A轴标定窗体失败");
                return;
            }
            
            this.Close();
        }
        #endregion
    }
}
