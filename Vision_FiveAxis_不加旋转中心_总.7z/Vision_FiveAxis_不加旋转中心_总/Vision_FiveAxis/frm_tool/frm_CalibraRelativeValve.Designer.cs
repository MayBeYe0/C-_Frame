﻿namespace Vision_FiveAxis
{
    partial class frm_CalibraRelativeValve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_ValveY = new System.Windows.Forms.TextBox();
            this.bt_sure = new System.Windows.Forms.Button();
            this.tb_ValveX = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bt_cancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tb_OffsetX = new System.Windows.Forms.TextBox();
            this.tb_OffsetY = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_GetPosition = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_CheckValve = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_ValveY
            // 
            this.tb_ValveY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_ValveY.Enabled = false;
            this.tb_ValveY.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_ValveY.Location = new System.Drawing.Point(114, 35);
            this.tb_ValveY.Name = "tb_ValveY";
            this.tb_ValveY.Size = new System.Drawing.Size(105, 29);
            this.tb_ValveY.TabIndex = 38;
            this.tb_ValveY.Text = "100.00";
            // 
            // bt_sure
            // 
            this.bt_sure.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_sure.Location = new System.Drawing.Point(185, 0);
            this.bt_sure.Name = "bt_sure";
            this.bt_sure.Size = new System.Drawing.Size(75, 30);
            this.bt_sure.TabIndex = 4;
            this.bt_sure.Text = "确定";
            this.bt_sure.UseVisualStyleBackColor = true;
            this.bt_sure.Click += new System.EventHandler(this.bt_sure_Click);
            // 
            // tb_ValveX
            // 
            this.tb_ValveX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_ValveX.Enabled = false;
            this.tb_ValveX.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_ValveX.Location = new System.Drawing.Point(3, 35);
            this.tb_ValveX.Name = "tb_ValveX";
            this.tb_ValveX.Size = new System.Drawing.Size(105, 29);
            this.tb_ValveX.TabIndex = 37;
            this.tb_ValveX.Text = "100.00";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Controls.Add(this.bt_sure);
            this.panel4.Controls.Add(this.bt_cancel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 131);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(335, 30);
            this.panel4.TabIndex = 6;
            // 
            // bt_cancel
            // 
            this.bt_cancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_cancel.Location = new System.Drawing.Point(260, 0);
            this.bt_cancel.Name = "bt_cancel";
            this.bt_cancel.Size = new System.Drawing.Size(75, 30);
            this.bt_cancel.TabIndex = 5;
            this.bt_cancel.Text = "取消";
            this.bt_cancel.UseVisualStyleBackColor = true;
            this.bt_cancel.Click += new System.EventHandler(this.bt_cancel_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(5, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 22);
            this.label1.TabIndex = 35;
            this.label1.Text = "X";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.tb_OffsetX, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tb_OffsetY, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_ValveX, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tb_ValveY, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.bt_GetPosition, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.bt_CheckValve, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(335, 129);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tb_OffsetX
            // 
            this.tb_OffsetX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_OffsetX.Enabled = false;
            this.tb_OffsetX.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_OffsetX.Location = new System.Drawing.Point(3, 99);
            this.tb_OffsetX.Name = "tb_OffsetX";
            this.tb_OffsetX.Size = new System.Drawing.Size(105, 29);
            this.tb_OffsetX.TabIndex = 44;
            this.tb_OffsetX.Text = "0.000";
            // 
            // tb_OffsetY
            // 
            this.tb_OffsetY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_OffsetY.Enabled = false;
            this.tb_OffsetY.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_OffsetY.Location = new System.Drawing.Point(114, 99);
            this.tb_OffsetY.Name = "tb_OffsetY";
            this.tb_OffsetY.Size = new System.Drawing.Size(105, 29);
            this.tb_OffsetY.TabIndex = 43;
            this.tb_OffsetY.Text = "0.000";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(116, 5);
            this.label3.Margin = new System.Windows.Forms.Padding(5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 22);
            this.label3.TabIndex = 35;
            this.label3.Text = "Y";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt_GetPosition
            // 
            this.bt_GetPosition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_GetPosition.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_GetPosition.Location = new System.Drawing.Point(225, 35);
            this.bt_GetPosition.Name = "bt_GetPosition";
            this.bt_GetPosition.Size = new System.Drawing.Size(107, 26);
            this.bt_GetPosition.TabIndex = 39;
            this.bt_GetPosition.Text = "获  取";
            this.bt_GetPosition.UseVisualStyleBackColor = true;
            this.bt_GetPosition.Click += new System.EventHandler(this.bt_GetPosition_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(227, 5);
            this.label2.Margin = new System.Windows.Forms.Padding(5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 22);
            this.label2.TabIndex = 35;
            this.label2.Text = "标准位置";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt_CheckValve
            // 
            this.bt_CheckValve.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_CheckValve.Location = new System.Drawing.Point(225, 99);
            this.bt_CheckValve.Name = "bt_CheckValve";
            this.bt_CheckValve.Size = new System.Drawing.Size(107, 27);
            this.bt_CheckValve.TabIndex = 40;
            this.bt_CheckValve.Text = "校  正";
            this.bt_CheckValve.UseVisualStyleBackColor = true;
            this.bt_CheckValve.Click += new System.EventHandler(this.bt_CheckValve_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(227, 69);
            this.label4.Margin = new System.Windows.Forms.Padding(5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 22);
            this.label4.TabIndex = 41;
            this.label4.Text = "针头校正";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(5, 69);
            this.label5.Margin = new System.Windows.Forms.Padding(5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 22);
            this.label5.TabIndex = 42;
            this.label5.Text = "X补偿量";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(116, 69);
            this.label6.Margin = new System.Windows.Forms.Padding(5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 22);
            this.label6.TabIndex = 35;
            this.label6.Text = "Y补偿量";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_CalibraRelativeValve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 161);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_CalibraRelativeValve";
            this.Text = "阀位置校正";
            this.Load += new System.EventHandler(this.frm_CalibraRelativeValve_Load);
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_ValveY;
        private System.Windows.Forms.Button bt_sure;
        private System.Windows.Forms.TextBox tb_ValveX;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bt_cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_GetPosition;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_CheckValve;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_OffsetX;
        private System.Windows.Forms.TextBox tb_OffsetY;
    }
}