﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ImageTool1212;
using HalconDotNet;
using Parameter;
using Data;
using System.Threading;
using MathCal;

namespace Vision_FiveAxis
{
    public delegate void ChangeModelPara(ModelParamers modelPara);
    public partial class frm_CreateShapeModel : Form
    {
        public ChangeModelPara changeModelPara;
        imageTool1212 it = new imageTool1212();  //图像处理
        HTuple ModelID;
        ModelParamers modelParam = new ModelParamers();  //模板参数
        mathCal maCal = new mathCal();  //计算对象
        private frm_CreateShapeModel()
        {
            InitializeComponent();
        }
        #region 单实例
        private static frm_CreateShapeModel _instance;
        public static frm_CreateShapeModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_CreateShapeModel();
                }
                return _instance;
            }
        }
        #endregion
        #region 窗体事件
        private void frm_CreateShapeModel_Load(object sender, EventArgs e)
        {
            changeModelPara += Frm_VisionRun.Instance.ChangeModelPara;
            Instance.TopMost = true;
            this.FormClosing += frm_AcqFifo_FormClosing;  //注册窗口关闭事件
            #region 初始化模板参数
            modelParam = Frm_VisionRun.Instance.modelPara;
            nud_MinContrast.Value = Frm_VisionRun.Instance.modelPara.MinContrast;
            nud_MinContrastThres.Value = Frm_VisionRun.Instance.modelPara.MinContrastThres;
            nud_ScaleMin.Value = (decimal)Frm_VisionRun.Instance.modelPara.ScaleMin;
            nud_ScaleMax.Value = (decimal)Frm_VisionRun.Instance.modelPara.ScaleMax;
            nud_MinScore.Value = (decimal)Frm_VisionRun.Instance.modelPara.MinScore;
            nud_MinNum.Value = Frm_VisionRun.Instance.modelPara.MinNum;
            cb_NumLevels.Text = Frm_VisionRun.Instance.modelPara.NumLevels;
            nud_AngleStart.Value = Frm_VisionRun.Instance.modelPara.AngleStart;
            nud_AngleExtent.Value = Frm_VisionRun.Instance.modelPara.AngleExtent;
            tb_ModelOffsetX.Text = modelParam.ModelOffsetX.ToString("f3");
            tb_ModelOffsetY.Text = modelParam.ModelOffsetY.ToString("f3");
            #endregion
        }
        #endregion
        #region 窗体关闭
        void frm_AcqFifo_FormClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
            //this.Visible = false;
            
        }
        #endregion
        #region 创建模板
        private void bt_CreateModel_Click(object sender, EventArgs e)
        {
            Frm_ShowImage.Instance.halconView1.IsZoom = false;  //取消图像缩放
            Frm_ShowImage.Instance.halconView1.ContextMenuStrip = null;  //取消右键菜单栏
            Instance.TopMost = false;  //关闭窗口置顶
            int numb = Convert.ToInt16(((Button)sender).Tag);  // 0 是圆形，1是矩形
            Frm_ShowImage.Instance.halconView1.Focus();
            try
            {
                it.CreateModel(Frm_VisionRun.Instance.outImage, out ModelID, ref modelParam, Frm_ShowImage.Instance.halconView1.HalconWindow, numb);
            }
            catch
            {
                MessageBox.Show("创建模板失败");
            }
            it.ClearWindow(Frm_ShowImage.Instance.halconView1.HalconWindow);
            try
            {
                it.ShowImage(Frm_VisionRun.Instance.outImage, Frm_ShowImage.Instance.halconView1.HalconWindow);
                it.ShowModelContours(modelParam, Frm_ShowImage.Instance.halconView1.HalconWindow);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "轮廓显示错误");
                return;
            }
            this.panel3.Focus();
            Frm_ShowImage.Instance.halconView1.IsZoom = true;  //打开图像缩放
            Instance.TopMost = true;  //打开窗口置顶
            Frm_VisionRun.Instance.modelPara = modelParam;  //传参数
            Frm_VisionRun.Instance.bll.ModelID = null;  //设置模板为空，重新读取
        }
        #endregion
        #region 打开模板
        private void bt_ReadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "请选择文件";
            ofd.Filter = "所有文件(*viso*)|*.viso*";
            ofd.RestoreDirectory = true;
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                bool isCon = ofd.FileName.Contains('.');
                if (isCon)
                {
                    string[] nameArray = ofd.FileName.Split('.');
                    Frm_VisionRun.Instance.fileName = nameArray[0];
                }
                else
                {
                    Frm_VisionRun.Instance.fileName = ofd.FileName;
                }
            }
            try
            {
                Frm_VisionRun.Instance.Deserialize(Frm_VisionRun.Instance.modelPara, Frm_VisionRun.Instance.fileName + ".viso");  //读取模板参数
            }
            catch
            {
                Frm_Log.Instance.AddLog(1,"模板参数导入失败");
                return;
            }
            try
            {
                Frm_VisionRun.Instance.bll.ModelID = null;  //设置模板为空，重新读取
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "读取模板失败");
                return;
            }
            try
            {
                INI.WritePrivateProfileString("Model", "fileName", Frm_VisionRun.Instance.fileName, "./modelConfigure");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "读取模板失败");
                return;
            }
        }
        #endregion
        #region 保存模板
        private void bt_WriteModel_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "请选择文件夹";
            sfd.Filter = "所有文件(*viso*)|*.viso*";
            sfd.RestoreDirectory = true;
            sfd.FilterIndex = 1;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                bool isCon = sfd.FileName.Contains('.');
                if (isCon)
                {
                    string[] nameArray = sfd.FileName.Split('.');
                    Frm_VisionRun.Instance.fileName = nameArray[0];
                }
                else
                {
                    Frm_VisionRun.Instance.fileName = sfd.FileName;
                }
            }
            try
            {
                Frm_VisionRun.Instance.Serialize(modelParam, Frm_VisionRun.Instance.fileName + ".viso");  //保存模板参数
                Frm_VisionRun.Instance.modelPara = modelParam;  //传参
                it.SaveModel(ModelID, Frm_VisionRun.Instance.fileName + ".shm");  //保存模型
                Frm_VisionRun.Instance.bll.ModelID = null;  //传参
                INI.WritePrivateProfileString("Model", "fileName", Frm_VisionRun.Instance.fileName, "./modelConfigure");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "保存模板失败");
                return;
            }
        }
        #endregion
        #region 确认模板参数
        private void bt_ModelParaSure_Click(object sender, EventArgs e)
        {
            try
            {
                changeModelPara(modelParam);  //委托传模板参数
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改参数失败");
                return;
            }
        }
        #endregion
        #region 最小灰度值
        private void nud_Expose_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.MinContrast = (int)nud_MinContrast.Value;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 最小对比度
        private void nud_Gain_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.MinContrastThres = (int)nud_MinContrastThres.Value;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 缩放比例下限
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            modelParam.ScaleMin = (double)nud_ScaleMin.Value;
        }
        #endregion
        #region 缩放比例上限
        private void nud_ScaleMax_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.ScaleMax = (double)nud_ScaleMax.Value;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 最小分数
        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.MinScore = Convert.ToDouble(nud_MinScore.Value);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 最小组件数
        private void nud_MinNum_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.MinNum = Convert.ToInt16(nud_MinNum.Value);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 金字塔层数
        private void cb_NumLevels_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_NumLevels.Text == "auto")  //赋string类型值
                {
                    modelParam.NumLevels = cb_NumLevels.Text;
                }
                else  //赋int类型值
                {
                    modelParam.NumLevels = Convert.ToInt16(cb_NumLevels.Text);
                }

            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 起始角度
        private void nud_AngleStart_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.AngleStart = Convert.ToInt16(nud_AngleStart.Value);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 角度范围
        private void nud_AngleExtent_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.AngleExtent = Convert.ToInt16(nud_AngleExtent.Value);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 取消
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                _instance = null;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "关闭模板窗口失败");
                return;
            }
            this.Close();
        }
        #endregion
        #region 创建查找区域
        private void bt_FindArea_Click(object sender, EventArgs e)
        {
            try
            {
                Frm_ShowImage.Instance.halconView1.IsZoom = false;  //取消图像缩放
                Frm_ShowImage.Instance.halconView1.ContextMenuStrip = null;
                Instance.TopMost = false;  //关闭窗口置顶
                Frm_ShowImage.Instance.halconView1.Focus();
                it.CreateFindModelArea(ref modelParam);
                Frm_VisionRun.Instance.modelPara = modelParam;  //传参数
                this.panel3.Focus();
                Frm_ShowImage.Instance.halconView1.IsZoom = true;  //打开图像缩放
                Instance.TopMost = true;  //打开窗口置顶
            }
            catch
            {
                MessageBox.Show("创建匹配区域失败","错误提示",MessageBoxButtons.OKCancel);
            }
        }
        #endregion
        #region 发送模板中心
        private void bt_SendModelCenter_Click(object sender, EventArgs e)
        {
            //HTuple hv_Qx1, hv_Qy1;  //阀坐标
            HTuple hv_HomMat2D;  //相机转阀矩阵
            HTuple hv_HomMat2D1;  //九点标定矩阵
            #region 转换模板中心为阀坐标
            try
            {
                mathCal.ReadCabliPointNine("ValveHomMat2D.tup", out hv_HomMat2D);  //读取相机转阀坐标标定矩阵 
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "读取参数失败");
                return;
            }
            try
            {
                mathCal.ReadCabliPointNine("NineHomMat2D.tup", out hv_HomMat2D1);  //读取九点标定矩阵 
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "读取参数失败");
                return;
            }
            try
            {
                //模板中心像素转物理
                maCal.CalModelXY(hv_HomMat2D1, ref modelParam);
                //通过矩阵换算成点胶阀坐标
                //HOperatorSet.AffineTransPoint2d(hv_HomMat2D, -modelParam.CreateModelX, -modelParam.CreateModelY, out hv_Qx1, out hv_Qy1);
                //modelParam.CreateModelToValveX = hv_Qx1 + modelParam.ModelOffsetX;
                //modelParam.CreateModelToValveY = hv_Qy1 + modelParam.ModelOffsetY;

                modelParam.CreateModelToValveX = modelParam.DetX - modelParam.CreateModelX;
                modelParam.CreateModelToValveY = modelParam.DetY - modelParam.CreateModelY;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "矩阵转换错误");
                return;
            }
            try
            {
                Frm_VisionRun.Instance.bll.math.ModelCenterToHex(ref modelParam);  //偏差值转换成16进制字符串
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "请先做模板");
                return;
            }
            #endregion
            #region 发送模板中心XY坐标
            //是否连接服务器
            if (!Frm_VisionRun.Instance.bll.comm.IsConnect)
            {
                try
                {
                    Frm_VisionRun.Instance.bll.comm.ConnectServer(Frm_VisionRun.Instance.bll.ip, Frm_VisionRun.Instance.bll.port);  //连接服务器
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "通信失败");
                    Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                }
            }
            string SendDataX = "00 F0 00 00 00 0B 01 10 3B DD 00 02 04 ";
            SendDataX += modelParam.CreateModelHexX;
            string SendDataY = "00 F0 00 00 00 0B 01 10 3B DF 00 02 04 ";
            SendDataY += modelParam.CreateModelHexY;
            //发送X坐标
            try
            {
                Frm_VisionRun.Instance.bll.comm.SendMessage(SendDataX);  //发送指令OK
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "通信失败");
                Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                return;
            }
            Thread.Sleep(50);
            if (Frm_VisionRun.Instance.bll.comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B DD 00 02 ")  //返回修改OK指令成功
            {
                //发送Y坐标
                try
                {
                    Frm_VisionRun.Instance.bll.comm.SendMessage(SendDataY);  //发送Y坐标
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "通信失败");
                    Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                    return;
                }
                Thread.Sleep(50);
                if (Frm_VisionRun.Instance.bll.comm.ReceiveMessage == "00 F0 00 00 00 06 01 10 3B DF 00 02 ")  //返回修改OK指令成功
                {
                    Frm_Log.Instance.AddLog(0, "模板位置修改成功");
                }
                else
                {
                    Frm_Log.Instance.AddLog(1, "通信失败");
                    Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                    return;
                }
            }
            else
            {
                Frm_Log.Instance.AddLog(1, "通信失败");
                Frm_VisionRun.Instance.bll.comm.IsConnect = false;
                return;
            }
            #endregion
        }
        #endregion
        #region X补偿
        private void tb_ModelOffsetX_TextChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.ModelOffsetX = Convert.ToDouble(tb_ModelOffsetX.Text);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region Y补偿
        private void tb_ModelOffsetY_TextChanged(object sender, EventArgs e)
        {
            try
            {
                modelParam.ModelOffsetY = Convert.ToDouble(tb_ModelOffsetY.Text);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改数据失败");
                return;
            }
        }
        #endregion
        #region 设置模板中心点
        private void bt_setModelCenter_Click(object sender, EventArgs e)
        {
            HTuple hv_HomMat2D1;
            Frm_ShowImage.Instance.halconView1.IsZoom = false;  //取消图像缩放
            Frm_ShowImage.Instance.halconView1.ContextMenuStrip = null;  //取消右键菜单栏
            Instance.TopMost = false;  //关闭窗口置顶
            Frm_ShowImage.Instance.halconView1.Focus();
            try
            {
                mathCal.ReadCabliPointNine("NineHomMat2D.tup", out hv_HomMat2D1);  //读取九点标定矩阵 
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "读取九点标定文件失败");
                return;
            }
            try
            {
                it.SetModelCenter(ref ModelID, ref modelParam, Frm_VisionRun.Instance.hwi);  //修改模板像素中心点
                maCal.CalModelXY(hv_HomMat2D1, ref modelParam);  //修改模板世界坐标中心
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "设置模板中心错误");
                return;
            }
            Frm_ShowImage.Instance.halconView1.IsZoom = true;  //打开图像缩放
            Instance.TopMost = true;  //打开窗口置顶
            Frm_VisionRun.Instance.modelPara = modelParam;  //传参数
            Frm_VisionRun.Instance.bll.ModelID = null;  //设置模板为空，重新读取
        }
        #endregion
        
    }
}
