﻿namespace Vision_FiveAxis
{
    partial class frm_9PointCalib
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.bt_SaveCalibraFile1 = new System.Windows.Forms.Button();
            this.bt_SaveCalibraFile = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bt_StartCalib = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_X1 = new System.Windows.Forms.TextBox();
            this.tb_X2 = new System.Windows.Forms.TextBox();
            this.tb_X3 = new System.Windows.Forms.TextBox();
            this.tb_X4 = new System.Windows.Forms.TextBox();
            this.tb_X5 = new System.Windows.Forms.TextBox();
            this.tb_X6 = new System.Windows.Forms.TextBox();
            this.tb_X7 = new System.Windows.Forms.TextBox();
            this.tb_X8 = new System.Windows.Forms.TextBox();
            this.tb_X9 = new System.Windows.Forms.TextBox();
            this.tb_Y1 = new System.Windows.Forms.TextBox();
            this.tb_Y2 = new System.Windows.Forms.TextBox();
            this.tb_Y3 = new System.Windows.Forms.TextBox();
            this.tb_Y4 = new System.Windows.Forms.TextBox();
            this.tb_Y5 = new System.Windows.Forms.TextBox();
            this.tb_Y6 = new System.Windows.Forms.TextBox();
            this.tb_Y7 = new System.Windows.Forms.TextBox();
            this.tb_Y8 = new System.Windows.Forms.TextBox();
            this.tb_Y9 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_R1 = new System.Windows.Forms.TextBox();
            this.tb_R2 = new System.Windows.Forms.TextBox();
            this.tb_R3 = new System.Windows.Forms.TextBox();
            this.tb_R4 = new System.Windows.Forms.TextBox();
            this.tb_R5 = new System.Windows.Forms.TextBox();
            this.tb_R6 = new System.Windows.Forms.TextBox();
            this.tb_R7 = new System.Windows.Forms.TextBox();
            this.tb_R8 = new System.Windows.Forms.TextBox();
            this.tb_R9 = new System.Windows.Forms.TextBox();
            this.tb_C1 = new System.Windows.Forms.TextBox();
            this.tb_C2 = new System.Windows.Forms.TextBox();
            this.tb_C3 = new System.Windows.Forms.TextBox();
            this.tb_C4 = new System.Windows.Forms.TextBox();
            this.tb_C5 = new System.Windows.Forms.TextBox();
            this.tb_C6 = new System.Windows.Forms.TextBox();
            this.tb_C7 = new System.Windows.Forms.TextBox();
            this.tb_C8 = new System.Windows.Forms.TextBox();
            this.tb_C9 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tb_MaxGray = new System.Windows.Forms.TextBox();
            this.tb_MinGray = new System.Windows.Forms.TextBox();
            this.tb_MaxArea = new System.Windows.Forms.TextBox();
            this.tb_MinArea = new System.Windows.Forms.TextBox();
            this.tb_MedianFilter = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(419, 347);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.bt_SaveCalibraFile1);
            this.panel6.Controls.Add(this.bt_SaveCalibraFile);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(209, 317);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(210, 30);
            this.panel6.TabIndex = 5;
            // 
            // bt_SaveCalibraFile1
            // 
            this.bt_SaveCalibraFile1.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_SaveCalibraFile1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_SaveCalibraFile1.Location = new System.Drawing.Point(106, 0);
            this.bt_SaveCalibraFile1.Name = "bt_SaveCalibraFile1";
            this.bt_SaveCalibraFile1.Size = new System.Drawing.Size(104, 30);
            this.bt_SaveCalibraFile1.TabIndex = 1;
            this.bt_SaveCalibraFile1.Tag = "2";
            this.bt_SaveCalibraFile1.Text = "下相机矩阵保存";
            this.bt_SaveCalibraFile1.UseVisualStyleBackColor = true;
            this.bt_SaveCalibraFile1.Click += new System.EventHandler(this.bt_SaveCalibraFile_Click);
            // 
            // bt_SaveCalibraFile
            // 
            this.bt_SaveCalibraFile.Dock = System.Windows.Forms.DockStyle.Left;
            this.bt_SaveCalibraFile.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_SaveCalibraFile.Location = new System.Drawing.Point(0, 0);
            this.bt_SaveCalibraFile.Name = "bt_SaveCalibraFile";
            this.bt_SaveCalibraFile.Size = new System.Drawing.Size(105, 30);
            this.bt_SaveCalibraFile.TabIndex = 1;
            this.bt_SaveCalibraFile.Tag = "1";
            this.bt_SaveCalibraFile.Text = "上相机矩阵保存";
            this.bt_SaveCalibraFile.UseVisualStyleBackColor = true;
            this.bt_SaveCalibraFile.Click += new System.EventHandler(this.bt_SaveCalibraFile_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.bt_StartCalib);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 317);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(209, 30);
            this.panel5.TabIndex = 4;
            // 
            // bt_StartCalib
            // 
            this.bt_StartCalib.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_StartCalib.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_StartCalib.Location = new System.Drawing.Point(0, 0);
            this.bt_StartCalib.Name = "bt_StartCalib";
            this.bt_StartCalib.Size = new System.Drawing.Size(209, 30);
            this.bt_StartCalib.TabIndex = 0;
            this.bt_StartCalib.Text = "九  点  标  定";
            this.bt_StartCalib.UseVisualStyleBackColor = true;
            this.bt_StartCalib.Click += new System.EventHandler(this.bt_StartCalib_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tableLayoutPanel3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(209, 30);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(210, 287);
            this.panel4.TabIndex = 3;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.label5, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tb_X1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tb_X2, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.tb_X3, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.tb_X4, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.tb_X5, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.tb_X6, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.tb_X7, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.tb_X8, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.tb_X9, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y1, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y2, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y3, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y4, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y5, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y6, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y7, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y8, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.tb_Y9, 1, 9);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 10;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(210, 287);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(108, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 28);
            this.label5.TabIndex = 1;
            this.label5.Text = "Y";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 28);
            this.label6.TabIndex = 0;
            this.label6.Text = "X";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_X1
            // 
            this.tb_X1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X1.Location = new System.Drawing.Point(3, 31);
            this.tb_X1.Name = "tb_X1";
            this.tb_X1.Size = new System.Drawing.Size(99, 29);
            this.tb_X1.TabIndex = 2;
            this.tb_X1.Text = "-215";
            this.tb_X1.TextChanged += new System.EventHandler(this.tb_X1_TextChanged);
            // 
            // tb_X2
            // 
            this.tb_X2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X2.Location = new System.Drawing.Point(3, 59);
            this.tb_X2.Name = "tb_X2";
            this.tb_X2.ReadOnly = true;
            this.tb_X2.Size = new System.Drawing.Size(99, 29);
            this.tb_X2.TabIndex = 3;
            // 
            // tb_X3
            // 
            this.tb_X3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X3.Location = new System.Drawing.Point(3, 87);
            this.tb_X3.Name = "tb_X3";
            this.tb_X3.ReadOnly = true;
            this.tb_X3.Size = new System.Drawing.Size(99, 29);
            this.tb_X3.TabIndex = 3;
            // 
            // tb_X4
            // 
            this.tb_X4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X4.Location = new System.Drawing.Point(3, 115);
            this.tb_X4.Name = "tb_X4";
            this.tb_X4.ReadOnly = true;
            this.tb_X4.Size = new System.Drawing.Size(99, 29);
            this.tb_X4.TabIndex = 3;
            // 
            // tb_X5
            // 
            this.tb_X5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X5.Location = new System.Drawing.Point(3, 143);
            this.tb_X5.Name = "tb_X5";
            this.tb_X5.ReadOnly = true;
            this.tb_X5.Size = new System.Drawing.Size(99, 29);
            this.tb_X5.TabIndex = 3;
            // 
            // tb_X6
            // 
            this.tb_X6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X6.Location = new System.Drawing.Point(3, 171);
            this.tb_X6.Name = "tb_X6";
            this.tb_X6.ReadOnly = true;
            this.tb_X6.Size = new System.Drawing.Size(99, 29);
            this.tb_X6.TabIndex = 3;
            // 
            // tb_X7
            // 
            this.tb_X7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X7.Location = new System.Drawing.Point(3, 199);
            this.tb_X7.Name = "tb_X7";
            this.tb_X7.ReadOnly = true;
            this.tb_X7.Size = new System.Drawing.Size(99, 29);
            this.tb_X7.TabIndex = 3;
            // 
            // tb_X8
            // 
            this.tb_X8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X8.Location = new System.Drawing.Point(3, 227);
            this.tb_X8.Name = "tb_X8";
            this.tb_X8.ReadOnly = true;
            this.tb_X8.Size = new System.Drawing.Size(99, 29);
            this.tb_X8.TabIndex = 3;
            // 
            // tb_X9
            // 
            this.tb_X9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_X9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_X9.Location = new System.Drawing.Point(3, 255);
            this.tb_X9.Name = "tb_X9";
            this.tb_X9.ReadOnly = true;
            this.tb_X9.Size = new System.Drawing.Size(99, 29);
            this.tb_X9.TabIndex = 3;
            // 
            // tb_Y1
            // 
            this.tb_Y1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y1.Location = new System.Drawing.Point(108, 31);
            this.tb_Y1.Name = "tb_Y1";
            this.tb_Y1.Size = new System.Drawing.Size(99, 29);
            this.tb_Y1.TabIndex = 3;
            this.tb_Y1.Text = "-115";
            this.tb_Y1.TextChanged += new System.EventHandler(this.tb_X1_TextChanged);
            // 
            // tb_Y2
            // 
            this.tb_Y2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y2.Location = new System.Drawing.Point(108, 59);
            this.tb_Y2.Name = "tb_Y2";
            this.tb_Y2.ReadOnly = true;
            this.tb_Y2.Size = new System.Drawing.Size(99, 29);
            this.tb_Y2.TabIndex = 3;
            // 
            // tb_Y3
            // 
            this.tb_Y3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y3.Location = new System.Drawing.Point(108, 87);
            this.tb_Y3.Name = "tb_Y3";
            this.tb_Y3.ReadOnly = true;
            this.tb_Y3.Size = new System.Drawing.Size(99, 29);
            this.tb_Y3.TabIndex = 3;
            // 
            // tb_Y4
            // 
            this.tb_Y4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y4.Location = new System.Drawing.Point(108, 115);
            this.tb_Y4.Name = "tb_Y4";
            this.tb_Y4.ReadOnly = true;
            this.tb_Y4.Size = new System.Drawing.Size(99, 29);
            this.tb_Y4.TabIndex = 3;
            // 
            // tb_Y5
            // 
            this.tb_Y5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y5.Location = new System.Drawing.Point(108, 143);
            this.tb_Y5.Name = "tb_Y5";
            this.tb_Y5.ReadOnly = true;
            this.tb_Y5.Size = new System.Drawing.Size(99, 29);
            this.tb_Y5.TabIndex = 3;
            // 
            // tb_Y6
            // 
            this.tb_Y6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y6.Location = new System.Drawing.Point(108, 171);
            this.tb_Y6.Name = "tb_Y6";
            this.tb_Y6.ReadOnly = true;
            this.tb_Y6.Size = new System.Drawing.Size(99, 29);
            this.tb_Y6.TabIndex = 3;
            // 
            // tb_Y7
            // 
            this.tb_Y7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y7.Location = new System.Drawing.Point(108, 199);
            this.tb_Y7.Name = "tb_Y7";
            this.tb_Y7.ReadOnly = true;
            this.tb_Y7.Size = new System.Drawing.Size(99, 29);
            this.tb_Y7.TabIndex = 3;
            // 
            // tb_Y8
            // 
            this.tb_Y8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y8.Location = new System.Drawing.Point(108, 227);
            this.tb_Y8.Name = "tb_Y8";
            this.tb_Y8.ReadOnly = true;
            this.tb_Y8.Size = new System.Drawing.Size(99, 29);
            this.tb_Y8.TabIndex = 3;
            // 
            // tb_Y9
            // 
            this.tb_Y9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Y9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Y9.Location = new System.Drawing.Point(108, 255);
            this.tb_Y9.Name = "tb_Y9";
            this.tb_Y9.ReadOnly = true;
            this.tb_Y9.Size = new System.Drawing.Size(99, 29);
            this.tb_Y9.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 30);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(209, 287);
            this.panel3.TabIndex = 2;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.label4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tb_R1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tb_R2, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tb_R3, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.tb_R4, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.tb_R5, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.tb_R6, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.tb_R7, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.tb_R8, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.tb_R9, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.tb_C1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.tb_C2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.tb_C3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.tb_C4, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.tb_C5, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.tb_C6, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.tb_C7, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.tb_C8, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.tb_C9, 1, 9);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 10;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(209, 287);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(107, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 28);
            this.label4.TabIndex = 1;
            this.label4.Text = "C";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "R";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_R1
            // 
            this.tb_R1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R1.Location = new System.Drawing.Point(3, 31);
            this.tb_R1.Name = "tb_R1";
            this.tb_R1.ReadOnly = true;
            this.tb_R1.Size = new System.Drawing.Size(98, 29);
            this.tb_R1.TabIndex = 2;
            // 
            // tb_R2
            // 
            this.tb_R2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R2.Location = new System.Drawing.Point(3, 59);
            this.tb_R2.Name = "tb_R2";
            this.tb_R2.ReadOnly = true;
            this.tb_R2.Size = new System.Drawing.Size(98, 29);
            this.tb_R2.TabIndex = 3;
            // 
            // tb_R3
            // 
            this.tb_R3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R3.Location = new System.Drawing.Point(3, 87);
            this.tb_R3.Name = "tb_R3";
            this.tb_R3.ReadOnly = true;
            this.tb_R3.Size = new System.Drawing.Size(98, 29);
            this.tb_R3.TabIndex = 3;
            // 
            // tb_R4
            // 
            this.tb_R4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R4.Location = new System.Drawing.Point(3, 115);
            this.tb_R4.Name = "tb_R4";
            this.tb_R4.ReadOnly = true;
            this.tb_R4.Size = new System.Drawing.Size(98, 29);
            this.tb_R4.TabIndex = 3;
            // 
            // tb_R5
            // 
            this.tb_R5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R5.Location = new System.Drawing.Point(3, 143);
            this.tb_R5.Name = "tb_R5";
            this.tb_R5.ReadOnly = true;
            this.tb_R5.Size = new System.Drawing.Size(98, 29);
            this.tb_R5.TabIndex = 3;
            // 
            // tb_R6
            // 
            this.tb_R6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R6.Location = new System.Drawing.Point(3, 171);
            this.tb_R6.Name = "tb_R6";
            this.tb_R6.ReadOnly = true;
            this.tb_R6.Size = new System.Drawing.Size(98, 29);
            this.tb_R6.TabIndex = 3;
            // 
            // tb_R7
            // 
            this.tb_R7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R7.Location = new System.Drawing.Point(3, 199);
            this.tb_R7.Name = "tb_R7";
            this.tb_R7.ReadOnly = true;
            this.tb_R7.Size = new System.Drawing.Size(98, 29);
            this.tb_R7.TabIndex = 3;
            // 
            // tb_R8
            // 
            this.tb_R8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R8.Location = new System.Drawing.Point(3, 227);
            this.tb_R8.Name = "tb_R8";
            this.tb_R8.ReadOnly = true;
            this.tb_R8.Size = new System.Drawing.Size(98, 29);
            this.tb_R8.TabIndex = 3;
            // 
            // tb_R9
            // 
            this.tb_R9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_R9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_R9.Location = new System.Drawing.Point(3, 255);
            this.tb_R9.Name = "tb_R9";
            this.tb_R9.ReadOnly = true;
            this.tb_R9.Size = new System.Drawing.Size(98, 29);
            this.tb_R9.TabIndex = 3;
            // 
            // tb_C1
            // 
            this.tb_C1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C1.Location = new System.Drawing.Point(107, 31);
            this.tb_C1.Name = "tb_C1";
            this.tb_C1.ReadOnly = true;
            this.tb_C1.Size = new System.Drawing.Size(99, 29);
            this.tb_C1.TabIndex = 3;
            // 
            // tb_C2
            // 
            this.tb_C2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C2.Location = new System.Drawing.Point(107, 59);
            this.tb_C2.Name = "tb_C2";
            this.tb_C2.ReadOnly = true;
            this.tb_C2.Size = new System.Drawing.Size(99, 29);
            this.tb_C2.TabIndex = 3;
            // 
            // tb_C3
            // 
            this.tb_C3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C3.Location = new System.Drawing.Point(107, 87);
            this.tb_C3.Name = "tb_C3";
            this.tb_C3.ReadOnly = true;
            this.tb_C3.Size = new System.Drawing.Size(99, 29);
            this.tb_C3.TabIndex = 3;
            // 
            // tb_C4
            // 
            this.tb_C4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C4.Location = new System.Drawing.Point(107, 115);
            this.tb_C4.Name = "tb_C4";
            this.tb_C4.ReadOnly = true;
            this.tb_C4.Size = new System.Drawing.Size(99, 29);
            this.tb_C4.TabIndex = 3;
            // 
            // tb_C5
            // 
            this.tb_C5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C5.Location = new System.Drawing.Point(107, 143);
            this.tb_C5.Name = "tb_C5";
            this.tb_C5.ReadOnly = true;
            this.tb_C5.Size = new System.Drawing.Size(99, 29);
            this.tb_C5.TabIndex = 3;
            // 
            // tb_C6
            // 
            this.tb_C6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C6.Location = new System.Drawing.Point(107, 171);
            this.tb_C6.Name = "tb_C6";
            this.tb_C6.ReadOnly = true;
            this.tb_C6.Size = new System.Drawing.Size(99, 29);
            this.tb_C6.TabIndex = 3;
            // 
            // tb_C7
            // 
            this.tb_C7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C7.Location = new System.Drawing.Point(107, 199);
            this.tb_C7.Name = "tb_C7";
            this.tb_C7.ReadOnly = true;
            this.tb_C7.Size = new System.Drawing.Size(99, 29);
            this.tb_C7.TabIndex = 3;
            // 
            // tb_C8
            // 
            this.tb_C8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C8.Location = new System.Drawing.Point(107, 227);
            this.tb_C8.Name = "tb_C8";
            this.tb_C8.ReadOnly = true;
            this.tb_C8.Size = new System.Drawing.Size(99, 29);
            this.tb_C8.TabIndex = 3;
            // 
            // tb_C9
            // 
            this.tb_C9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_C9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_C9.Location = new System.Drawing.Point(107, 255);
            this.tb_C9.Name = "tb_C9";
            this.tb_C9.ReadOnly = true;
            this.tb_C9.Size = new System.Drawing.Size(99, 29);
            this.tb_C9.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(209, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(210, 30);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "实  际  位  置";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(209, 30);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "像  素  位  置";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(433, 386);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(425, 353);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "九点标定";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tb_MaxGray);
            this.tabPage2.Controls.Add(this.tb_MinGray);
            this.tabPage2.Controls.Add(this.tb_MaxArea);
            this.tabPage2.Controls.Add(this.tb_MinArea);
            this.tabPage2.Controls.Add(this.tb_MedianFilter);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(425, 353);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "标定参数";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tb_MaxGray
            // 
            this.tb_MaxGray.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_MaxGray.Location = new System.Drawing.Point(161, 242);
            this.tb_MaxGray.Name = "tb_MaxGray";
            this.tb_MaxGray.Size = new System.Drawing.Size(100, 26);
            this.tb_MaxGray.TabIndex = 1;
            this.tb_MaxGray.Text = "120";
            this.tb_MaxGray.TextChanged += new System.EventHandler(this.tb_MaxGray_TextChanged);
            // 
            // tb_MinGray
            // 
            this.tb_MinGray.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_MinGray.Location = new System.Drawing.Point(161, 190);
            this.tb_MinGray.Name = "tb_MinGray";
            this.tb_MinGray.Size = new System.Drawing.Size(100, 26);
            this.tb_MinGray.TabIndex = 1;
            this.tb_MinGray.Text = "10";
            this.tb_MinGray.TextChanged += new System.EventHandler(this.tb_MinGray_TextChanged);
            // 
            // tb_MaxArea
            // 
            this.tb_MaxArea.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_MaxArea.Location = new System.Drawing.Point(161, 137);
            this.tb_MaxArea.Name = "tb_MaxArea";
            this.tb_MaxArea.Size = new System.Drawing.Size(100, 26);
            this.tb_MaxArea.TabIndex = 1;
            this.tb_MaxArea.Text = "5000000";
            this.tb_MaxArea.TextChanged += new System.EventHandler(this.tb_MaxArea_TextChanged);
            // 
            // tb_MinArea
            // 
            this.tb_MinArea.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_MinArea.Location = new System.Drawing.Point(161, 84);
            this.tb_MinArea.Name = "tb_MinArea";
            this.tb_MinArea.Size = new System.Drawing.Size(100, 26);
            this.tb_MinArea.TabIndex = 1;
            this.tb_MinArea.Text = "240994";
            this.tb_MinArea.TextChanged += new System.EventHandler(this.tb_MinArea_TextChanged);
            // 
            // tb_MedianFilter
            // 
            this.tb_MedianFilter.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_MedianFilter.Location = new System.Drawing.Point(161, 29);
            this.tb_MedianFilter.Name = "tb_MedianFilter";
            this.tb_MedianFilter.Size = new System.Drawing.Size(100, 26);
            this.tb_MedianFilter.TabIndex = 1;
            this.tb_MedianFilter.Text = "20";
            this.tb_MedianFilter.TextChanged += new System.EventHandler(this.tb_MedianFilter_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(43, 247);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "灰度最大值:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(43, 195);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "灰度最小值:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(43, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "区域最大值:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(43, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "区域最小值:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(43, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "中值滤波:";
            // 
            // frm_9PointCalib
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 386);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_9PointCalib";
            this.Text = "九点标定";
            this.Load += new System.EventHandler(this.frm_9PointCalib_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_R1;
        private System.Windows.Forms.TextBox tb_R2;
        private System.Windows.Forms.TextBox tb_R3;
        private System.Windows.Forms.TextBox tb_R4;
        private System.Windows.Forms.TextBox tb_R5;
        private System.Windows.Forms.TextBox tb_R6;
        private System.Windows.Forms.TextBox tb_R7;
        private System.Windows.Forms.TextBox tb_R8;
        private System.Windows.Forms.TextBox tb_R9;
        private System.Windows.Forms.TextBox tb_C1;
        private System.Windows.Forms.TextBox tb_C2;
        private System.Windows.Forms.TextBox tb_C3;
        private System.Windows.Forms.TextBox tb_C4;
        private System.Windows.Forms.TextBox tb_C5;
        private System.Windows.Forms.TextBox tb_C6;
        private System.Windows.Forms.TextBox tb_C7;
        private System.Windows.Forms.TextBox tb_C8;
        private System.Windows.Forms.TextBox tb_C9;
        private System.Windows.Forms.Button bt_SaveCalibraFile;
        private System.Windows.Forms.Button bt_StartCalib;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_X1;
        private System.Windows.Forms.TextBox tb_X2;
        private System.Windows.Forms.TextBox tb_X3;
        private System.Windows.Forms.TextBox tb_X4;
        private System.Windows.Forms.TextBox tb_X5;
        private System.Windows.Forms.TextBox tb_X6;
        private System.Windows.Forms.TextBox tb_X7;
        private System.Windows.Forms.TextBox tb_X8;
        private System.Windows.Forms.TextBox tb_X9;
        private System.Windows.Forms.TextBox tb_Y1;
        private System.Windows.Forms.TextBox tb_Y2;
        private System.Windows.Forms.TextBox tb_Y3;
        private System.Windows.Forms.TextBox tb_Y4;
        private System.Windows.Forms.TextBox tb_Y5;
        private System.Windows.Forms.TextBox tb_Y6;
        private System.Windows.Forms.TextBox tb_Y7;
        private System.Windows.Forms.TextBox tb_Y8;
        private System.Windows.Forms.TextBox tb_Y9;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_MinGray;
        private System.Windows.Forms.TextBox tb_MaxArea;
        private System.Windows.Forms.TextBox tb_MinArea;
        private System.Windows.Forms.TextBox tb_MedianFilter;
        private System.Windows.Forms.TextBox tb_MaxGray;
        private System.Windows.Forms.Button bt_SaveCalibraFile1;
    }
}