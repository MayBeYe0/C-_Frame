﻿namespace Vision_FiveAxis
{
    partial class frm_CalibraAAxis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tb_position2 = new System.Windows.Forms.TextBox();
            this.tb_position1 = new System.Windows.Forms.TextBox();
            this.bt_position2 = new System.Windows.Forms.Button();
            this.bt_position1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_positionY1 = new System.Windows.Forms.TextBox();
            this.tb_positionY2 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bt_sure = new System.Windows.Forms.Button();
            this.bt_cancel = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 96);
            this.panel1.TabIndex = 2;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33112F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33444F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33445F));
            this.tableLayoutPanel1.Controls.Add(this.tb_position2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tb_position1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.bt_position2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.bt_position1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_positionY1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tb_positionY2, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(348, 95);
            this.tableLayoutPanel1.TabIndex = 27;
            // 
            // tb_position2
            // 
            this.tb_position2.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_position2.Location = new System.Drawing.Point(118, 65);
            this.tb_position2.Name = "tb_position2";
            this.tb_position2.ReadOnly = true;
            this.tb_position2.Size = new System.Drawing.Size(110, 26);
            this.tb_position2.TabIndex = 29;
            this.tb_position2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_position1
            // 
            this.tb_position1.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_position1.Location = new System.Drawing.Point(118, 34);
            this.tb_position1.Name = "tb_position1";
            this.tb_position1.ReadOnly = true;
            this.tb_position1.Size = new System.Drawing.Size(110, 26);
            this.tb_position1.TabIndex = 27;
            this.tb_position1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bt_position2
            // 
            this.bt_position2.Font = new System.Drawing.Font("宋体", 12F);
            this.bt_position2.Location = new System.Drawing.Point(234, 65);
            this.bt_position2.Name = "bt_position2";
            this.bt_position2.Size = new System.Drawing.Size(107, 25);
            this.bt_position2.TabIndex = 25;
            this.bt_position2.Tag = "2";
            this.bt_position2.Text = "位置二";
            this.bt_position2.UseVisualStyleBackColor = true;
            this.bt_position2.Click += new System.EventHandler(this.bt_position2_Click);
            // 
            // bt_position1
            // 
            this.bt_position1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_position1.Location = new System.Drawing.Point(234, 34);
            this.bt_position1.Name = "bt_position1";
            this.bt_position1.Size = new System.Drawing.Size(107, 24);
            this.bt_position1.TabIndex = 0;
            this.bt_position1.Tag = "1";
            this.bt_position1.Text = "位置一";
            this.bt_position1.UseVisualStyleBackColor = true;
            this.bt_position1.Click += new System.EventHandler(this.bt_position1_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(118, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 31);
            this.label1.TabIndex = 33;
            this.label1.Text = "高度值";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 31);
            this.label2.TabIndex = 33;
            this.label2.Text = "Y坐标";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_positionY1
            // 
            this.tb_positionY1.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_positionY1.Location = new System.Drawing.Point(3, 34);
            this.tb_positionY1.Name = "tb_positionY1";
            this.tb_positionY1.Size = new System.Drawing.Size(109, 26);
            this.tb_positionY1.TabIndex = 27;
            this.tb_positionY1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb_positionY1.TextChanged += new System.EventHandler(this.tb_positionY1_TextChanged);
            // 
            // tb_positionY2
            // 
            this.tb_positionY2.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_positionY2.Location = new System.Drawing.Point(3, 65);
            this.tb_positionY2.Name = "tb_positionY2";
            this.tb_positionY2.Size = new System.Drawing.Size(109, 26);
            this.tb_positionY2.TabIndex = 27;
            this.tb_positionY2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb_positionY2.TextChanged += new System.EventHandler(this.tb_positionY2_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Controls.Add(this.bt_sure);
            this.panel4.Controls.Add(this.bt_cancel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 98);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(348, 30);
            this.panel4.TabIndex = 3;
            // 
            // bt_sure
            // 
            this.bt_sure.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_sure.Location = new System.Drawing.Point(198, 0);
            this.bt_sure.Name = "bt_sure";
            this.bt_sure.Size = new System.Drawing.Size(75, 30);
            this.bt_sure.TabIndex = 4;
            this.bt_sure.Text = "确定";
            this.bt_sure.UseVisualStyleBackColor = true;
            this.bt_sure.Click += new System.EventHandler(this.bt_sure_Click);
            // 
            // bt_cancel
            // 
            this.bt_cancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_cancel.Location = new System.Drawing.Point(273, 0);
            this.bt_cancel.Name = "bt_cancel";
            this.bt_cancel.Size = new System.Drawing.Size(75, 30);
            this.bt_cancel.TabIndex = 5;
            this.bt_cancel.Text = "取消";
            this.bt_cancel.UseVisualStyleBackColor = true;
            this.bt_cancel.Click += new System.EventHandler(this.bt_cancel_Click);
            // 
            // frm_CalibraAAxis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 128);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_CalibraAAxis";
            this.Text = "A轴标定";
            this.Load += new System.EventHandler(this.frm_CalibraAAxis_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tb_position2;
        private System.Windows.Forms.TextBox tb_position1;
        private System.Windows.Forms.Button bt_position2;
        private System.Windows.Forms.Button bt_position1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_positionY1;
        private System.Windows.Forms.TextBox tb_positionY2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bt_sure;
        private System.Windows.Forms.Button bt_cancel;
    }
}