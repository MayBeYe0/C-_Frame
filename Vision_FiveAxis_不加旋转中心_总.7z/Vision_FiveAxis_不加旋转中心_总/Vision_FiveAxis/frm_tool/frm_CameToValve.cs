﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Parameter;
using MathCal;
using ImageTool1212;
using HalconDotNet;
using System.Threading;

namespace Vision_FiveAxis
{
    public partial class frm_CameToValve : Form
    {
        #region 单实例
        private static frm_CameToValve _instance;
        public static frm_CameToValve Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_CameToValve();
                }
                return _instance;
            }
        }
        #endregion
        #region 属性字段
        HObject outImage = new HObject();  //图像位置
        public CalibraValveParam CVP = new CalibraValveParam();  //阀标定参数
        mathCal maCal = new mathCal();  //计算对象
        imageTool1212 it = new imageTool1212();  //图像处理对象
        #endregion
        public frm_CameToValve()
        {
            InitializeComponent();
        }
        #region 获取圆中心位置
        private void bt_getPosition_Click(object sender, EventArgs e)
        {
            HTuple hv_HomMat2D1 = null;  //相机像素坐标To相机世界坐标
            HTuple hv_Qx1 = 0;  //换算后的模板中心在阀的坐标下的X坐标
            HTuple hv_Qy1 = 0;  //换算后的模板中心在阀的坐标下的Y坐标
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm1.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm1.OpenSerialPort(Frm_VisionRun.Instance.SPP1);
                }
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0255#");
                Thread.Sleep(200);
                Frm_VisionRun.Instance.camera_AMKS.GrabImageOne(out outImage);
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0000#");
                it.ShowImage(outImage, Frm_VisionRun.Instance.hwi);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "拍照失败");
            }
            try
            {
                it.FindValveCircle(outImage, out CVP);
                it.ShowCalibraValve(CVP, Frm_VisionRun.Instance.hwi);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "未找到圆心");
                return;
            }
            //将相机抓取的圆心转换成世界坐标
            try
            {
                hv_HomMat2D1 = it.ReadMatric();  //读取九点标定矩阵 
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "读取九点标定矩阵错误");
                return;
            }
            if (CVP != null)
            {
                try
                {
                    HOperatorSet.AffineTransPoint2d(hv_HomMat2D1, CVP.CircleCenterColumn, CVP.CircleCenterRow, out hv_Qx1, out hv_Qy1);
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "转换矩阵错误");
                    return;
                }
            }
            else
            {
                Frm_Log.Instance.AddLog(1, "请先获取圆中心位置");
            }
            CVP.CircleCenterX = hv_Qx1;
            CVP.CircleCenterY = hv_Qy1;
            tb_ModelX.Text = hv_Qx1.D.ToString("f3");
            tb_ModelY.Text = hv_Qy1.D.ToString("f3");
        }
        #endregion
        #region 窗体事件
        private void frm_CameToValve_Load(object sender, EventArgs e)
        {
            this.FormClosing += frm_CameToValve_FormClosing;  //注册窗口关闭事件
        }
        #endregion
        #region 窗体关闭
        void frm_CameToValve_FormClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        #region 计算差值
        private void bt_CalOffset_Click(object sender, EventArgs e)
        {
            double valveX;  //输入阀的X坐标
            double valveY;  //输入阀的Y坐标
            HTuple hv_Qx2 = 0;  //圆心的世界X坐标
            HTuple hv_Qy2 = 0;  //圆心的世界Y坐标
            HTuple hv_HomMat2D2 = null;  //相机To阀矩阵
            //求相机和阀的世界坐标的转换矩阵
            try
            {
                valveX = Convert.ToDouble(tb_valveX.Text);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "请输出正确坐标");
                return;
            }
            try
            {
                valveY = Convert.ToDouble(tb_valveY.Text);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "请输出正确坐标");
                return;
            }
            if (CVP != null)
            {
                try
                {
                    HOperatorSet.VectorAngleToRigid(-CVP.CircleCenterX, -CVP.CircleCenterY, 0, valveX, valveY, 0, out hv_HomMat2D2);
                    double detX = valveX - CVP.CircleCenterX;
                    double detY = valveY - CVP.CircleCenterY;
                    Frm_VisionRun.Instance.modelPara.DetX = detX;
                    Frm_VisionRun.Instance.modelPara.DetY = detY;
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "矩阵转换错误");
                    return;
                }
            }
            //保存矩阵关系
            try
            {
                mathCal.SaveNineHomMat2d("ValveHomMat2D.tup", hv_HomMat2D2);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "保存矩阵失败");
                return;
            }
        }
        #endregion
        
    }
}
