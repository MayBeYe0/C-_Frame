﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;

namespace Vision_FiveAxis
{
    public partial class frm_TCPServer : Form
    {
        public frm_TCPServer()
        {
            InitializeComponent();
        }

    }
}
