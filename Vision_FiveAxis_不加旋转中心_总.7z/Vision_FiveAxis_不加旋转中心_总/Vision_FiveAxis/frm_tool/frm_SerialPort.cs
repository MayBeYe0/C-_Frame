﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Communicate;

namespace Vision_FiveAxis
{
    public partial class frm_SerialPort : Form
    {
        #region 属性字段
        public SerialPortParamer SPP1 = new SerialPortParamer();  //串口参数
        #endregion
        #region 单实例
        private static frm_SerialPort _instance;
        public static frm_SerialPort Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_SerialPort();
                }
                return _instance;
            }
        }
        #endregion
        private frm_SerialPort()
        {
            InitializeComponent();
        }
        #region 确认保存参数
        private void bt_Sure_Click(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.SPP1 = SPP1;  //传参
                Frm_VisionRun.Instance.Serialize(SPP1, "SerialPort1.viso");  //保存串口参数
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "保存串口1参数失败");
                return;
            }
        }
        #endregion
        #region 修改COM口
        private void cb_COMPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SPP1.ComPort = cb_COMPort.Text;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口1COM口参数失败");
                return;
            }
        }
        #endregion
        #region 窗体事件
        private void frm_SerialPort_Load(object sender, EventArgs e)
        {
            Instance.TopMost = true;
            this.FormClosing += frm_SerialPort_Closing;  //窗体关闭事件
            cb_COMPort.Text = Frm_VisionRun.Instance.SPP1.ComPort;
        }
        void frm_SerialPort_Closing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        #region 取消
        private void bt_Cancel_Click(object sender, EventArgs e)
        {
            _instance = null;
            this.Close();
        }
        #endregion
    }
}
