﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HalconDotNet;
using ImageTool1212;
using Parameter;
using MathCal;
using Communicate;
using System.Threading;

namespace Vision_FiveAxis
{
    public partial class frm_CalibraCircleCenter : Form
    {
        #region 属性字段
        #region 单实例
        private static frm_CalibraCircleCenter _instance;
        public static frm_CalibraCircleCenter Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_CalibraCircleCenter();
                }
                return _instance;
            }
        }
        #endregion
        HObject outImage;  //图像
        imageTool1212 imTool = new imageTool1212();  //图像工具
        CircleCenterParam cCenPara;  //旋转中心参数
        HTuple Mat;  //九点矩阵
        //HTuple MatInvert;  //九点逆矩阵
        HTuple hv_x, hv_y;  //抓圆参数
        mathCal maCal = new mathCal();  //数据计算
        public SerialPortCommu SPComm = new SerialPortCommu();  //串口
        #endregion
        private frm_CalibraCircleCenter()
        {
            InitializeComponent();
        }
        #region 抓圆获得物理坐标
        private void bt_GrabOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm1.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm1.OpenSerialPort(Frm_VisionRun.Instance.SPP1);
                }
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0255#");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "串口通讯1失败");
                return;
            }
            Thread.Sleep(150);
            try
            {
                Frm_VisionRun.Instance.camera_AMKS.GrabImageOne(out outImage);  //开始拍照
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "拍照错误");
                return;
            }
            try
            {
                Frm_VisionRun.Instance.bll.SPComm1.SendData("SA0000#");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "串口1通讯错误");
                return;
            }
            try
            {
                imTool.ShowImage(outImage, Frm_ShowImage.Instance.halconView1.HalconWindow);  //显示图像
                imTool.FindCircleCenter(outImage, out cCenPara);
                imTool.ShowCirCleCenterContours(cCenPara, Frm_ShowImage.Instance.halconView1.HalconWindow);  //显示轮廓显示中心
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "查找轮廓失败");
                return;
            }
            if (Mat == null)
            {
                try
                {
                    mathCal.ReadCabliPointNine("NineHomMat2D.tup", out Mat);
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "读取九点标定矩阵错误");
                    return;
                }
            }
            try
            {
                HOperatorSet.AffineTransPoint2d(Mat, cCenPara.CircleColumn, cCenPara.CircleRow, out hv_x, out hv_y);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "转换矩阵错误");
                return;
            }
            int num = Convert.ToInt16(((Button)sender).Tag.ToString());
            if (num == 1)  //位置1
            {
                try
                {
                    cCenPara.EnX[0] = hv_x;
                    cCenPara.EnY[0] = hv_y;
                    tb_X1.Text = cCenPara.EnX[0].D.ToString("f3");
                    tb_Y1.Text = cCenPara.EnY[0].D.ToString("f3");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "未找到圆");
                    return;
                }
                
            }
            else if (num == 2)  //位置2
            {
                try
                {
                    double devX = Convert.ToDouble(tb_Pos2X.Text) - Convert.ToDouble(tb_Pos1X.Text);
                    double devY = Convert.ToDouble(tb_Pos2Y.Text) - Convert.ToDouble(tb_Pos1Y.Text);
                    cCenPara.EnX[1] = hv_x + devX;
                    cCenPara.EnY[1] = hv_y + devY;
                    tb_X2.Text = cCenPara.EnX[1].D.ToString("f3");
                    tb_Y2.Text = cCenPara.EnY[1].D.ToString("f3");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1,"请填写正确的坐标");
                    return;
                }
            }
            else if (num == 3)  //位置3
            {
                try
                {
                    double devX = Convert.ToDouble(tb_Pos3X.Text) - Convert.ToDouble(tb_Pos1X.Text);
                    double devY = Convert.ToDouble(tb_Pos3Y.Text) - Convert.ToDouble(tb_Pos1Y.Text);
                    cCenPara.EnX[2] = hv_x + devX;
                    cCenPara.EnY[2] = hv_y + devY;
                    tb_X3.Text = cCenPara.EnX[2].D.ToString("f3");
                    tb_Y3.Text = cCenPara.EnY[2].D.ToString("f3");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "请填写正确的坐标");
                    return;
                }
            }
            else  //位置4
            {
                try
                {
                    double devX = Convert.ToDouble(tb_Pos4X.Text) - Convert.ToDouble(tb_Pos1X.Text);
                    double devY = Convert.ToDouble(tb_Pos4Y.Text) - Convert.ToDouble(tb_Pos1Y.Text);
                    cCenPara.EnX[3] = hv_x + devX;
                    cCenPara.EnY[3] = hv_y + devY;
                    tb_X4.Text = cCenPara.EnX[3].D.ToString("f3");
                    tb_Y4.Text = cCenPara.EnY[3].D.ToString("f3");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "请填写正确的坐标");
                    return;
                }
            }
        }
        #endregion
        #region 计算圆心
        private void bt_CalCirCenter_Click(object sender, EventArgs e)
        {
            HTuple Mat, MatInvert, Row12, Column12;
            HObject ho_ContCircle = new HObject();
            try
            {
                maCal.GetCenterCircle(ref cCenPara);  //计算旋转中心
                #region 显示旋转中心
                mathCal.ReadCabliPointNine("NineHomMat2D.tup", out Mat);
                HOperatorSet.HomMat2dInvert(Mat, out MatInvert);  //求逆矩阵
                HOperatorSet.AffineTransPoint2d(MatInvert, cCenPara.CircleCenterX, cCenPara.CircleCenterY, out Column12, out Row12);
                cCenPara.CircleCenterRow = Row12;
                cCenPara.CircleCenterColumn = Column12;
                imTool.DrawCircleCenter(Frm_VisionRun.Instance.hwi, cCenPara.CircleCenterRow, cCenPara.CircleCenterColumn);  //显示旋转中心
                #endregion
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "计算旋转中心位置错误");
                return;
            }
            #region 计算半径
            //HTuple hv_row1, hv_column1, hv_row2, hv_colunm2, hv_row3, hv_colunm3;
            //if (MatInvert == null)
            //{
            //    mathCal.ReadCabliPointNine("NineHomMat2D.tup", out Mat);
            //    HOperatorSet.HomMat2dInvert(Mat, out MatInvert);  //求逆矩阵
            //}
            //HOperatorSet.AffineTransPoint2d(MatInvert, cCenPara.CircleCenterX, cCenPara.CircleCenterY, out hv_row1, out hv_column1);
            //HOperatorSet.AffineTransPoint2d(MatInvert, 0, 0, out hv_row2, out hv_colunm2);
            //HOperatorSet.AffineTransPoint2d(MatInvert, 0, cCenPara.CircleRadiusWor, out hv_row3, out hv_colunm3);
            //cCenPara.CircleRow = hv_row1;
            //cCenPara.CircleColumn = hv_column1;
            //cCenPara.CircleRadius = hv_row3 - hv_row2;

            //HOperatorSet.GenCircleContourXld(out ho_ContCircle, cCenPara.CircleRow, cCenPara.CircleColumn, cCenPara.CircleRadius,
            //    0, 6.28318, "positive", 1);
            //cCenPara.CircleContour = ho_ContCircle;

            //imTool.ShowCirCleCenterContours(cCenPara, Frm_ShowImage.Instance.halconView1.HalconWindow);
            #endregion
            try
            {
                Frm_VisionRun.Instance.Serialize(cCenPara, "CircleCenterPara.viso");  //保存旋转中心参数
                Frm_VisionRun.Instance.cirCenPara = cCenPara;  //传参到主页面
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "保存旋转中心参数错误");
                return;
            }
        }
        #endregion
        #region 窗体事件
        private void frm_CalibraCircleCenter_Load(object sender, EventArgs e)
        {
            Instance.TopMost = true;
            this.FormClosing += frm_CalibraCircleCenterClosing;  //注册窗口关闭事件
        }
        #endregion
        #region 窗体关闭
        void frm_CalibraCircleCenterClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
    }
}
