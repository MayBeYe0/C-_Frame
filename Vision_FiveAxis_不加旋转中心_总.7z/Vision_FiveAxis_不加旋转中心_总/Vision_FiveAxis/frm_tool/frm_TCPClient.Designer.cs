﻿namespace Vision_FiveAxis
{
    partial class frm_TCPClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lst_Rcv = new System.Windows.Forms.ListView();
            this.时间 = new System.Windows.Forms.ColumnHeader();
            this.消息 = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Send = new System.Windows.Forms.TextBox();
            this.bt_Send = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_Break = new System.Windows.Forms.Button();
            this.bt_ConnectServer = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Port = new System.Windows.Forms.TextBox();
            this.txt_IP = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Lst_Rcv
            // 
            this.Lst_Rcv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.时间,
            this.消息});
            this.Lst_Rcv.Location = new System.Drawing.Point(22, 52);
            this.Lst_Rcv.Name = "Lst_Rcv";
            this.Lst_Rcv.Size = new System.Drawing.Size(386, 247);
            this.Lst_Rcv.TabIndex = 0;
            this.Lst_Rcv.UseCompatibleStateImageBehavior = false;
            this.Lst_Rcv.View = System.Windows.Forms.View.Details;
            // 
            // 时间
            // 
            this.时间.Text = "时间";
            this.时间.Width = 80;
            // 
            // 消息
            // 
            this.消息.Text = "消息";
            this.消息.Width = 200;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(17, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "消息日志";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(19, 320);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "内容";
            // 
            // txt_Send
            // 
            this.txt_Send.Location = new System.Drawing.Point(65, 320);
            this.txt_Send.Name = "txt_Send";
            this.txt_Send.Size = new System.Drawing.Size(206, 21);
            this.txt_Send.TabIndex = 3;
            // 
            // bt_Send
            // 
            this.bt_Send.Location = new System.Drawing.Point(286, 318);
            this.bt_Send.Name = "bt_Send";
            this.bt_Send.Size = new System.Drawing.Size(57, 23);
            this.bt_Send.TabIndex = 4;
            this.bt_Send.Text = "发  送";
            this.bt_Send.UseVisualStyleBackColor = true;
            this.bt_Send.Click += new System.EventHandler(this.bt_Send_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(351, 318);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(57, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "清  空";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_Break);
            this.groupBox1.Controls.Add(this.bt_ConnectServer);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_Port);
            this.groupBox1.Controls.Add(this.txt_IP);
            this.groupBox1.Location = new System.Drawing.Point(441, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(228, 186);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "服务器配置";
            // 
            // bt_Break
            // 
            this.bt_Break.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_Break.Location = new System.Drawing.Point(120, 124);
            this.bt_Break.Name = "bt_Break";
            this.bt_Break.Size = new System.Drawing.Size(102, 35);
            this.bt_Break.TabIndex = 6;
            this.bt_Break.Text = "断开服务器";
            this.bt_Break.UseVisualStyleBackColor = true;
            this.bt_Break.Click += new System.EventHandler(this.bt_Break_Click);
            // 
            // bt_ConnectServer
            // 
            this.bt_ConnectServer.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_ConnectServer.Location = new System.Drawing.Point(6, 124);
            this.bt_ConnectServer.Name = "bt_ConnectServer";
            this.bt_ConnectServer.Size = new System.Drawing.Size(108, 35);
            this.bt_ConnectServer.TabIndex = 5;
            this.bt_ConnectServer.Text = "连接服务器";
            this.bt_ConnectServer.UseVisualStyleBackColor = true;
            this.bt_ConnectServer.Click += new System.EventHandler(this.bt_ConnectServer_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(30, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "端口";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(30, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "IP";
            // 
            // txt_Port
            // 
            this.txt_Port.Location = new System.Drawing.Point(97, 75);
            this.txt_Port.Name = "txt_Port";
            this.txt_Port.Size = new System.Drawing.Size(107, 21);
            this.txt_Port.TabIndex = 1;
            this.txt_Port.Text = "8000";
            // 
            // txt_IP
            // 
            this.txt_IP.Location = new System.Drawing.Point(97, 29);
            this.txt_IP.Name = "txt_IP";
            this.txt_IP.Size = new System.Drawing.Size(107, 21);
            this.txt_IP.TabIndex = 0;
            this.txt_IP.Text = "127.0.0.1";
            // 
            // frm_TCPClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 367);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.bt_Send);
            this.Controls.Add(this.txt_Send);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Lst_Rcv);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_TCPClient";
            this.Text = "TCP客户端";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView Lst_Rcv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Send;
        private System.Windows.Forms.Button bt_Send;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_Break;
        private System.Windows.Forms.Button bt_ConnectServer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Port;
        private System.Windows.Forms.TextBox txt_IP;
        private System.Windows.Forms.ColumnHeader 时间;
        private System.Windows.Forms.ColumnHeader 消息;

    }
}