﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Vision_FiveAxis
{
    public partial class frm_SerialPort2 : Form
    {
        #region 单实例
        private static frm_SerialPort2 _instance;
        public static frm_SerialPort2 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_SerialPort2();
                }
                return _instance;
            }
        }
        #endregion
        public frm_SerialPort2()
        {
            InitializeComponent();
        }
        #region 窗体事件
        private void frm_SerialPort2_Load(object sender, EventArgs e)
        {
            this.FormClosing += frm_SerialPort2_FormClosing;  //注册窗口关闭事件
            #region 初始化参数
            cb_COMPort.Text = Frm_VisionRun.Instance.SPP2.ComPort;
            cb_COMBaudRate.Text = Frm_VisionRun.Instance.SPP2.ComBaudRate.ToString();
            cb_COMDataBits.Text = Frm_VisionRun.Instance.SPP2.ComDataBits.ToString();
            cb_COMParity.Text = Frm_VisionRun.Instance.SPP2.ComParity;
            cb_COMStopBits.Text = Frm_VisionRun.Instance.SPP2.ComStopBits;
            #endregion
        }
        #endregion
        #region 窗体关闭
        void frm_SerialPort2_FormClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        #region 修改串口号
        private void cb_COMPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.SPP2.ComPort = cb_COMPort.Text;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口2COM口参数失败");
                return;
            }
        }
        #endregion
        #region 修改波特率
        private void cb_COMBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.SPP2.ComBaudRate = Convert.ToInt16(cb_COMBaudRate.Text);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口2波特率参数失败");
                return;
            }
        }
        #endregion
        #region 修改数据位
        private void cb_COMDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.SPP2.ComDataBits = Convert.ToInt16(cb_COMDataBits.Text);
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口2数据位参数失败");
                return;
            }
        }
        #endregion
        #region 修改校验位
        private void cb_COMParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.SPP2.ComParity = cb_COMParity.Text;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口2校验位参数失败");
                return;
            }
        }
        #endregion
        #region 修改停止位
        private void cb_COMStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.SPP2.ComStopBits = cb_COMStopBits.Text;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口2停止位参数失败");
                return;
            }
        }
        #endregion
        #region 确认参数
        private void bt_Sure_Click(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.SPP2, "SerialPort2.viso");  //保存串口参数
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改串口2参数失败");
                return;
            }
        }
        #endregion
        #region 取消
        private void bt_Cancel_Click(object sender, EventArgs e)
        {
            _instance = null;
            this.Close();
        }
        #endregion
    }
}
