﻿namespace Vision_FiveAxis
{
    partial class frm_CalibraHeightCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tb_heightDown = new System.Windows.Forms.TextBox();
            this.tb_heightUpp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_heightNormal = new System.Windows.Forms.TextBox();
            this.bt_HeightNormal = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bt_sure = new System.Windows.Forms.Button();
            this.bt_cancel = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.tb_heightDown, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.tb_heightUpp, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_heightNormal, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.bt_HeightNormal, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(369, 71);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tb_heightDown
            // 
            this.tb_heightDown.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_heightDown.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_heightDown.Location = new System.Drawing.Point(249, 38);
            this.tb_heightDown.Name = "tb_heightDown";
            this.tb_heightDown.Size = new System.Drawing.Size(117, 29);
            this.tb_heightDown.TabIndex = 38;
            this.tb_heightDown.Text = "49.9";
            this.tb_heightDown.TextChanged += new System.EventHandler(this.tb_heightDown_TextChanged);
            // 
            // tb_heightUpp
            // 
            this.tb_heightUpp.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_heightUpp.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_heightUpp.Location = new System.Drawing.Point(126, 38);
            this.tb_heightUpp.Name = "tb_heightUpp";
            this.tb_heightUpp.Size = new System.Drawing.Size(117, 29);
            this.tb_heightUpp.TabIndex = 37;
            this.tb_heightUpp.Text = "50.100";
            this.tb_heightUpp.TextChanged += new System.EventHandler(this.tb_heightUpp_TextChanged);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(126, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 35);
            this.label1.TabIndex = 35;
            this.label1.Text = "上限";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(249, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 35);
            this.label3.TabIndex = 35;
            this.label3.Text = "下限";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_heightNormal
            // 
            this.tb_heightNormal.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_heightNormal.Enabled = false;
            this.tb_heightNormal.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_heightNormal.Location = new System.Drawing.Point(3, 38);
            this.tb_heightNormal.Name = "tb_heightNormal";
            this.tb_heightNormal.Size = new System.Drawing.Size(117, 29);
            this.tb_heightNormal.TabIndex = 36;
            this.tb_heightNormal.Text = "50.000";
            // 
            // bt_HeightNormal
            // 
            this.bt_HeightNormal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_HeightNormal.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_HeightNormal.Location = new System.Drawing.Point(3, 3);
            this.bt_HeightNormal.Name = "bt_HeightNormal";
            this.bt_HeightNormal.Size = new System.Drawing.Size(117, 29);
            this.bt_HeightNormal.TabIndex = 39;
            this.bt_HeightNormal.Text = "标 准 高 度";
            this.bt_HeightNormal.UseVisualStyleBackColor = true;
            this.bt_HeightNormal.Click += new System.EventHandler(this.bt_HeightNormal_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Controls.Add(this.bt_sure);
            this.panel4.Controls.Add(this.bt_cancel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 72);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(369, 30);
            this.panel4.TabIndex = 4;
            // 
            // bt_sure
            // 
            this.bt_sure.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_sure.Location = new System.Drawing.Point(219, 0);
            this.bt_sure.Name = "bt_sure";
            this.bt_sure.Size = new System.Drawing.Size(75, 30);
            this.bt_sure.TabIndex = 4;
            this.bt_sure.Text = "确定";
            this.bt_sure.UseVisualStyleBackColor = true;
            this.bt_sure.Click += new System.EventHandler(this.bt_sure_Click);
            // 
            // bt_cancel
            // 
            this.bt_cancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_cancel.Location = new System.Drawing.Point(294, 0);
            this.bt_cancel.Name = "bt_cancel";
            this.bt_cancel.Size = new System.Drawing.Size(75, 30);
            this.bt_cancel.TabIndex = 5;
            this.bt_cancel.Text = "取消";
            this.bt_cancel.UseVisualStyleBackColor = true;
            this.bt_cancel.Click += new System.EventHandler(this.bt_cancel_Click);
            // 
            // frm_CalibraHeightCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 102);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_CalibraHeightCheck";
            this.Text = "高度防呆参数";
            this.Load += new System.EventHandler(this.frm_CalibraHeightCheck_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bt_sure;
        private System.Windows.Forms.Button bt_cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_heightNormal;
        private System.Windows.Forms.TextBox tb_heightDown;
        private System.Windows.Forms.TextBox tb_heightUpp;
        private System.Windows.Forms.Button bt_HeightNormal;
    }
}