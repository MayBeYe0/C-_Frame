﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Camera;
using HalconDotNet;
using ImageTool1212;
using System.Threading;
using Parameter;
using VisionTool.ImageToolDAL;

namespace Vision_FiveAxis
{
    public partial class frm_AcqFifo : Form
    {
        #region 属性字段
        AcqFifoTool acqFifoTool = new AcqFifoTool();  //图像工具类
        #endregion
        #region 单实例
        private static frm_AcqFifo _instance;
        public static frm_AcqFifo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_AcqFifo();
                }
                return _instance;
            }
        }
        #endregion
        private frm_AcqFifo()
        {
            InitializeComponent();
        }
        #region 窗体事件
        private void frm_AcqFifo_Load(object sender, EventArgs e)
        {
            Instance.TopMost = true;
            Frm_VisionRun.Instance.camera_AMKS.GrapImageEvent += Frm_VisionRun.Instance.camera_GrabImageEvent;  //注册相机采集事件
            this.FormClosing += frm_AcqFifo_FormClosing;  //注册窗口关闭事件
        }
        #endregion
        void frm_AcqFifo_FormClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #region 确认信息
        private void bt_AcqFifoSure_Click(object sender, EventArgs e)
        {

        }
        #endregion
        #region 取消
        private void bt_Cancel_Click(object sender, EventArgs e)
        {
            try
            {
                _instance = null;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "拍照窗口关闭失败");
            }
            this.Close();
        }
        #endregion
        #region 打开图片
        private void bt_ReadImage_Click(object sender, EventArgs e)
        {
            GetFilePath();  //获取文件路径
            acqFifoTool.ReadImage();  //读取图片
            ShowImage();  //显示图像
        }
        #endregion
        #region 上一张
        private void bt_UpImage_Click(object sender, EventArgs e)
        {

        }
        #endregion
        #region 下一张
        private void bt_DownImage_Click(object sender, EventArgs e)
        {

        }
        #endregion
        #region 获取文件路径
        private void GetFilePath()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "图像文件(*.bmp)|*.bmp|所有文件(*.bmp*.tif)|*.bmp;*.tif";
            ofd.Multiselect = true;
            ofd.Title = "请选择文件夹";
            ofd.InitialDirectory = @"E:\";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                acqFifoTool.imgPaths = ofd.FileNames;  //赋值文件路径
            }
            tb_ReadImagePath.Text = acqFifoTool.imgPaths[0];
        }
        #endregion
        #region 显示图像
        HTuple hv_Width, hv_Height;
        public void ShowImage()
        {
            HOperatorSet.GetImageSize(acqFifoTool.outImage, out hv_Width, out hv_Height);
            HOperatorSet.SetPart(halconView1.HalconWindow, 0, 0, hv_Height, hv_Width);
            HOperatorSet.DispObj(acqFifoTool.outImage, halconView1.HalconWindow);
        }
        #endregion
    }
}
