﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace Vision_FiveAxis
{
    public partial class frm_TCPClient : Form
    {
        private string currentTime;
        Thread thread;
        public frm_TCPClient()
        {
            InitializeComponent();
            Instance.TopMost = true;
            currentTime = DateTime.Now.ToString("hh:mm:ss");
        }
        private static frm_TCPClient _instance;
        public static frm_TCPClient Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new frm_TCPClient();
                return _instance;
            }
        }

        private void AddLog(string info)
        {
            //判断是否出现了跨线程访问的情况
            if (!this.Lst_Rcv.InvokeRequired)
            {
                //拼接一行的显示内容：时间与图标
                ListViewItem ls = new ListViewItem(" " + currentTime);
                //添加消息
                ls.SubItems.Add(info);
                //插入指定行
                Lst_Rcv.Items.Insert(Lst_Rcv.Items.Count, ls);
                //设置滚动到最后一行:确保最后一行是可以看到的
                Lst_Rcv.Items[this.Lst_Rcv.Items.Count - 1].EnsureVisible();
            }
            else
            {
                this.Invoke(new Action(() =>
                {
                    //拼接一行的显示内容：时间与图标
                    ListViewItem ls = new ListViewItem(" " + currentTime);
                    //添加消息
                    ls.SubItems.Add(info);
                    //插入指定行
                    Lst_Rcv.Items.Insert(Lst_Rcv.Items.Count, ls);
                    //设置滚动到最后一行:确保最后一行是可以看到的
                    Lst_Rcv.Items[this.Lst_Rcv.Items.Count - 1].EnsureVisible();
                }));
            }
        }

        Socket socketClinet;//创建Socket对象
        bool IsConnect = false;//是否连接成功
        #region 连接服务器
        private void bt_ConnectServer_Click(object sender, EventArgs e)
        {
            AddLog("开始连接服务器");
            //第一步:调用Socket对象初始化，IP4协议|Socke字节流|TCP协议
            socketClinet = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //第二步设置IP端口
            IPEndPoint ipe = new IPEndPoint(IPAddress.Parse(txt_IP.Text), int.Parse(txt_Port.Text));
            //第三步:Connect使用函数来连接服务器
            try
            {
                socketClinet.Connect(ipe);
                IsConnect = true;//判断是否连接成功
                AddLog("成功连接至服务器");
            }
            catch (Exception ex)
            {
                IsConnect = false;//连接失败
                AddLog("连接服务失败：" + ex.Message.ToString());
            }
            //第四步：创建一个监听线程来专门接收服务器发送过来的内容，然后显示
            thread = new Thread(CheckReceiveMsg);
            thread.Start();
        }
        #endregion
        /// <summary>
        /// 监听
        /// </summary>
        private void CheckReceiveMsg()
        {
            while (true)
            {
                //创建Byte字节缓冲区，专门用来接收内容
                byte[] buffer = new byte[1024 * 1024];
                //设置获取消息的长度
                int length = -1;
                //接收服务器发送过来的消息
                try
                {
                    //接收字节的长度->
                    length = socketClinet.Receive(buffer);
                }
                catch (Exception ex)
                {
                    AddLog("异常:" + ex.Message.ToString());
                    break;
                }
                //判断返回的内容是否大于-1
                if (length > 0)
                {
                    //string msg = Encoding.Default.GetString(buffer, 0, length);
                    string msg = ValueToHexStr(buffer, length);
                    AddLog(msg);
                }
                else
                {
                    AddLog("服务器断开连接!");
                    socketClinet.Close();
                    break;
                }
            }
        }
        #region 发送
        private void bt_Send_Click(object sender, EventArgs e)
        {
            if (IsConnect)
            {
                byte[] bufferSend = HexToValue(txt_Send.Text.Trim());
                socketClinet.Send(bufferSend);
            }
        }
        #endregion
        /// <summary>
        /// 清空发送区
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.txt_Send.Text = "";
        }
        /// <summary>
        /// 断开连接
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_Break_Click(object sender, EventArgs e)
        {
            socketClinet.Close();
            AddLog("服务器断开连接!");
        }
        #region  数值转换成16进制字符串
        public string ValueToHexStr(byte[] buffer, int length)
        {
            string hexStr = string.Empty;
            for (int i = 0; i < length; i++)
            {
                hexStr += buffer[i].ToString("X2");
                hexStr += " ";
            }
            return hexStr;
        }
        #endregion
        #region  16进制写法的字符串转成数值
        public byte[] HexToValue(string sendStr)
        {
            sendStr = sendStr.Replace(" ", "");
            sendStr = sendStr.Replace("0x", "");
            if (sendStr.Length % 2 != 0)
            {
                sendStr += " ";
            }
            byte[] buffer = new byte[sendStr.Length / 2];
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = Convert.ToByte(sendStr.Substring(i * 2, 2), 16);
            }
            return buffer;
        }
        #endregion

    }
}
