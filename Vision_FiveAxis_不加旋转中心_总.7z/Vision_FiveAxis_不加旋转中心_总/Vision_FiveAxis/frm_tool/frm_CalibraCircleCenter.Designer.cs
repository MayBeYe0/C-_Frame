﻿namespace Vision_FiveAxis
{
    partial class frm_CalibraCircleCenter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.tb_X3 = new System.Windows.Forms.TextBox();
            this.tb_Y3 = new System.Windows.Forms.TextBox();
            this.tb_Y2 = new System.Windows.Forms.TextBox();
            this.tb_Y1 = new System.Windows.Forms.TextBox();
            this.tb_X2 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bt_CalCirCenter = new System.Windows.Forms.Button();
            this.tb_X1 = new System.Windows.Forms.TextBox();
            this.bt_GrabThree = new System.Windows.Forms.Button();
            this.bt_GrabTwo = new System.Windows.Forms.Button();
            this.bt_GrabOne = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_Pos1X = new System.Windows.Forms.TextBox();
            this.tb_Pos1Y = new System.Windows.Forms.TextBox();
            this.tb_Pos2X = new System.Windows.Forms.TextBox();
            this.tb_Pos2Y = new System.Windows.Forms.TextBox();
            this.tb_Pos3X = new System.Windows.Forms.TextBox();
            this.tb_Pos3Y = new System.Windows.Forms.TextBox();
            this.tb_X4 = new System.Windows.Forms.TextBox();
            this.tb_Y4 = new System.Windows.Forms.TextBox();
            this.tb_Pos4X = new System.Windows.Forms.TextBox();
            this.tb_Pos4Y = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(82, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 31);
            this.label2.TabIndex = 34;
            this.label2.Text = "Y";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_X3
            // 
            this.tb_X3.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_X3.Location = new System.Drawing.Point(3, 99);
            this.tb_X3.Name = "tb_X3";
            this.tb_X3.ReadOnly = true;
            this.tb_X3.Size = new System.Drawing.Size(73, 26);
            this.tb_X3.TabIndex = 31;
            // 
            // tb_Y3
            // 
            this.tb_Y3.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Y3.Location = new System.Drawing.Point(82, 99);
            this.tb_Y3.Name = "tb_Y3";
            this.tb_Y3.ReadOnly = true;
            this.tb_Y3.Size = new System.Drawing.Size(73, 26);
            this.tb_Y3.TabIndex = 32;
            // 
            // tb_Y2
            // 
            this.tb_Y2.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Y2.Location = new System.Drawing.Point(82, 67);
            this.tb_Y2.Name = "tb_Y2";
            this.tb_Y2.ReadOnly = true;
            this.tb_Y2.Size = new System.Drawing.Size(73, 26);
            this.tb_Y2.TabIndex = 30;
            // 
            // tb_Y1
            // 
            this.tb_Y1.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Y1.Location = new System.Drawing.Point(82, 35);
            this.tb_Y1.Name = "tb_Y1";
            this.tb_Y1.ReadOnly = true;
            this.tb_Y1.Size = new System.Drawing.Size(73, 26);
            this.tb_Y1.TabIndex = 28;
            // 
            // tb_X2
            // 
            this.tb_X2.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_X2.Location = new System.Drawing.Point(3, 67);
            this.tb_X2.Name = "tb_X2";
            this.tb_X2.ReadOnly = true;
            this.tb_X2.Size = new System.Drawing.Size(73, 26);
            this.tb_X2.TabIndex = 29;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28F));
            this.tableLayoutPanel1.Controls.Add(this.bt_CalCirCenter, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_X3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tb_Y3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tb_Y2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tb_Y1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tb_X2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tb_X1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.bt_GrabThree, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.bt_GrabTwo, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.bt_GrabOne, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos1X, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos1Y, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos2X, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos2Y, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos3X, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos3Y, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.tb_X4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.tb_Y4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos4X, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.tb_Pos4Y, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.button1, 4, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(439, 162);
            this.tableLayoutPanel1.TabIndex = 27;
            // 
            // bt_CalCirCenter
            // 
            this.bt_CalCirCenter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_CalCirCenter.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_CalCirCenter.Location = new System.Drawing.Point(319, 3);
            this.bt_CalCirCenter.Name = "bt_CalCirCenter";
            this.bt_CalCirCenter.Size = new System.Drawing.Size(117, 26);
            this.bt_CalCirCenter.TabIndex = 28;
            this.bt_CalCirCenter.Text = "计算圆心";
            this.bt_CalCirCenter.UseVisualStyleBackColor = true;
            this.bt_CalCirCenter.Click += new System.EventHandler(this.bt_CalCirCenter_Click);
            // 
            // tb_X1
            // 
            this.tb_X1.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_X1.Location = new System.Drawing.Point(3, 35);
            this.tb_X1.Name = "tb_X1";
            this.tb_X1.ReadOnly = true;
            this.tb_X1.Size = new System.Drawing.Size(73, 26);
            this.tb_X1.TabIndex = 27;
            // 
            // bt_GrabThree
            // 
            this.bt_GrabThree.Font = new System.Drawing.Font("宋体", 12F);
            this.bt_GrabThree.Location = new System.Drawing.Point(319, 99);
            this.bt_GrabThree.Name = "bt_GrabThree";
            this.bt_GrabThree.Size = new System.Drawing.Size(117, 26);
            this.bt_GrabThree.TabIndex = 26;
            this.bt_GrabThree.Tag = "3";
            this.bt_GrabThree.Text = "位置三拍照";
            this.bt_GrabThree.UseVisualStyleBackColor = true;
            this.bt_GrabThree.Click += new System.EventHandler(this.bt_GrabOne_Click);
            // 
            // bt_GrabTwo
            // 
            this.bt_GrabTwo.Font = new System.Drawing.Font("宋体", 12F);
            this.bt_GrabTwo.Location = new System.Drawing.Point(319, 67);
            this.bt_GrabTwo.Name = "bt_GrabTwo";
            this.bt_GrabTwo.Size = new System.Drawing.Size(117, 25);
            this.bt_GrabTwo.TabIndex = 25;
            this.bt_GrabTwo.Tag = "2";
            this.bt_GrabTwo.Text = "位置二拍照";
            this.bt_GrabTwo.UseVisualStyleBackColor = true;
            this.bt_GrabTwo.Click += new System.EventHandler(this.bt_GrabOne_Click);
            // 
            // bt_GrabOne
            // 
            this.bt_GrabOne.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_GrabOne.Location = new System.Drawing.Point(319, 35);
            this.bt_GrabOne.Name = "bt_GrabOne";
            this.bt_GrabOne.Size = new System.Drawing.Size(117, 25);
            this.bt_GrabOne.TabIndex = 0;
            this.bt_GrabOne.Tag = "1";
            this.bt_GrabOne.Text = "位置一拍照";
            this.bt_GrabOne.UseVisualStyleBackColor = true;
            this.bt_GrabOne.Click += new System.EventHandler(this.bt_GrabOne_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 32);
            this.label1.TabIndex = 33;
            this.label1.Text = "X";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(161, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 31);
            this.label3.TabIndex = 34;
            this.label3.Text = "相机X坐标";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(240, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 31);
            this.label4.TabIndex = 34;
            this.label4.Text = "相机Y坐标";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_Pos1X
            // 
            this.tb_Pos1X.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos1X.Location = new System.Drawing.Point(161, 35);
            this.tb_Pos1X.Name = "tb_Pos1X";
            this.tb_Pos1X.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos1X.TabIndex = 28;
            this.tb_Pos1X.Text = "-135";
            // 
            // tb_Pos1Y
            // 
            this.tb_Pos1Y.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos1Y.Location = new System.Drawing.Point(240, 35);
            this.tb_Pos1Y.Name = "tb_Pos1Y";
            this.tb_Pos1Y.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos1Y.TabIndex = 28;
            this.tb_Pos1Y.Text = "-128";
            // 
            // tb_Pos2X
            // 
            this.tb_Pos2X.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos2X.Location = new System.Drawing.Point(161, 67);
            this.tb_Pos2X.Name = "tb_Pos2X";
            this.tb_Pos2X.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos2X.TabIndex = 28;
            this.tb_Pos2X.Text = "-135";
            // 
            // tb_Pos2Y
            // 
            this.tb_Pos2Y.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos2Y.Location = new System.Drawing.Point(240, 67);
            this.tb_Pos2Y.Name = "tb_Pos2Y";
            this.tb_Pos2Y.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos2Y.TabIndex = 28;
            this.tb_Pos2Y.Text = "-128";
            // 
            // tb_Pos3X
            // 
            this.tb_Pos3X.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos3X.Location = new System.Drawing.Point(161, 99);
            this.tb_Pos3X.Name = "tb_Pos3X";
            this.tb_Pos3X.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos3X.TabIndex = 28;
            this.tb_Pos3X.Text = "-135";
            // 
            // tb_Pos3Y
            // 
            this.tb_Pos3Y.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos3Y.Location = new System.Drawing.Point(240, 99);
            this.tb_Pos3Y.Name = "tb_Pos3Y";
            this.tb_Pos3Y.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos3Y.TabIndex = 28;
            this.tb_Pos3Y.Text = "-128";
            // 
            // tb_X4
            // 
            this.tb_X4.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_X4.Location = new System.Drawing.Point(3, 131);
            this.tb_X4.Name = "tb_X4";
            this.tb_X4.ReadOnly = true;
            this.tb_X4.Size = new System.Drawing.Size(73, 26);
            this.tb_X4.TabIndex = 31;
            // 
            // tb_Y4
            // 
            this.tb_Y4.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Y4.Location = new System.Drawing.Point(82, 131);
            this.tb_Y4.Name = "tb_Y4";
            this.tb_Y4.ReadOnly = true;
            this.tb_Y4.Size = new System.Drawing.Size(73, 26);
            this.tb_Y4.TabIndex = 31;
            // 
            // tb_Pos4X
            // 
            this.tb_Pos4X.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos4X.Location = new System.Drawing.Point(161, 131);
            this.tb_Pos4X.Name = "tb_Pos4X";
            this.tb_Pos4X.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos4X.TabIndex = 31;
            this.tb_Pos4X.Text = "-135";
            // 
            // tb_Pos4Y
            // 
            this.tb_Pos4Y.Font = new System.Drawing.Font("宋体", 12F);
            this.tb_Pos4Y.Location = new System.Drawing.Point(240, 131);
            this.tb_Pos4Y.Name = "tb_Pos4Y";
            this.tb_Pos4Y.Size = new System.Drawing.Size(73, 26);
            this.tb_Pos4Y.TabIndex = 31;
            this.tb_Pos4Y.Text = "-128";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 12F);
            this.button1.Location = new System.Drawing.Point(319, 131);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 28);
            this.button1.TabIndex = 26;
            this.button1.Tag = "4";
            this.button1.Text = "位置四拍照";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.bt_GrabOne_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(439, 162);
            this.panel1.TabIndex = 1;
            // 
            // frm_CalibraCircleCenter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 162);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frm_CalibraCircleCenter";
            this.Text = "旋转中心标定";
            this.Load += new System.EventHandler(this.frm_CalibraCircleCenter_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_X3;
        private System.Windows.Forms.TextBox tb_Y3;
        private System.Windows.Forms.TextBox tb_Y2;
        private System.Windows.Forms.TextBox tb_Y1;
        private System.Windows.Forms.TextBox tb_X2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tb_X1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt_CalCirCenter;
        private System.Windows.Forms.Button bt_GrabThree;
        private System.Windows.Forms.Button bt_GrabTwo;
        private System.Windows.Forms.Button bt_GrabOne;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_Pos1X;
        private System.Windows.Forms.TextBox tb_Pos1Y;
        private System.Windows.Forms.TextBox tb_Pos2X;
        private System.Windows.Forms.TextBox tb_Pos2Y;
        private System.Windows.Forms.TextBox tb_Pos3X;
        private System.Windows.Forms.TextBox tb_Pos3Y;
        private System.Windows.Forms.TextBox tb_X4;
        private System.Windows.Forms.TextBox tb_Y4;
        private System.Windows.Forms.TextBox tb_Pos4X;
        private System.Windows.Forms.TextBox tb_Pos4Y;
        private System.Windows.Forms.Button button1;
    }
}