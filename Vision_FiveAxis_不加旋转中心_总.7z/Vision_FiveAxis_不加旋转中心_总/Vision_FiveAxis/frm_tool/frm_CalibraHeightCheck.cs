﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using MathCal;

namespace Vision_FiveAxis
{
    public partial class frm_CalibraHeightCheck : Form
    {
        #region 属性和字段
        //单例窗体
        private static frm_CalibraHeightCheck _instance;
        public static frm_CalibraHeightCheck Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_CalibraHeightCheck();
                }
                return _instance;
            }
        }
        public mathCal math = new mathCal();
        #endregion

        public frm_CalibraHeightCheck()
        {
            InitializeComponent();
        }

        #region 设置标准高度
        private void bt_HeightNormal_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Frm_VisionRun.Instance.bll.SPComm2.isConnect)
                {
                    Frm_VisionRun.Instance.bll.SPComm2.OpenSerialPort(Frm_VisionRun.Instance.SPP2);
                }
                Frm_VisionRun.Instance.bll.SPComm2.SendDataHex("02 4D 45 41 53 55 52 45 03");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "通讯失败");
                return;
            }
            Thread.Sleep(100);
            try
            {
                string height = Frm_VisionRun.Instance.bll.SPComm2.ReceiveDataHex();
                string heightDec = math.OptexHexToValue(height);  //将16进制数据转换成对应的ASCII码
                Frm_VisionRun.Instance.CHCP.HeightNormol = double.Parse(heightDec);  //传给参数类
                tb_heightNormal.Text = Frm_VisionRun.Instance.CHCP.HeightNormol.ToString("f3");  //显示
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "数据获取失败");
                return;
            }
        }
        #endregion
        #region 修改高度上限
        private void tb_heightUpp_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(tb_heightUpp.Text) >= Frm_VisionRun.Instance.CHCP.HeightNormol)
                {
                    Frm_VisionRun.Instance.CHCP.HeightUpp = Convert.ToDouble(tb_heightUpp.Text);
                }
                else
                {
                    tb_heightUpp.Text = Frm_VisionRun.Instance.CHCP.HeightNormol.ToString("f3");
                    Frm_VisionRun.Instance.CHCP.HeightUpp = Frm_VisionRun.Instance.CHCP.HeightNormol;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改参数失败");
                return;
            }
        }
        #endregion
        #region 修改高度下限
        private void tb_heightDown_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(tb_heightDown.Text) <= Frm_VisionRun.Instance.CHCP.HeightNormol)
                {
                    Frm_VisionRun.Instance.CHCP.HeightDown = Convert.ToDouble(tb_heightDown.Text);
                }
                else
                {
                    tb_heightDown.Text = Frm_VisionRun.Instance.CHCP.HeightNormol.ToString("f3");
                    Frm_VisionRun.Instance.CHCP.HeightDown = Frm_VisionRun.Instance.CHCP.HeightNormol;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "修改参数失败");
                return;
            }
        }
        #endregion
        #region 确认
        private void bt_sure_Click(object sender, EventArgs e)
        {
            try
            {
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CHCP, "CalibraHeightCheckParam.viso");  //保存高度防呆参数
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "保存参数失败");
                return;
            }
        }
        #endregion
        #region 取消
        private void bt_cancel_Click(object sender, EventArgs e)
        {
            try
            {
                _instance = null;
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "关闭高度防呆窗体失败");
                return;
            }
            this.Close();
        }
        #endregion
        #region 窗体事件
        private void frm_CalibraHeightCheck_Load(object sender, EventArgs e)
        {
            this.FormClosing += frm_CalibraHeightCheckClosing;  //注册窗口关闭事件
            #region 初始化参数
            tb_heightNormal.Text = Frm_VisionRun.Instance.CHCP.HeightNormol.ToString("f3");
            tb_heightUpp.Text = Frm_VisionRun.Instance.CHCP.HeightUpp.ToString("f3");
            tb_heightDown.Text = Frm_VisionRun.Instance.CHCP.HeightDown.ToString("f3");
            #endregion
        }
        void frm_CalibraHeightCheckClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        
    }
}
