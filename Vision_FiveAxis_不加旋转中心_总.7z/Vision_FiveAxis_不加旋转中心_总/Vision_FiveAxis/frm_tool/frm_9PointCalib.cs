﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using Parameter;
using MathCal;
using HalconDotNet;

namespace Vision_FiveAxis
{
    public partial class frm_9PointCalib : Form
    {
        #region 属性字段
        HTuple NineHomMat2d; //九点标定矩阵
        HTuple hwi = Frm_ShowImage.Instance.halconView1.HalconWindow;  //窗口显示句柄
        string info = null;  //日志信息
        PosInfo NinePointPix;  //标定信息
        #endregion
        public frm_9PointCalib()
        {
            InitializeComponent();
        }
        #region 单实例
        private static frm_9PointCalib _instance;
        public static frm_9PointCalib Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new frm_9PointCalib();
                }
                return _instance;
            }
        }
        #endregion
        #region 窗体事件
        private void frm_9PointCalib_Load(object sender, EventArgs e)
        {
            Instance.TopMost = true;
            this.FormClosing += frm_AcqFifo_FormClosing;  //注册窗口关闭事件
            ChangeXY();  //初始化坐标数据
            #region 初始化标定参数
            tb_MedianFilter.Text = Frm_VisionRun.Instance.CNPP.MedianValue.ToString();
            tb_MinArea.Text = Frm_VisionRun.Instance.CNPP.MinArea.ToString();
            tb_MaxArea.Text = Frm_VisionRun.Instance.CNPP.MaxArea.ToString();
            tb_MinGray.Text = Frm_VisionRun.Instance.CNPP.MinGray.ToString();
            tb_MaxGray.Text = Frm_VisionRun.Instance.CNPP.MaxGray.ToString();
            #endregion
        }
        #endregion
        #region 窗体关闭
        void frm_AcqFifo_FormClosing(object sender, FormClosingEventArgs e)
        {
            _instance = null;
        }
        #endregion
        #region 九点标定
        private void bt_StartCalib_Click(object sender, EventArgs e)
        {
            info = null;  //初始化日志信息
            NinePointPix = null;
            NinePointPix = new PosInfo();  //初始化标定信息
            #region 像素位置的获取
            try
            {
                int runNumber = Frm_VisionRun.Instance.bll.AutoNineCalibration(Frm_VisionRun.Instance.camera_AMKS, ref NinePointPix, hwi, Frm_VisionRun.Instance.SPP1, out info, Frm_VisionRun.Instance.CNPP);
                if (runNumber != 0)
                {
                    Frm_Log.Instance.AddLog(1, info);
                    return;
                }
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "获取像素位置失败");
                return;
            }
            if (NinePointPix.CountsObj != 9)
            {
                Frm_Log.Instance.AddLog(1,"获取标定指令失败");
                return;
            }
            int i = 0, j = 0;
            foreach (var item in tableLayoutPanel2.Controls)
            {
                if (item is TextBox)
                {
                    if (i < 9)
                    {
                        ((TextBox)item).Text = NinePointPix.Rows[i].D.ToString("f2");
                    }
                    else
                    {
                        ((TextBox)item).Text = NinePointPix.Columns[j].D.ToString("f2");
                        j++;
                    }
                    i++;
                }
            }
            #endregion
            #region 获取物理位置的坐标
            int m = 0, n = 0;
            foreach (var item in tableLayoutPanel3.Controls)
            {
                if (item is TextBox)
                {
                    if (m < 9)
                    {
                        NinePointPix.EnX[m] = Convert.ToDouble(((TextBox)item).Text);
                    }
                    else
                    {
                        NinePointPix.EnY[n] = Convert.ToDouble(((TextBox)item).Text);
                        n++;
                    }
                    m++;
                }
            }
            #endregion
            #region 九点标定
            try
            {
                NineHomMat2d = mathCal.NinePointCabli(NinePointPix);
                //mathCal.SaveNineHomMat2d("NineHomMat2D.tup", NineHomMat2d);
                Frm_Log.Instance.AddLog(1, "标定成功");
            }
            catch
            {
                Frm_Log.Instance.AddLog(1, "标定失败");
            }
            #endregion
        }
        #endregion
        #region 显示标定XY坐标
        private void tb_X1_TextChanged(object sender, EventArgs e)
        {
            if (tb_X1.Text == "-" || tb_Y1.Text == "-")
            {
                return;
            }
            else
            {
                ChangeXY();
            }
        }
        #endregion
        #region 循环修改XY坐标
        void ChangeXY()
        {
            int k = 0, i = 0, j = 0;
            if (tb_X1.Text == "" || tb_Y1.Text == "")
            {
                return;
            }
            else
            {
                foreach (var item in tableLayoutPanel3.Controls)
                {
                    if (item is TextBox)
                    {
                        if (k > 0 && k <= 2)  //X第一列
                        {
                            ((TextBox)item).Text = (Convert.ToDouble(tb_X1.Text) + k * 15.0).ToString("f2");
                        }
                        else if (k > 2 && k <= 5)  //X第二列
                        {
                            ((TextBox)item).Text = (Convert.ToDouble(tb_X1.Text) + 2 * 15.0 - i * 15.0).ToString("f2");
                            i++;
                        }
                        else if (k > 5 && k <= 8)  //X第三列
                        {
                            ((TextBox)item).Text = (Convert.ToDouble(tb_X1.Text) + j * 15.0).ToString("f2");
                            j++;
                        }
                        else if (k > 9 && k <= 11)  //Y第一列
                        {
                            ((TextBox)item).Text = (Convert.ToDouble(tb_Y1.Text)).ToString("f2");
                        }
                        else if (k > 11 && k <= 14)  //Y第二列
                        {
                            ((TextBox)item).Text = (Convert.ToDouble(tb_Y1.Text) - 8.0).ToString("f2");
                        }
                        else if (k > 14 && k <= 17)  //Y第三列
                        {
                            ((TextBox)item).Text = (Convert.ToDouble(tb_Y1.Text) - 2 * 8.0).ToString("f2");
                        }
                        k++;
                    }
                }
            }
        }
        #endregion
        #region 保存九点标定文件
        private void bt_SaveCalibraFile_Click(object sender, EventArgs e)
        {
            //if (NineHomMat2d == null)
            //{
            //    Frm_Log.Instance.AddLog(1, "九点标定矩阵为空 无法保存 请先标定");
            //    return;
            //}
            //bool res = false;
            //SaveFileDialog sfd = new SaveFileDialog();
            //sfd.Title = "保存对话框";
            //sfd.InitialDirectory = @"D:\";
            //sfd.Filter = "标定文件(*.tup)|*.tup";
            //if (sfd.ShowDialog() == DialogResult.OK)
            //{
            //    res = mathCal.SaveNineHomMat2d(sfd.FileName, NineHomMat2d);
            //}
            //if (res)
            //{
            //    Frm_Log.Instance.AddLog(0, "保存成功");
            //}
            //else
            //{
            //    Frm_Log.Instance.AddLog(0, "保存失败");
            //}
            if (((Button)sender).Tag.ToString() == "1")
            {
                try
                {
                    mathCal.SaveNineHomMat2d("NineHomMat2D.tup", NineHomMat2d);
                    Frm_Log.Instance.AddLog(0, "保存成功");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "保存失败");
                }
            }
            else
            {
                try
                {
                    mathCal.SaveNineHomMat2d(@"Parameter\NineHomMat2D1.tup", NineHomMat2d);
                    Frm_Log.Instance.AddLog(0, "保存成功");
                }
                catch
                {
                    Frm_Log.Instance.AddLog(1, "保存失败");
                }
            }
        }
        #endregion
        #region 中值滤波参数
        private void tb_MedianFilter_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(tb_MedianFilter.Text) < 1)
                {
                    tb_MedianFilter.Text = "1";
                    Frm_VisionRun.Instance.CNPP.MedianValue = 1;
                }
                else if (Convert.ToInt32(tb_MedianFilter.Text) > 4095)
                {
                    tb_MedianFilter.Text = "4095";
                    Frm_VisionRun.Instance.CNPP.MedianValue = 4095;
                }
                else
                {
                    Frm_VisionRun.Instance.CNPP.MedianValue = Convert.ToInt32(tb_MedianFilter.Text);
                }
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CNPP, @"Parameter\calibraNinePointParam.viso");
            }
            catch
            {
                MessageBox.Show("输入内容错误","提示",MessageBoxButtons.OK,MessageBoxIcon.Error);
                tb_MedianFilter.Text = Frm_VisionRun.Instance.CNPP.MedianValue.ToString();
                return;
            }
        }
        #endregion
        #region 区域最小值
        private void tb_MinArea_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(tb_MinArea.Text) < 1)
                {
                    tb_MinArea.Text = "1";
                    Frm_VisionRun.Instance.CNPP.MinArea = 1;
                }
                else if (Convert.ToInt32(tb_MinArea.Text) > Convert.ToInt32(tb_MaxArea.Text))
                {
                    tb_MinArea.Text = tb_MaxArea.Text;
                    Frm_VisionRun.Instance.CNPP.MinArea = Convert.ToInt32(tb_MaxArea.Text);
                }
                else
                {
                    Frm_VisionRun.Instance.CNPP.MinArea = Convert.ToInt32(tb_MinArea.Text);
                }
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CNPP, @"Parameter\calibraNinePointParam.viso");
            }
            catch
            {
                MessageBox.Show("输入内容错误", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_MinArea.Text = Frm_VisionRun.Instance.CNPP.MinArea.ToString();
                return;
            }
        }
        #endregion
        #region 区域最大值
        private void tb_MaxArea_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(tb_MaxArea.Text) > 99999)
                {
                    tb_MaxArea.Text = "99999";
                    Frm_VisionRun.Instance.CNPP.MaxArea = 99999;
                }
                else if (Convert.ToInt32(tb_MaxArea.Text) < Convert.ToInt32(tb_MinArea.Text))
                {
                    tb_MaxArea.Text = tb_MinArea.Text;
                    Frm_VisionRun.Instance.CNPP.MaxArea = Convert.ToInt32(tb_MinArea.Text);
                }
                else
                {
                    Frm_VisionRun.Instance.CNPP.MaxArea = Convert.ToInt32(tb_MaxArea.Text);
                }
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CNPP, @"Parameter\calibraNinePointParam.viso");
            }
            catch
            {
                MessageBox.Show("输入内容错误", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_MaxArea.Text = Frm_VisionRun.Instance.CNPP.MaxArea.ToString();
                return;
            }
        }
        #endregion
        #region 灰度最小值
        private void tb_MinGray_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt16(tb_MinGray.Text) < 0)
                {
                    tb_MinGray.Text = "0";
                    Frm_VisionRun.Instance.CNPP.MinGray = 0;
                }
                else if (Convert.ToInt16(tb_MinGray.Text) > Convert.ToInt16(tb_MaxGray.Text))
                {
                    tb_MinGray.Text = tb_MaxGray.Text;
                    Frm_VisionRun.Instance.CNPP.MinGray = Convert.ToInt16(tb_MaxGray.Text);
                }
                else
                {
                    Frm_VisionRun.Instance.CNPP.MinGray = Convert.ToInt16(tb_MinGray.Text);
                }
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CNPP, @"Parameter\calibraNinePointParam.viso");
            }
            catch
            {
                MessageBox.Show("输入内容错误", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_MinGray.Text = Frm_VisionRun.Instance.CNPP.MinGray.ToString();
                return;
            }
        }
        #endregion
        #region 灰度最大值
        private void tb_MaxGray_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt16(tb_MaxGray.Text) > 255)
                {
                    tb_MaxGray.Text = "255";
                    Frm_VisionRun.Instance.CNPP.MaxGray = 255;
                }
                else if (Convert.ToInt16(tb_MaxGray.Text) < Convert.ToInt16(tb_MinGray.Text))
                {
                    tb_MaxGray.Text = tb_MinGray.Text;
                    Frm_VisionRun.Instance.CNPP.MaxGray = Convert.ToInt16(tb_MinGray.Text);
                }
                else
                {
                    Frm_VisionRun.Instance.CNPP.MaxGray = Convert.ToInt16(tb_MaxGray.Text);
                }
                Frm_VisionRun.Instance.Serialize(Frm_VisionRun.Instance.CNPP, @"Parameter\calibraNinePointParam.viso");
            }
            catch
            {
                MessageBox.Show("输入内容错误", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_MaxGray.Text = Frm_VisionRun.Instance.CNPP.MaxGray.ToString();
                return;
            }
        }
        #endregion
        

    }
}
