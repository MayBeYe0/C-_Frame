﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VisionTool.ImageToolDAL;
using HalconDotNet;
using Vision_FiveAxis.DAL;

namespace Vision_FiveAxis.BLL
{
    public class EditBLL
    {
        public static void Add(ListView listView, List<ImageTool> tool, ImageTool it, string[] str, HWindowControl hwin)
        {
            EditDAL.Add(listView, tool, it, str, hwin);
        }
    }
}
