﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VisionTool.ImageToolDAL;

namespace Vision_FiveAxis
{
    public class ProgramBLL
    {
        public static int Run(List<ImageTool> tool, FlowExecuteDAL flowExecute)
        {
            return ProgramDAL.ProgramRun(tool, flowExecute);
        }
    }
}